# Market Monitoring - Price Dashboard (Refactored Modular Release: Web App Deployment)

This release provides the domain-modular refactored implementation of the UAT-approved **Market Monitoring - Price Dashboard** (`prizedashboard_ux_webapp_PASS`), configured for **Azure App Service (Web App) deployment** with Managed Identity and Azure Key Vault.

---

## 1. Modular File Structure

```text
prizedashboard_refactored_webapp/
├── .streamlit/
│   └── config.toml
├── assets/
│   └── logo.png
├── azure-pipelines.yaml
├── azure-pipelines-NED-refresh.yml
├── requirements.txt
├── requirements-NED.txt
├── streamlit_app.py                 # Application entry point
├── dashboards/
│   └── demo_dashboard.py            # Thin controller coordinating sidebar, data loading & tabs
├── src/
│   ├── apis/                        # Cached data loaders (NEDBlob.py, elexon.py, enappsys.py, etc.)
│   ├── models/
│   │   └── investigation.py         # Immutable InvestigationRequest & LoadedInvestigation models
│   ├── services/                    # Pure Python/Pandas business logic
│   │   ├── date_service.py          # Year + Day / ISO Week / Month / Custom date resolution
│   │   ├── diagnostics_service.py   # Step timings & source diagnostics recorder
│   │   ├── filter_service.py        # Fuel -> Portfolio -> BMU scoping, pair presets & summary fields
│   │   ├── operational_service.py   # Operational mapping prep, Dynamic Params & REMIT capacity bar prep
│   │   └── price_service.py         # Wholesale filtering, Bid/Offer pivot table & BOA filtering
│   ├── components/                  # Reusable UI & Plotly figure builders
│   │   ├── operational_chart.py     # 750px Operational (with REMIT bars) & Dynamic Parameters charts
│   │   ├── price_chart.py           # 750px Wholesale & Bid/Offer chart
│   │   ├── sidebar.py               # Sidebar investigation controls & compact NESO footer
│   │   ├── styles.py                # CSS styling (white cards, plum sidebar, React Aria calendar fix)
│   │   └── summary_cards.py         # 5 responsive summary cards & pending-change notice
│   ├── views/                       # One self-contained module per analytical tab
│   │   ├── ancillary_services_view.py
│   │   ├── boa_instructions_view.py
│   │   ├── data_tables_view.py
│   │   ├── dynamic_parameters_view.py
│   │   ├── roc_view.py
│   │   ├── strike_prices_view.py
│   │   └── unit_prices_view.py
│   └── utils/
│       ├── dates.py
│       ├── figTrace.py
│       ├── globals.py               # Managed Identity credential & Azure endpoint configuration
│       └── keyvault.py              # Lazy SecretClient initialization
├── jobs/
│   └── ned_query.py
└── setup/
```

---

## 2. Startup Command (Azure App Service)

```bash
python -m streamlit run streamlit_app.py --server.port 8000 --server.address 0.0.0.0
```
