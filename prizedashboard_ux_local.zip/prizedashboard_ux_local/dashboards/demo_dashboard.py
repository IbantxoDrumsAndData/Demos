from __future__ import annotations

import calendar
from contextlib import contextmanager
from datetime import date, datetime, time, timezone
import html
from pathlib import Path
from time import perf_counter
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from src.apis.enappsys import getWholesalePrices
from src.apis.NEDBlob import getOperationalData
from src.apis.NEDBlob import getStakeholders
from src.apis.NEDBlob import getBidOfferData
from src.utils.figTrace import figTrace
from src.apis.elexon import getBMUMapping
from src.apis.elexon import getRemit
from src.apis.NEDBlob import getBOAInstructionsData

# =============================
#   TITLE AND COLUMN CONFIG
# =============================
st.set_page_config(
    page_title="Market Monitoring - Price Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)

PLOTLY_THEME = "plotly_white"
PLOTLY_BG_COLOR = "#FFFFFF"
REMIT_FILL_COLOR = "#C7B2D3"
REMIT_LINE_COLOR = "#78456E"

MONTH_NAMES = {
    1: "01 - January",
    2: "02 - February",
    3: "03 - March",
    4: "04 - April",
    5: "05 - May",
    6: "06 - June",
    7: "07 - July",
    8: "08 - August",
    9: "09 - September",
    10: "10 - October",
    11: "11 - November",
    12: "12 - December",
}

PAIR_PRESET_OPTIONS = [
    "Pair -1",
    "Pair +1",
    "Pairs -1 and +1",
    "All pairs",
    "Custom selection",
]


# =============================
#   STYLING
# =============================
def _inject_ux_styles() -> None:
    st.markdown(
        """
        <style>
        .ux-head {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 8px;
        }
        .ux-head h2 {
            font-size: 25px;
            margin: 0 0 4px 0;
            color: #233044;
        }
        .ux-muted {
            color: #657387;
            font-size: 12px;
            margin: 0;
        }
        .ux-pending {
            color: #77460C;
            background: #FFF0D7;
            border: 1px solid #F0D4A8;
            padding: 9px 12px;
            border-radius: 5px;
            font-size: 12px;
            margin: 12px 0;
        }
        .ux-summary-grid {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 12px;
            margin: 16px 0 20px 0;
        }
        .ux-summary-card {
            min-width: 0;
            background: #FFFFFF;
            border: 1px solid #D5DCE5;
            border-radius: 9px;
            padding: 15px 16px;
            box-shadow: 0 2px 6px rgba(25, 35, 50, 0.035);
        }
        .ux-summary-card span {
            display: block;
            color: #667286;
            font-size: 11px;
            margin-bottom: 4px;
        }
        .ux-summary-card strong {
            display: block;
            color: #233044;
            font-size: 13px;
            overflow-wrap: anywhere;
            line-height: 1.5;
        }
        .ux-notice {
            padding: 14px 16px;
            border-radius: 6px;
            background: #E2E9F6;
            color: #364D71;
            font-size: 12px;
            border: 1px solid #C8D6EC;
        }
        .ux-sidebar-title {
            font-size: 19px;
            font-weight: 700;
            color: #FFFFFF;
            margin: 0 0 8px 0;
            line-height: 1.3;
        }
        .ux-sidebar-help {
            font-size: 12px;
            color: #E1C9DD;
            margin: 4px 0 10px 0;
        }
        .ux-sidebar-section-label {
            font-size: 12px;
            font-weight: 650;
            color: #FFFFFF;
            margin: 12px 0 6px 0;
        }
        .ux-sidebar-foot {
            border-top: 1px solid #78456E;
            padding-top: 14px;
            margin-top: 18px;
        }
        .ux-sidebar-foot-note {
            display: block;
            color: #DEC7D9;
            font-size: 10px;
            margin: 4px 0 0 0;
            line-height: 1.4;
        }
        [data-testid="stMain"] [data-testid="stVerticalBlockBorderWrapper"] {
            background-color: #FFFFFF;
            border: 1px solid #D5DCE5;
            border-radius: 8px;
        }
        [data-testid="stSidebar"] button[kind="primary"] {
            background-color: #BD88B9 !important;
            color: #290723 !important;
            font-weight: 700 !important;
            border: 0 !important;
        }
        @media (max-width: 1200px) {
            .ux-summary-grid {
                grid-template-columns: repeat(3, minmax(0, 1fr));
            }
        }
        @media (max-width: 760px) {
            .ux-summary-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
        @media (max-width: 400px) {
            .ux-summary-grid {
                grid-template-columns: minmax(0, 1fr);
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


# =============================
#   DATE & PAIR HELPERS
# =============================
def get_iso_week_count(year: int) -> int:
    """Return total number of ISO weeks (52 or 53) for the given calendar year."""
    return date(int(year), 12, 28).isocalendar()[1]


def resolve_investigation_dates(
    year: int,
    mode: str,
    selected_day: date | None = None,
    selected_week: int = 1,
    selected_month: int = 1,
    custom_start: date | None = None,
    custom_end: date | None = None,
) -> tuple[date, date]:
    """Resolve inclusive start and end calendar dates for the chosen drill-down mode."""
    yr = int(year)
    if mode == "Single Day":
        day_val = selected_day if selected_day is not None else date(yr, 1, 1)
        return day_val, day_val

    if mode == "Week":
        max_weeks = get_iso_week_count(yr)
        wk = max(1, min(int(selected_week), max_weeks))
        return date.fromisocalendar(yr, wk, 1), date.fromisocalendar(yr, wk, 7)

    if mode == "Month":
        mo = max(1, min(int(selected_month), 12))
        last_day = calendar.monthrange(yr, mo)[1]
        return date(yr, mo, 1), date(yr, mo, last_day)

    start_val = custom_start if custom_start is not None else date(yr, 1, 1)
    end_val = custom_end if custom_end is not None else date(yr, 12, 31)
    return start_val, end_val


def to_datetime_bounds(start_d: date, end_d: date) -> tuple[datetime, datetime]:
    """Convert inclusive start and end dates into full-day datetime boundaries."""
    return (
        datetime.combine(start_d, time(0, 0, 0)),
        datetime.combine(end_d, time(23, 59, 59)),
    )


def resolve_pair_selection(
    preset: str,
    custom_pairs: list[int] | tuple[int, ...],
) -> tuple[list[int], str]:
    """Resolve Bid/Offer pair preset or custom list into pair ID filter and summary text."""
    if preset == "Pair -1":
        return [-1], "Pair -1"
    if preset == "Pair +1":
        return [1], "Pair +1"
    if preset == "Pairs -1 and +1":
        return [-1, 1], "Pairs -1 and +1"
    if preset == "All pairs":
        return [], "All pairs"

    cleaned = [int(p) for p in custom_pairs]
    label = ", ".join(str(p) for p in cleaned) if cleaned else "None"
    return cleaned, label


def resolve_bmu_fuel_summary(
    bmus: list[str] | tuple[str, ...],
    stakeholders_df: pd.DataFrame,
    selected_fuels: list[str] | tuple[str, ...],
) -> str:
    """Resolve fuel types associated with the selected BMUs from stakeholder metadata."""
    if (
        stakeholders_df is not None
        and not stakeholders_df.empty
        and {"BMU ID", "sheetName"}.issubset(stakeholders_df.columns)
    ):
        matched = stakeholders_df[
            stakeholders_df["BMU ID"].astype(str).isin([str(b) for b in bmus])
        ]
        fuels = [
            str(f)
            for f in matched["sheetName"].dropna().unique().tolist()
            if str(f).strip()
        ]
        if fuels:
            return ", ".join(fuels)

    if selected_fuels:
        return ", ".join(str(f) for f in selected_fuels)
    return "All fuel types"


# =============================
#   TIMING & CACHED HELPERS
# =============================
@contextmanager
def timed_step(name: str, timings: dict[str, float]):
    started = perf_counter()
    try:
        yield
    finally:
        timings[name] = perf_counter() - started


def _record_source_diagnostic(
    source_name: str,
    loaded: bool,
    df: pd.DataFrame = None,
    filtered_df: pd.DataFrame = None,
    timestamp_col: str = None,
    load_s: float = 0.0,
    prep_s: float = 0.0,
    render_s: float = 0.0,
    message: str = "OK",
):
    if "source_diagnostics" not in st.session_state:
        st.session_state["source_diagnostics"] = {}

    if not loaded or df is None:
        st.session_state["source_diagnostics"][source_name] = {
            "Source Name": source_name,
            "Status": "Not Loaded",
            "Load Duration (s)": round(load_s, 4),
            "Prep Duration (s)": round(prep_s, 4),
            "Chart Render Duration (s)": round(render_s, 4),
            "Total Rows": 0,
            "Selected-BMU Rows": 0,
            "Min Timestamp": None,
            "Max Timestamp": None,
            "Last Loaded (UTC)": None,
            "Details": message,
        }
        return

    target_df = filtered_df if filtered_df is not None else df
    min_ts = None
    max_ts = None
    if (
        timestamp_col
        and timestamp_col in target_df.columns
        and not target_df.empty
        and target_df[timestamp_col].notna().any()
    ):
        ts_series = pd.to_datetime(target_df[timestamp_col], errors="coerce").dropna()
        if not ts_series.empty:
            min_ts = str(ts_series.min())
            max_ts = str(ts_series.max())

    st.session_state["source_diagnostics"][source_name] = {
        "Source Name": source_name,
        "Status": "Loaded",
        "Load Duration (s)": round(load_s, 4),
        "Prep Duration (s)": round(prep_s, 4),
        "Chart Render Duration (s)": round(render_s, 4),
        "Total Rows": len(df),
        "Selected-BMU Rows": len(target_df),
        "Min Timestamp": min_ts,
        "Max Timestamp": max_ts,
        "Last Loaded (UTC)": datetime.now(timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S UTC"
        ),
        "Details": (
            "No rows matched submitted BMUs and date range."
            if len(target_df) == 0
            else message
        ),
    }


@st.cache_data(ttl=3600, show_spinner=False)
def _prepare_operational_with_mapping(
    operational_df: pd.DataFrame,
    bmu_mapping_df: pd.DataFrame,
) -> pd.DataFrame:
    df = operational_df.copy()
    df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])
    if (
        bmu_mapping_df is not None
        and not bmu_mapping_df.empty
        and {"BMU_ID", "ELEXON_BMU_ID"}.issubset(bmu_mapping_df.columns)
    ):
        df = df.merge(bmu_mapping_df, on="BMU_ID", how="left")
    elif "ELEXON_BMU_ID" not in df.columns:
        df["ELEXON_BMU_ID"] = pd.NA
    return df


@st.cache_data(ttl=3600, show_spinner=False)
def _filter_operational_data(
    prepared_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    bmus_tuple: tuple[str, ...],
) -> pd.DataFrame:
    mask = (prepared_df["GMT_DATETIME"] >= start_dt) & (
        prepared_df["GMT_DATETIME"] <= end_dt
    )
    if bmus_tuple:
        mask = mask & prepared_df["BMU_ID"].isin(bmus_tuple)
    return prepared_df.loc[mask].sort_values("GMT_DATETIME")


@st.cache_data(ttl=3600, show_spinner=False)
def _build_wholesale_comparison_table(
    filtered_wholesale_df: pd.DataFrame,
    filtered_bid_offer_df: pd.DataFrame,
) -> pd.DataFrame:
    if filtered_bid_offer_df is None or filtered_bid_offer_df.empty:
        return filtered_wholesale_df.copy()

    bid_offer_pivot_df = filtered_bid_offer_df.pivot_table(
        index="GMT_DATETIME",
        columns=["BMU_ID", "BOPAIR_ID"],
        values=["BID_PRICE_GBP_MWH", "OFFER_PRICE_GBP_MWH"],
        aggfunc="first",
    )

    bid_offer_pivot_df.columns = [
        (
            f"{bmu} | Pair {pair_id} | "
            f"{'Bid' if metric == 'BID_PRICE_GBP_MWH' else 'Offer'}"
        )
        for metric, bmu, pair_id in bid_offer_pivot_df.columns
    ]

    bid_offer_pivot_df = bid_offer_pivot_df.reset_index()

    if filtered_wholesale_df is None or filtered_wholesale_df.empty:
        return bid_offer_pivot_df

    return (
        filtered_wholesale_df.copy()
        .merge(
            bid_offer_pivot_df,
            left_on="dateTime",
            right_on="GMT_DATETIME",
            how="left",
        )
        .drop(columns=["GMT_DATETIME"], errors="ignore")
    )


def _build_operational_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    show_remit: bool,
    remit_df: pd.DataFrame | None,
) -> go.Figure:
    """Build the operational Plotly figure for a single BMU."""
    operational_fig = go.Figure()

    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["MAXIMUM_EXPORT_LIMIT"],
        "lines",
        "MEL",
        line=dict(width=3, dash="dot"),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["MAXIMUM_IMPORT_LIMIT"],
        "lines",
        "MIL",
        line=dict(width=3),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["STABLEEXPORTLIMIT"],
        "lines",
        "SEL",
        line=dict(width=3, dash="dot"),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["FINAL_PHYSICAL_NOTIFICATION_MW"],
        "lines",
        "FPN",
        line=dict(width=3),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["OPERATIONAL_METERED_OUTPUT_MW"],
        "lines",
        "Metered Output",
        line=dict(width=3, dash="dot"),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN4HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "4H PN",
        line=dict(width=3),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN6HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "6H PN",
        line=dict(width=3),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN8HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "8H PN",
        line=dict(width=3),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN12HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "12H PN",
        line=dict(width=3),
    )
    figTrace(
        operational_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN18HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "18H PN",
        line=dict(width=3),
    )

    if show_remit and remit_df is not None and not remit_df.empty:
        r_df = remit_df.copy()
        r_df["eventStartTime"] = pd.to_datetime(r_df["eventStartTime"]).dt.tz_localize(
            None
        )
        r_df["eventEndTime"] = pd.to_datetime(r_df["eventEndTime"]).dt.tz_localize(None)

        for _, remit in r_df.iterrows():
            if remit["eventEndTime"] < start_dt or remit["eventStartTime"] > end_dt:
                continue

            overlay_start = max(remit["eventStartTime"], start_dt)
            overlay_end = min(remit["eventEndTime"], end_dt)

            normal_capacity = remit["normalCapacity"]
            unavailable_capacity = remit["unavailableCapacity"]
            available_capacity = normal_capacity - unavailable_capacity

            operational_fig.add_shape(
                type="rect",
                x0=overlay_start,
                x1=overlay_end,
                y0=available_capacity,
                y1=normal_capacity,
                fillcolor=REMIT_FILL_COLOR,
                opacity=0.35,
                line_width=0,
            )

            operational_fig.add_trace(
                go.Scatter(
                    x=[overlay_start, overlay_end],
                    y=[available_capacity, available_capacity],
                    mode="lines",
                    name=(
                        f"REMIT | Avail: {available_capacity} MW "
                        f"(-{unavailable_capacity} MW) | "
                        f"{remit['eventStartTime'].strftime('%d %b')} -> "
                        f"{remit['eventEndTime'].strftime('%d %b')}"
                    ),
                    line=dict(
                        color=REMIT_LINE_COLOR,
                        width=2,
                    ),
                )
            )

    operational_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        title=f"{bmu} Operational Data",
        xaxis_title="Date/Time",
        yaxis_title="MW",
        height=500,
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    return operational_fig


def _build_wholesale_figure(
    bmu: str,
    filtered_wholesale_df: pd.DataFrame,
    show_bid_offer: bool,
    selected_bod_df: pd.DataFrame,
    pair_ids: list[int],
) -> go.Figure:
    """Build the wholesale price and Bid/Offer overlay Plotly figure for a single BMU."""
    wholesale_fig = go.Figure()

    if filtered_wholesale_df is not None and not filtered_wholesale_df.empty:
        figTrace(
            wholesale_fig,
            filtered_wholesale_df["dateTime"],
            filtered_wholesale_df["ID_Forecast £/MWh"],
            "lines",
            "ID Forecast",
            line=dict(width=3),
        )
        figTrace(
            wholesale_fig,
            filtered_wholesale_df["dateTime"],
            filtered_wholesale_df["DA_Nordpool £/MWh"],
            "lines",
            "DA Forecast",
            line=dict(width=3),
        )

    if show_bid_offer and selected_bod_df is not None and not selected_bod_df.empty:
        bmu_bod_df = selected_bod_df[selected_bod_df["BMU_ID"] == bmu]
        for pair_id in pair_ids:
            pair_df = bmu_bod_df[bmu_bod_df["BOPAIR_ID"] == pair_id].sort_values(
                "GMT_DATETIME"
            )
            if pair_df.empty:
                continue

            figTrace(
                wholesale_fig,
                pair_df["GMT_DATETIME"],
                pair_df["BID_PRICE_GBP_MWH"],
                "lines",
                f"Pair {pair_id} BID",
                line=dict(width=3, dash="dot"),
            )
            figTrace(
                wholesale_fig,
                pair_df["GMT_DATETIME"],
                pair_df["OFFER_PRICE_GBP_MWH"],
                "lines",
                f"Pair {pair_id} OFFER",
                line=dict(width=3, dash="dot"),
            )

    wholesale_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        title=f"{bmu} Wholesale Data",
        xaxis_title="Date/Time",
        yaxis_title="£/MWh",
        height=500,
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    return wholesale_fig


def _build_dynamic_params_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
) -> go.Figure:
    """Build the Dynamic Parameters Plotly figure for a single BMU."""
    dynamic_fig = go.Figure()

    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGENOTICETODEVIATEFROMZERO_MINS"],
        "lines",
        "Average NDZ",
        line=dict(width=3),
    )
    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGEMINIMUMZEROTIME_MINS"],
        "lines",
        "Average MZT",
        line=dict(width=3),
    )
    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGEMINIMUMNONZEROTIME_MINS"],
        "lines",
        "Average MNZT",
        line=dict(width=3),
    )

    dynamic_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        title=f"{bmu} Dynamic Parameters",
        xaxis_title="Date/Time",
        yaxis_title="Time (Minutes)",
        height=500,
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    dynamic_fig.update_xaxes(range=[start_dt, end_dt])
    return dynamic_fig


def _render_summary_cards(fields: list[tuple[str, str]]) -> None:
    """Render individual responsive summary cards across the top of the dashboard."""
    cards_html = "".join(
        f'<div class="ux-summary-card">'
        f"<span>{html.escape(str(label))}</span>"
        f"<strong>{html.escape(str(val))}</strong>"
        f"</div>"
        for label, val in fields
    )
    st.markdown(
        f'<section class="ux-summary-grid" aria-label="Loaded investigation">'
        f"{cards_html}"
        f"</section>",
        unsafe_allow_html=True,
    )


def _render_notice(text: str) -> None:
    """Render a clean corporate informational banner."""
    st.markdown(
        f'<div class="ux-notice">{html.escape(text)}</div>',
        unsafe_allow_html=True,
    )


def main() -> None:
    _inject_ux_styles()

    st.markdown(
        """
        <div class="ux-head">
            <div>
                <h2>Market Monitoring - Price Dashboard</h2>
                <p class="ux-muted">Operational behaviour and prices together for each BMU.</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if "step_timings" not in st.session_state:
        st.session_state["step_timings"] = {}
    timings = st.session_state["step_timings"]

    # =============================
    #     GET STAKEHOLDER DATA
    # =============================
    try:
        with timed_step("stakeholder_metadata_load", timings):
            stakeholders, fuelTypes, leadParties = getStakeholders()
        _record_source_diagnostic(
            "Stakeholder Metadata",
            loaded=True,
            df=stakeholders,
            load_s=timings.get("stakeholder_metadata_load", 0.0),
        )
    except Exception as error:
        _record_source_diagnostic(
            "Stakeholder Metadata",
            loaded=False,
            load_s=timings.get("stakeholder_metadata_load", 0.0),
            message=str(error),
        )
        st.error("Stakeholder metadata could not be loaded.")
        st.exception(error)
        stakeholders = pd.DataFrame(columns=["sheetName", "Lead Party", "BMU ID"])
        fuelTypes = []
        leadParties = []

    # =============================
    #      SIDEBAR FILTERS
    # =============================
    now_dt = datetime.now()
    current_year = now_dt.year

    with st.sidebar:
        st.markdown(
            '<div class="ux-sidebar-title">Select units, period and overlays</div>',
            unsafe_allow_html=True,
        )

        draftFuelType = st.multiselect(
            "Fuel types (optional)",
            options=fuelTypes,
        )

        bmusInSelectedFuelType = stakeholders.copy()
        if draftFuelType and "sheetName" in bmusInSelectedFuelType.columns:
            bmusInSelectedFuelType = bmusInSelectedFuelType[
                bmusInSelectedFuelType["sheetName"].isin(draftFuelType)
            ]

        portfoliosInSelectedFuelType = (
            sorted(
                bmusInSelectedFuelType["Lead Party"]
                .dropna()
                .astype(str)
                .unique()
                .tolist()
            )
            if "Lead Party" in bmusInSelectedFuelType.columns
            else []
        )

        draftPortfolio = st.multiselect(
            "Portfolio (optional)",
            options=portfoliosInSelectedFuelType,
        )

        bmusInSelectedPortfolio = bmusInSelectedFuelType.copy()
        if draftPortfolio and "Lead Party" in bmusInSelectedPortfolio.columns:
            bmusInSelectedPortfolio = bmusInSelectedPortfolio[
                bmusInSelectedPortfolio["Lead Party"].isin(draftPortfolio)
            ]

        filtered_bmus = (
            sorted(
                bmusInSelectedPortfolio["BMU ID"].dropna().astype(str).unique().tolist()
            )
            if "BMU ID" in bmusInSelectedPortfolio.columns
            else []
        )

        # Preserve any already-selected BMUs across filter changes so analysts can
        # freely combine units across different technologies or portfolios.
        existing_selected_bmus = [
            b
            for b in st.session_state.get("sidebar_bmus", [])
            if "BMU ID" not in stakeholders.columns
            or stakeholders.empty
            or b in set(stakeholders["BMU ID"].dropna().astype(str))
        ]
        bmu_options = sorted(set(filtered_bmus) | set(existing_selected_bmus))

        draftBMUs = st.multiselect(
            "BMUs (up to 4)",
            options=bmu_options,
            max_selections=4,
            key="sidebar_bmus",
        )

        st.markdown(
            '<p class="ux-sidebar-help">Leave fuel unselected to compare technologies.</p>',
            unsafe_allow_html=True,
        )

        # =============================
        #       DATE SELECTION
        # =============================
        selectedYear = int(
            st.number_input(
                "Year",
                min_value=2000,
                max_value=2100,
                value=current_year,
                step=1,
            )
        )

        dateMode = st.selectbox(
            "Drill down",
            options=["Single Day", "Week", "Month", "Custom Date Range"],
            index=1,
            key="date_mode_selector",
        )

        selectedDay = None
        selectedWeek = 1
        selectedMonth = now_dt.month if selectedYear == current_year else 1
        customStartDate = date(selectedYear, 1, 1)
        customEndDate = (
            now_dt.date()
            if selectedYear == current_year
            else date(selectedYear, 12, 31)
        )

        if dateMode == "Single Day":
            default_anchor = (
                now_dt.date()
                if selectedYear == current_year
                else date(selectedYear, 1, 1)
            )
            selectedDay = st.date_input(
                "Select day",
                value=default_anchor,
                min_value=date(selectedYear, 1, 1),
                max_value=date(selectedYear, 12, 31),
                format="DD/MM/YYYY",
            )
        elif dateMode == "Week":
            max_weeks = get_iso_week_count(selectedYear)
            default_week = (
                min(max_weeks, now_dt.isocalendar()[1])
                if selectedYear == current_year
                else 1
            )
            selectedWeek = st.selectbox(
                "Week number (ISO, Monday-Sunday)",
                options=list(range(1, max_weeks + 1)),
                index=max(0, default_week - 1),
                format_func=lambda w: f"Week {w}",
            )
        elif dateMode == "Month":
            selectedMonth = st.selectbox(
                "Month",
                options=list(range(1, 13)),
                index=max(0, selectedMonth - 1),
                format_func=lambda m: MONTH_NAMES[m],
            )

        if dateMode == "Custom Date Range":
            col_from, col_to = st.columns(2)
            with col_from:
                customStartDate = st.date_input(
                    "Start date",
                    value=customStartDate,
                    min_value=date(2000, 1, 1),
                    max_value=date(2100, 12, 31),
                    format="DD/MM/YYYY",
                )
            with col_to:
                customEndDate = st.date_input(
                    "End date",
                    value=customEndDate,
                    min_value=date(2000, 1, 1),
                    max_value=date(2100, 12, 31),
                    format="DD/MM/YYYY",
                )
            resolvedStartDate, resolvedEndDate = resolve_investigation_dates(
                year=selectedYear,
                mode=dateMode,
                custom_start=customStartDate,
                custom_end=customEndDate,
            )
            date_help_text = (
                "Custom range supports cross-year historical periods. "
                "Dates are inclusive."
            )
        else:
            resolvedStartDate, resolvedEndDate = resolve_investigation_dates(
                year=selectedYear,
                mode=dateMode,
                selected_day=selectedDay,
                selected_week=selectedWeek,
                selected_month=selectedMonth,
            )
            col_from, col_to = st.columns(2)
            with col_from:
                st.date_input(
                    "Start date",
                    value=resolvedStartDate,
                    disabled=True,
                    format="DD/MM/YYYY",
                    key=f"readonly_start_{dateMode}_{resolvedStartDate.isoformat()}",
                )
            with col_to:
                st.date_input(
                    "End date",
                    value=resolvedEndDate,
                    disabled=True,
                    format="DD/MM/YYYY",
                    key=f"readonly_end_{dateMode}_{resolvedEndDate.isoformat()}",
                )
            date_help_text = (
                "ISO week, Monday-Sunday. Boundary weeks may cross calendar years."
                if dateMode == "Week"
                else "Dates are inclusive. Year defaults to the current year when opened."
            )

        st.markdown(
            f'<p class="ux-sidebar-help">{html.escape(date_help_text)}</p>',
            unsafe_allow_html=True,
        )

        # =============================
        #    INFORMATION OVERLAYS
        # =============================
        st.markdown(
            '<div class="ux-sidebar-section-label">Information overlays</div>',
            unsafe_allow_html=True,
        )

        draftShowREMITOverlay = st.checkbox(
            "REMIT on operational charts",
            value=False,
        )
        draftShowBidOfferOverlay = st.checkbox(
            "Bid/offer lines on price charts",
            value=False,
        )

        draftPairPreset = st.selectbox(
            "Bid/offer pairs",
            options=PAIR_PRESET_OPTIONS,
            index=0,
            key="pair_preset_selector",
        )

        knownPairIDs = st.session_state.get(
            "available_pair_ids", [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]
        )
        if not knownPairIDs:
            knownPairIDs = [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]

        draftCustomPairs: list[int] = []
        if draftPairPreset == "Custom selection":
            default_custom = [-1] if -1 in knownPairIDs else knownPairIDs[:1]
            draftCustomPairs = st.multiselect(
                "Select pairs",
                options=knownPairIDs,
                default=default_custom,
            )

        resolvedPairIDs, pairSummaryLabel = resolve_pair_selection(
            draftPairPreset, draftCustomPairs
        )

        loadInvestigationClicked = st.button(
            "Load investigation",
            type="primary",
            width="stretch",
        )

        sidebar_error = None
        if loadInvestigationClicked:
            if not draftBMUs or len(draftBMUs) > 4:
                sidebar_error = "Select between 1 and 4 BMUs."
            elif resolvedStartDate > resolvedEndDate:
                sidebar_error = (
                    "Enter valid dates with Start date no later than End date."
                )
            elif (
                draftShowBidOfferOverlay
                and draftPairPreset == "Custom selection"
                and not resolvedPairIDs
            ):
                sidebar_error = "Select at least one custom Bid/Offer pair."
            else:
                start_dt, end_dt = to_datetime_bounds(
                    resolvedStartDate, resolvedEndDate
                )
                st.session_state["submitted_request"] = {
                    "showREMITOverlay": bool(draftShowREMITOverlay),
                    "showBidOfferOverlay": bool(draftShowBidOfferOverlay),
                    "datetimeRange": (start_dt, end_dt),
                    "startDateStr": resolvedStartDate.isoformat(),
                    "endDateStr": resolvedEndDate.isoformat(),
                    "selectFuelType": tuple(draftFuelType),
                    "selectPortfolio": tuple(draftPortfolio),
                    "selectBMUs": tuple(draftBMUs),
                    "pairPreset": draftPairPreset,
                    "pairIDChoices": tuple(resolvedPairIDs),
                    "pairSummaryLabel": pairSummaryLabel,
                }

        if sidebar_error:
            st.error(sidebar_error)

        # =============================
        #    COMPACT FOOTER BRANDING
        # =============================
        st.markdown('<div class="ux-sidebar-foot"></div>', unsafe_allow_html=True)
        st.selectbox(
            "Dashboards",
            options=["Market Monitoring"],
            index=0,
        )
        logo_path = Path(__file__).resolve().parents[1] / "assets" / "logo.png"
        if logo_path.is_file():
            st.image(str(logo_path), width=110)
        else:
            st.markdown("**NESO**")
        st.markdown(
            '<small class="ux-sidebar-foot-note">National Energy System Operator</small>',
            unsafe_allow_html=True,
        )

    # =============================
    #    SUBMITTED EXECUTION GATE
    # =============================
    submitted = st.session_state.get("submitted_request")
    if submitted is None:
        st.info(
            "Select up to 4 BMUs, choose a period and overlays in the sidebar, "
            "then click 'Load investigation'."
        )
        st.stop()
        return

    # Detect uncommitted sidebar changes relative to the loaded investigation
    draft_bounds = to_datetime_bounds(resolvedStartDate, resolvedEndDate)
    selections_changed = (
        tuple(draftBMUs) != tuple(submitted["selectBMUs"])
        or tuple(draftFuelType) != tuple(submitted["selectFuelType"])
        or tuple(draftPortfolio) != tuple(submitted["selectPortfolio"])
        or draft_bounds != tuple(submitted["datetimeRange"])
        or bool(draftShowREMITOverlay) != bool(submitted["showREMITOverlay"])
        or bool(draftShowBidOfferOverlay) != bool(submitted["showBidOfferOverlay"])
        or (
            bool(draftShowBidOfferOverlay)
            and (
                draftPairPreset != submitted.get("pairPreset")
                or tuple(resolvedPairIDs) != tuple(submitted["pairIDChoices"])
            )
        )
    )
    if selections_changed:
        st.markdown(
            '<div class="ux-pending">'
            "Selections changed. Load investigation to update the displayed evidence."
            "</div>",
            unsafe_allow_html=True,
        )

    showREMITOverlay = submitted["showREMITOverlay"]
    showBidOfferOverlay = submitted["showBidOfferOverlay"]
    datetimeRange = submitted["datetimeRange"]
    selectBMUs = list(submitted["selectBMUs"])
    selectFuelType = list(submitted["selectFuelType"])
    selectPortfolio = list(submitted["selectPortfolio"])
    requestedPairIDs = list(submitted["pairIDChoices"])
    pairSummaryLabel = submitted.get("pairSummaryLabel", "Pair -1")
    startDateStr = submitted.get(
        "startDateStr", datetimeRange[0].strftime("%Y-%m-%d")
    )
    endDateStr = submitted.get("endDateStr", datetimeRange[1].strftime("%Y-%m-%d"))

    if not selectBMUs:
        st.warning("Select between 1 and 4 BMUs and click 'Load investigation'.")
        st.stop()
        return

    # =============================
    #    INVESTIGATION SUMMARY
    # =============================
    summary_fields = [
        ("BMUs", ", ".join(selectBMUs)),
        (
            "Fuel types",
            resolve_bmu_fuel_summary(selectBMUs, stakeholders, selectFuelType),
        ),
        (
            "Portfolio",
            ", ".join(selectPortfolio) if selectPortfolio else "All portfolios",
        ),
        ("Loaded period", f"{startDateStr} to {endDateStr}"),
        ("Bid/offer", pairSummaryLabel if showBidOfferOverlay else "Off"),
    ]
    _render_summary_cards(summary_fields)

    # =============================
    #    LOAD INVESTIGATION DATA
    # =============================
    with timed_step("complete_submitted_request_duration", timings):

        # 1. Operational Data & Elexon BMU Mapping
        filteredOperationalData = pd.DataFrame()
        operational_load_error = None
        try:
            with timed_step("operational_data_load", timings):
                operationalData = getOperationalData()
        except Exception as error:
            operational_load_error = error
            _record_source_diagnostic(
                "NED Operational Data",
                loaded=False,
                load_s=timings.get("operational_data_load", 0.0),
                message=str(error),
            )
            operationalData = None

        if operationalData is not None:
            with timed_step("bmu_mapping_load", timings):
                bmuMappingDF = getBMUMapping()
            _record_source_diagnostic(
                "Elexon BMU Mapping",
                loaded=bmuMappingDF is not None,
                df=bmuMappingDF,
                load_s=timings.get("bmu_mapping_load", 0.0),
            )

            with timed_step("operational_data_preparation", timings):
                preparedOperationalData = _prepare_operational_with_mapping(
                    operationalData, bmuMappingDF
                )
                if (
                    not preparedOperationalData.empty
                    and "GMT_DATETIME" in preparedOperationalData.columns
                ):
                    st.session_state["operational_min_dt"] = (
                        preparedOperationalData["GMT_DATETIME"].min().to_pydatetime()
                    )
                    st.session_state["operational_max_dt"] = (
                        preparedOperationalData["GMT_DATETIME"].max().to_pydatetime()
                    )

                filteredOperationalData = _filter_operational_data(
                    preparedOperationalData,
                    datetimeRange[0],
                    datetimeRange[1],
                    tuple(selectBMUs),
                )

            _record_source_diagnostic(
                "NED Operational Data",
                loaded=True,
                df=operationalData,
                filtered_df=filteredOperationalData,
                timestamp_col="GMT_DATETIME",
                load_s=timings.get("operational_data_load", 0.0),
                prep_s=timings.get("operational_data_preparation", 0.0),
            )

        # 2. REMIT Data (Conditional on showREMITOverlay)
        remitByBMU: dict[str, pd.DataFrame] = {}
        missingRemitMappingBMUs: list[str] = []
        remitTotalLoadTime = 0.0
        remitRowCount = 0

        if showREMITOverlay and not filteredOperationalData.empty:
            for bmu in selectBMUs:
                bmu_rows = filteredOperationalData[
                    filteredOperationalData["BMU_ID"] == bmu
                ]
                if bmu_rows.empty:
                    continue
                elexonBMU = (
                    bmu_rows["ELEXON_BMU_ID"].iloc[0]
                    if "ELEXON_BMU_ID" in bmu_rows.columns
                    else None
                )
                if pd.notna(elexonBMU) and str(elexonBMU).strip():
                    t_remit = perf_counter()
                    remit_df = getRemit(
                        elexonBMU,
                        datetimeRange[0],
                        datetimeRange[1],
                    )
                    remitTotalLoadTime += perf_counter() - t_remit
                    if remit_df is not None and not remit_df.empty:
                        tagged_remit = remit_df.copy()
                        if "BMU_ID" not in tagged_remit.columns:
                            tagged_remit.insert(0, "BMU_ID", bmu)
                        remitByBMU[bmu] = tagged_remit
                        remitRowCount += len(tagged_remit)
                else:
                    missingRemitMappingBMUs.append(bmu)

        timings["remit_load_total"] = remitTotalLoadTime
        _record_source_diagnostic(
            "Elexon REMIT",
            loaded=showREMITOverlay,
            load_s=remitTotalLoadTime,
            message=(
                f"Loaded {remitRowCount} REMIT rows."
                if showREMITOverlay
                else "Skipped (REMIT overlay disabled)."
            ),
        )

        # 3. Wholesale Prices & Conditional Bid/Offer Data
        start_str = datetimeRange[0].strftime("%Y%m%d%H%M")
        end_str = datetimeRange[1].strftime("%Y%m%d%H%M")

        with timed_step("wholesale_api_load", timings):
            wholesalePrices = getWholesalePrices(start_str, end_str)

        filteredWholesalePrices = pd.DataFrame()
        if wholesalePrices is not None and not wholesalePrices.empty:
            filteredWholesalePrices = wholesalePrices[
                (wholesalePrices["dateTime"] >= datetimeRange[0])
                & (wholesalePrices["dateTime"] <= datetimeRange[1])
            ]
            _record_source_diagnostic(
                "EnAppSys Wholesale Prices",
                loaded=True,
                df=wholesalePrices,
                filtered_df=filteredWholesalePrices,
                timestamp_col="dateTime",
                load_s=timings.get("wholesale_api_load", 0.0),
            )
        else:
            _record_source_diagnostic(
                "EnAppSys Wholesale Prices",
                loaded=False,
                load_s=timings.get("wholesale_api_load", 0.0),
                message="No wholesale price data returned for submitted date range.",
            )

        selectedBodBMUsDF = pd.DataFrame()
        pairIDChoices: list[int] = []
        bid_offer_load_error = None

        if showBidOfferOverlay:
            try:
                with timed_step("bid_offer_data_load", timings):
                    bidOfferData = getBidOfferData()
            except Exception as error:
                bid_offer_load_error = error
                _record_source_diagnostic(
                    "NED Bid/Offer Data",
                    loaded=False,
                    load_s=timings.get("bid_offer_data_load", 0.0),
                    message=str(error),
                )
                bidOfferData = None

            if bidOfferData is not None:
                with timed_step("bid_offer_preparation", timings):
                    filteredBidOfferData = bidOfferData[
                        (bidOfferData["GMT_DATETIME"] >= datetimeRange[0])
                        & (bidOfferData["GMT_DATETIME"] <= datetimeRange[1])
                    ]
                    selectedBodBMUsDF = filteredBidOfferData[
                        filteredBidOfferData["BMU_ID"].isin(selectBMUs)
                    ]
                    availablePairs = sorted(
                        selectedBodBMUsDF["BOPAIR_ID"].dropna().unique().tolist()
                    )
                    if availablePairs:
                        st.session_state["available_pair_ids"] = availablePairs
                    pairIDChoices = (
                        [p for p in availablePairs if p in requestedPairIDs]
                        if requestedPairIDs
                        else availablePairs
                    )

                _record_source_diagnostic(
                    "NED Bid/Offer Data",
                    loaded=True,
                    df=bidOfferData,
                    filtered_df=selectedBodBMUsDF,
                    timestamp_col="GMT_DATETIME",
                    load_s=timings.get("bid_offer_data_load", 0.0),
                    prep_s=timings.get("bid_offer_preparation", 0.0),
                )
        else:
            _record_source_diagnostic(
                "NED Bid/Offer Data",
                loaded=False,
                message="Skipped (Bid/Offer overlay disabled).",
            )

        # 4. BOA Instructions Data
        bOAInstructionsData = None
        boa_load_error = None
        try:
            with timed_step("boa_data_load", timings):
                bOAInstructionsData = getBOAInstructionsData()
        except Exception as error:
            boa_load_error = error
            _record_source_diagnostic(
                "NED BOA Instructions",
                loaded=False,
                load_s=timings.get("boa_data_load", 0.0),
                message=str(error),
            )

        # =============================
        #    TABS & ANALYTICAL VIEWS
        # =============================
        (
            tab_unit_prices,
            tab_dynamic,
            tab_ancillary,
            tab_boa,
            tab_strike,
            tab_roc,
            tab_tables,
        ) = st.tabs(
            [
                "Unit & Prices",
                "Dynamic Parameters",
                "Ancillary Services",
                "BOA Instructions",
                "Strike Prices",
                "ROC",
                "Data Tables",
            ]
        )

        # -----------------------------
        # TAB 1: UNIT & PRICES
        # -----------------------------
        with tab_unit_prices:
            if operational_load_error is not None:
                st.error("Operational data could not be loaded.")
                st.exception(operational_load_error)
            if bid_offer_load_error is not None:
                st.error("Bid/Offer data could not be loaded.")
                st.exception(bid_offer_load_error)

            with timed_step("unit_prices_chart_render", timings):
                for bmu in selectBMUs:
                    st.subheader(bmu)
                    col_op, col_price = st.columns(2)

                    with col_op:
                        with st.container(border=True):
                            bmu_op_df = (
                                filteredOperationalData[
                                    filteredOperationalData["BMU_ID"] == bmu
                                ].sort_values("GMT_DATETIME")
                                if not filteredOperationalData.empty
                                else pd.DataFrame()
                            )

                            if bmu_op_df.empty:
                                st.info(
                                    f"No operational data was found for BMU '{bmu}' in the selected date range."
                                )
                            else:
                                if bmu in missingRemitMappingBMUs:
                                    st.warning(
                                        f"{bmu}: No Elexon BMU mapping available; skipping REMIT lookup."
                                    )
                                op_fig = _build_operational_figure(
                                    bmu=bmu,
                                    bmu_df=bmu_op_df,
                                    start_dt=datetimeRange[0],
                                    end_dt=datetimeRange[1],
                                    show_remit=showREMITOverlay,
                                    remit_df=remitByBMU.get(bmu),
                                )
                                st.plotly_chart(
                                    op_fig,
                                    width="stretch",
                                    key=f"op_chart_{bmu}",
                                )

                    with col_price:
                        with st.container(border=True):
                            has_wholesale = not filteredWholesalePrices.empty
                            has_bmu_bod = (
                                showBidOfferOverlay
                                and not selectedBodBMUsDF.empty
                                and not selectedBodBMUsDF[
                                    selectedBodBMUsDF["BMU_ID"] == bmu
                                ].empty
                            )
                            if not has_wholesale and not has_bmu_bod:
                                st.info(
                                    "No wholesale price data was found for the submitted date range."
                                )
                            else:
                                price_fig = _build_wholesale_figure(
                                    bmu=bmu,
                                    filtered_wholesale_df=filteredWholesalePrices,
                                    show_bid_offer=showBidOfferOverlay,
                                    selected_bod_df=selectedBodBMUsDF,
                                    pair_ids=pairIDChoices,
                                )
                                st.plotly_chart(
                                    price_fig,
                                    width="stretch",
                                    key=f"price_chart_{bmu}",
                                )

        # -----------------------------
        # TAB 2: DYNAMIC PARAMETERS
        # -----------------------------
        dynamicParamDF = pd.DataFrame()
        with tab_dynamic:
            if operational_load_error is not None:
                st.error("Operational data could not be loaded.")
                st.exception(operational_load_error)
            elif filteredOperationalData.empty:
                st.info(
                    "No dynamic parameters data was found for the submitted BMUs and date range."
                )
            else:
                with timed_step("dynamic_params_chart_render", timings):
                    graphsPerRow = 2
                    dynamic_frames = []

                    for rowStart in range(0, len(selectBMUs), graphsPerRow):
                        currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]
                        cols = (
                            [st.container()]
                            if len(currentBMUs) == 1
                            else st.columns(graphsPerRow)
                        )

                        for col, bmu in zip(cols, currentBMUs):
                            with col:
                                bmu_df = filteredOperationalData[
                                    filteredOperationalData["BMU_ID"] == bmu
                                ].sort_values("GMT_DATETIME")

                                with st.container(border=True):
                                    if bmu_df.empty:
                                        st.info(
                                            f"No dynamic parameters data found for BMU '{bmu}' in the selected date range."
                                        )
                                        continue

                                    dynamic_frames.append(
                                        bmu_df[
                                            [
                                                "GMT_DATETIME",
                                                "BMU_ID",
                                                "AVERAGENOTICETODEVIATEFROMZERO_MINS",
                                                "AVERAGEMINIMUMZEROTIME_MINS",
                                                "AVERAGEMINIMUMNONZEROTIME_MINS",
                                            ]
                                        ]
                                    )
                                    dyn_fig = _build_dynamic_params_figure(
                                        bmu=bmu,
                                        bmu_df=bmu_df,
                                        start_dt=datetimeRange[0],
                                        end_dt=datetimeRange[1],
                                    )
                                    st.plotly_chart(
                                        dyn_fig,
                                        width="stretch",
                                        key=f"dyn_chart_{bmu}",
                                    )

                    if dynamic_frames:
                        dynamicParamDF = pd.concat(
                            dynamic_frames,
                            ignore_index=True,
                        )

        # -----------------------------
        # TAB 3: ANCILLARY SERVICES
        # -----------------------------
        with tab_ancillary:
            st.subheader("Ancillary Services")
            _render_notice(
                "Ancillary Services: Not yet implemented. Graph planned; no fabricated service participation is shown."
            )

        # -----------------------------
        # TAB 4: BOA INSTRUCTIONS
        # -----------------------------
        with tab_boa:
            if boa_load_error is not None:
                st.error("BOA instructions data could not be loaded.")
                st.exception(boa_load_error)
            elif bOAInstructionsData is not None:
                with timed_step("boa_table_render", timings):
                    graphsPerRow = 2
                    boaMatchedFrames = []

                    for rowStart in range(0, len(selectBMUs), graphsPerRow):
                        currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]
                        cols = (
                            [st.container()]
                            if len(currentBMUs) == 1
                            else st.columns(graphsPerRow)
                        )

                        for col, bmu in zip(cols, currentBMUs):
                            with col:
                                filteredBOAInstructionsData = bOAInstructionsData[
                                    (bOAInstructionsData["BMU_ID"] == bmu)
                                    & (
                                        bOAInstructionsData["GMT_DATETIME"]
                                        >= datetimeRange[0]
                                    )
                                    & (
                                        bOAInstructionsData["GMT_DATETIME"]
                                        <= datetimeRange[1]
                                    )
                                ].sort_values(
                                    "GMT_DATETIME",
                                    ascending=False,
                                )

                                filteredBOAInstructionsData = (
                                    filteredBOAInstructionsData[
                                        [
                                            "GMT_DATETIME",
                                            "BMU_ID",
                                            "BOPAIR_ID",
                                            "BID_PRICE",
                                            "OFFER_PRICE",
                                            "CST_GROUP",
                                            "DIRECT_ACTION_COST",
                                        ]
                                    ]
                                )
                                boaMatchedFrames.append(filteredBOAInstructionsData)

                                with st.container(border=True):
                                    st.subheader(f"{bmu} BOA Instructions")
                                    if filteredBOAInstructionsData.empty:
                                        st.info(
                                            f"No BOA instructions found for BMU '{bmu}' in the submitted date range."
                                        )
                                    else:
                                        st.dataframe(
                                            filteredBOAInstructionsData,
                                            width="stretch",
                                        )

                    allFilteredBOA = (
                        pd.concat(boaMatchedFrames, ignore_index=True)
                        if boaMatchedFrames
                        else pd.DataFrame()
                    )
                    _record_source_diagnostic(
                        "NED BOA Instructions",
                        loaded=True,
                        df=bOAInstructionsData,
                        filtered_df=allFilteredBOA,
                        timestamp_col="GMT_DATETIME",
                        load_s=timings.get("boa_data_load", 0.0),
                        render_s=timings.get("boa_table_render", 0.0),
                    )

        # -----------------------------
        # TAB 5: STRIKE PRICES
        # -----------------------------
        with tab_strike:
            st.subheader("Strike Prices")
            _render_notice("Strike Prices: Not yet implemented.")

        # -----------------------------
        # TAB 6: ROC
        # -----------------------------
        with tab_roc:
            st.subheader("Wind ROC Mappings")
            _render_notice(
                "Dedicated ROC view. Existing ROC mapping content will appear here when implemented. No subsidy values or eligibility are assumed."
            )

        # -----------------------------
        # TAB 7: DATA TABLES
        # -----------------------------
        with tab_tables:
            datasetChoice = st.selectbox(
                "Dataset",
                options=[
                    "Operational",
                    "Wholesale / bid-offer",
                    "Dynamic Parameters",
                    "REMIT",
                ],
                index=0,
                key="dataset_table_selector",
            )

            if datasetChoice == "Operational":
                st.subheader("BMU(s) Operational Data")
                if filteredOperationalData.empty:
                    st.info(
                        "No operational data was found for the submitted BMUs and date range."
                    )
                else:
                    selectedBMUsDF = filteredOperationalData[
                        filteredOperationalData["BMU_ID"].isin(selectBMUs)
                    ].sort_values("GMT_DATETIME")
                    st.dataframe(selectedBMUsDF, width="stretch")

            elif datasetChoice == "Wholesale / bid-offer":
                if showBidOfferOverlay:
                    st.subheader("Wholesale + Bid/Offer Data")
                    wholesalePriceComparisonDF = _build_wholesale_comparison_table(
                        filteredWholesalePrices,
                        selectedBodBMUsDF,
                    )
                    if wholesalePriceComparisonDF.empty:
                        st.info(
                            "No wholesale or bid/offer data was found for the submitted date range."
                        )
                    else:
                        st.dataframe(wholesalePriceComparisonDF, width="stretch")
                else:
                    st.subheader("Wholesale Data")
                    if filteredWholesalePrices.empty:
                        st.info(
                            "No wholesale price data was found for the submitted date range."
                        )
                    else:
                        st.dataframe(filteredWholesalePrices.copy(), width="stretch")

            elif datasetChoice == "Dynamic Parameters":
                st.subheader("Dynamic Parameters Data")
                if dynamicParamDF.empty:
                    st.info(
                        "No dynamic parameters data was found for the submitted BMUs and date range."
                    )
                else:
                    st.dataframe(dynamicParamDF, width="stretch")

            elif datasetChoice == "REMIT":
                st.subheader("REMIT Event Data")
                if not showREMITOverlay:
                    st.info(
                        "Enable 'REMIT on operational charts' in the sidebar and click 'Load investigation' to load REMIT event records."
                    )
                elif not remitByBMU:
                    st.info(
                        "No REMIT events were found for the submitted BMUs and date range."
                    )
                else:
                    combinedRemitDF = pd.concat(
                        list(remitByBMU.values()),
                        ignore_index=True,
                    )
                    st.dataframe(combinedRemitDF, width="stretch")


if __name__ == "__main__" or st.runtime.exists():
    main()
