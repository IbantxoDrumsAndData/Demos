# Market Monitoring - Price Dashboard (Refactored v2 Release: Web App Deployment)

This release provides the v2 domain-modular implementation of the **Market Monitoring - Price Dashboard**, incorporating the compact sidebar date controls, `DA PN` operational horizon, 6-trace legend-driven Bid/Offer price chart, subtle yellow REMIT time bands, and responsive HTML card titles above every Plotly chart. Configured for **Azure App Service (Web App) deployment** with Managed Identity and Azure Key Vault.

---

## 1. Highlights in Refactored v2

* **Compact Date Selection**: Single radio selector (`Specific Day`, `Specific Week` [`Week 48 - 23-29 Nov 2026`, ISO Monday–Sunday], `Specific Month` [`November 2026`], `Custom Date Range`) showing only the relevant date control for the chosen mode.
* **Operational Chart**: Includes `DA PN` (`DAYAHEADIPNSUBMISSION_MW`, royal blue `#1E40AF`, `legendonly`) alongside `4H–18H PN`, and represents active REMIT notices as subtle yellow vertical time bands bounded to the unit's MW data range (`0 / min MW` to `max MW`) with a single `"REMIT"` legend toggle.
* **Wholesale & Bid/Offer Chart**: Pair selection removed from sidebar and handled directly in the chart legend across six explicit traces (`Pair -1 Bid` and `Pair +1 Offer` visible by default; `Pair -2/-3 Bid` and `Pair +2/+3 Offer` hidden in legend).
* **Responsive Card Titles**: Chart headings sit outside and above each Plotly canvas (`autoexpand=True`) so legends never overlap titles at any screen size.

---

## 2. Startup Command (Azure App Service)

```bash
python -m streamlit run streamlit_app.py --server.port 8000 --server.address 0.0.0.0
```
