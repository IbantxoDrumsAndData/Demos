"""Compact sidebar investigation controls and NESO footer component."""

from __future__ import annotations

from datetime import date, datetime
import html
from pathlib import Path
from typing import Any
import pandas as pd
import streamlit as st

from src.models.investigation import (
    DATE_SELECTION_MODES,
    InvestigationRequest,
)
from src.services.date_service import (
    format_iso_week_label,
    format_month_label,
    get_recent_iso_week_options,
    get_recent_month_options,
    resolve_compact_dates,
    to_datetime_bounds,
)
from src.services.filter_service import (
    get_bmu_options,
    get_portfolios_for_fuel_types,
)


def render_sidebar(
    stakeholders: pd.DataFrame,
    fuel_types: list[str],
    logo_path: Path | None = None,
) -> dict[str, Any]:
    """Render compact sidebar controls, handle 'Load investigation', and return draft state."""
    now_dt: datetime = st.session_state.get("reference_now_dt") or datetime.now()
    ref_date = now_dt.date()

    with st.sidebar:
        st.markdown(
            '<div class="ux-sidebar-title">Select units, period and overlays</div>',
            unsafe_allow_html=True,
        )

        draft_fuel_type = st.multiselect(
            "Fuel types (optional)",
            options=fuel_types,
            key="sidebar_fuel_types",
        )

        portfolios_in_selected_fuel = get_portfolios_for_fuel_types(
            stakeholders,
            draft_fuel_type,
        )

        draft_portfolio = st.multiselect(
            "Portfolio (optional)",
            options=portfolios_in_selected_fuel,
            key="sidebar_portfolios",
        )

        bmu_options = get_bmu_options(
            stakeholders_df=stakeholders,
            fuel_types=draft_fuel_type,
            portfolios=draft_portfolio,
            existing_selected_bmus=st.session_state.get("sidebar_bmus", []),
        )

        draft_bmus = st.multiselect(
            "BMUs (up to 4)",
            options=bmu_options,
            max_selections=4,
            key="sidebar_bmus",
        )

        st.markdown(
            '<p class="ux-sidebar-help">Leave fuel unselected to compare technologies.</p>',
            unsafe_allow_html=True,
        )

        # Compact Date Selection section
        st.markdown(
            '<div class="ux-sidebar-section-label">Date selection</div>',
            unsafe_allow_html=True,
        )

        date_mode = st.radio(
            "Date selection",
            options=DATE_SELECTION_MODES,
            index=1,
            label_visibility="collapsed",
            key="date_mode_selector",
        )

        selected_day: date | None = None
        selected_iso_week: tuple[int, int] | None = None
        selected_year_month: tuple[int, int] | None = None
        custom_start_date: date | None = None
        custom_end_date: date | None = None
        date_help_text: str | None = None

        if date_mode == "Specific Day":
            selected_day = st.date_input(
                "Select day",
                value=ref_date,
                min_value=date(2000, 1, 1),
                max_value=date(2100, 12, 31),
                format="DD/MM/YYYY",
                key="sidebar_single_day",
            )
        elif date_mode == "Specific Week":
            week_options = get_recent_iso_week_options(ref_date)
            iso_cal = ref_date.isocalendar()
            current_iso_tuple = (int(iso_cal[0]), int(iso_cal[1]))
            default_week_idx = (
                week_options.index(current_iso_tuple)
                if current_iso_tuple in week_options
                else 0
            )
            selected_iso_week = st.selectbox(
                "Select week",
                options=week_options,
                index=default_week_idx,
                format_func=lambda pair: format_iso_week_label(pair[0], pair[1]),
                key="sidebar_week_selector",
            )
            date_help_text = "ISO weeks - Monday-Sunday"
        elif date_mode == "Specific Month":
            month_options = get_recent_month_options(ref_date)
            current_ym = (ref_date.year, ref_date.month)
            default_month_idx = (
                month_options.index(current_ym)
                if current_ym in month_options
                else 0
            )
            selected_year_month = st.selectbox(
                "Select month",
                options=month_options,
                index=default_month_idx,
                format_func=lambda pair: format_month_label(pair[0], pair[1]),
                key="sidebar_month_selector",
            )
        else:
            col_from, col_to = st.columns(2)
            with col_from:
                custom_start_date = st.date_input(
                    "Start date",
                    value=date(ref_date.year, ref_date.month, 1),
                    min_value=date(2000, 1, 1),
                    max_value=date(2100, 12, 31),
                    format="DD/MM/YYYY",
                    key="sidebar_custom_start_date",
                )
            with col_to:
                custom_end_date = st.date_input(
                    "End date",
                    value=ref_date,
                    min_value=date(2000, 1, 1),
                    max_value=date(2100, 12, 31),
                    format="DD/MM/YYYY",
                    key="sidebar_custom_end_date",
                )

        if date_help_text:
            st.markdown(
                f'<p class="ux-sidebar-help">{html.escape(date_help_text)}</p>',
                unsafe_allow_html=True,
            )

        resolved_start_date, resolved_end_date = resolve_compact_dates(
            mode=date_mode,
            selected_day=selected_day,
            selected_iso_week=selected_iso_week,
            selected_year_month=selected_year_month,
            custom_start=custom_start_date,
            custom_end=custom_end_date,
            reference_date=ref_date,
        )

        # Information overlays (pair selection is handled directly in the price chart legend)
        st.markdown(
            '<div class="ux-sidebar-section-label">Information overlays</div>',
            unsafe_allow_html=True,
        )

        draft_show_remit = st.checkbox(
            "REMIT on operational charts",
            value=False,
            key="sidebar_remit_checkbox",
        )
        draft_show_bid_offer = st.checkbox(
            "Bid/offer lines on price charts",
            value=False,
            key="sidebar_bo_checkbox",
        )

        load_clicked = st.button(
            "Load investigation",
            type="primary",
            width="stretch",
            key="sidebar_load_button",
        )

        start_dt, end_dt = to_datetime_bounds(
            resolved_start_date, resolved_end_date
        )

        sidebar_error = None
        if load_clicked:
            if not draft_bmus or len(draft_bmus) > 4:
                sidebar_error = "Select between 1 and 4 BMUs."
            elif resolved_start_date > resolved_end_date:
                sidebar_error = (
                    "Enter valid dates with Start date no later than End date."
                )
            else:
                req = InvestigationRequest(
                    show_remit_overlay=bool(draft_show_remit),
                    show_bid_offer_overlay=bool(draft_show_bid_offer),
                    datetime_range=(start_dt, end_dt),
                    start_date_str=resolved_start_date.isoformat(),
                    end_date_str=resolved_end_date.isoformat(),
                    select_fuel_type=tuple(draft_fuel_type),
                    select_portfolio=tuple(draft_portfolio),
                    select_bmus=tuple(draft_bmus),
                )
                st.session_state["submitted_request"] = req.to_session_dict()

        if sidebar_error:
            st.error(sidebar_error)

        # Compact footer branding
        st.markdown('<div class="ux-sidebar-foot"></div>', unsafe_allow_html=True)
        st.selectbox(
            "Dashboards",
            options=["Market Monitoring"],
            index=0,
            key="sidebar_dashboard_selector",
        )
        effective_logo = (
            logo_path
            if logo_path is not None
            else Path(__file__).resolve().parents[2] / "assets" / "logo.png"
        )
        if effective_logo.is_file():
            st.image(str(effective_logo), width=110)
        else:
            st.markdown("**NESO**")
        st.markdown(
            '<small class="ux-sidebar-foot-note">National Energy System Operator</small>',
            unsafe_allow_html=True,
        )

    return {
        "selectBMUs": tuple(draft_bmus),
        "selectFuelType": tuple(draft_fuel_type),
        "selectPortfolio": tuple(draft_portfolio),
        "datetimeRange": (start_dt, end_dt),
        "showREMITOverlay": bool(draft_show_remit),
        "showBidOfferOverlay": bool(draft_show_bid_offer),
    }
