"""Immutable request, loaded-data bundle, and constant definitions for investigations."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
import pandas as pd

PLOTLY_THEME = "plotly_white"
PLOTLY_BG_COLOR = "#FFFFFF"
CHART_HEIGHT = 750

DATE_SELECTION_MODES: list[str] = [
    "Specific Day",
    "Specific Week",
    "Specific Month",
    "Custom Date Range",
]

# Explicit Bid/Offer chart convention: negative pairs = Bids, positive pairs = Offers.
BID_OFFER_TRACE_SPECS: list[dict[str, Any]] = [
    {
        "pair_id": -1,
        "column": "BID_PRICE_GBP_MWH",
        "name": "Pair -1 Bid",
        "visible": True,
    },
    {
        "pair_id": -2,
        "column": "BID_PRICE_GBP_MWH",
        "name": "Pair -2 Bid",
        "visible": "legendonly",
    },
    {
        "pair_id": -3,
        "column": "BID_PRICE_GBP_MWH",
        "name": "Pair -3 Bid",
        "visible": "legendonly",
    },
    {
        "pair_id": 1,
        "column": "OFFER_PRICE_GBP_MWH",
        "name": "Pair +1 Offer",
        "visible": True,
    },
    {
        "pair_id": 2,
        "column": "OFFER_PRICE_GBP_MWH",
        "name": "Pair +2 Offer",
        "visible": "legendonly",
    },
    {
        "pair_id": 3,
        "column": "OFFER_PRICE_GBP_MWH",
        "name": "Pair +3 Offer",
        "visible": "legendonly",
    },
]

ALLOWED_BID_OFFER_PAIR_IDS: tuple[int, ...] = (-3, -2, -1, 1, 2, 3)

INVESTIGATION_TABS: list[str] = [
    "Unit & Prices",
    "Dynamic Parameters",
    "Ancillary Services",
    "BOA Instructions",
    "Strike Prices",
    "ROC",
    "Data Tables",
]

BOA_DISPLAY_COLUMNS: list[str] = [
    "GMT_DATETIME",
    "BMU_ID",
    "BOPAIR_ID",
    "BID_PRICE",
    "OFFER_PRICE",
    "CST_GROUP",
    "DIRECT_ACTION_COST",
]

DYNAMIC_PARAM_COLUMNS: list[str] = [
    "GMT_DATETIME",
    "BMU_ID",
    "AVERAGENOTICETODEVIATEFROMZERO_MINS",
    "AVERAGEMINIMUMZEROTIME_MINS",
    "AVERAGEMINIMUMNONZEROTIME_MINS",
]


@dataclass(frozen=True)
class InvestigationRequest:
    """Immutable snapshot of a submitted sidebar investigation request."""

    show_remit_overlay: bool
    show_bid_offer_overlay: bool
    datetime_range: tuple[datetime, datetime]
    start_date_str: str
    end_date_str: str
    select_fuel_type: tuple[str, ...]
    select_portfolio: tuple[str, ...]
    select_bmus: tuple[str, ...]

    def to_session_dict(self) -> dict[str, Any]:
        """Serialize to the session_state['submitted_request'] dictionary contract."""
        return {
            "showREMITOverlay": self.show_remit_overlay,
            "showBidOfferOverlay": self.show_bid_offer_overlay,
            "datetimeRange": self.datetime_range,
            "startDateStr": self.start_date_str,
            "endDateStr": self.end_date_str,
            "selectFuelType": self.select_fuel_type,
            "selectPortfolio": self.select_portfolio,
            "selectBMUs": self.select_bmus,
        }

    @classmethod
    def from_session_dict(cls, data: dict[str, Any]) -> InvestigationRequest:
        """Construct an InvestigationRequest from session_state['submitted_request']."""
        dt_range = tuple(data["datetimeRange"])
        return cls(
            show_remit_overlay=bool(data["showREMITOverlay"]),
            show_bid_offer_overlay=bool(data["showBidOfferOverlay"]),
            datetime_range=(dt_range[0], dt_range[1]),
            start_date_str=str(
                data.get("startDateStr", dt_range[0].strftime("%Y-%m-%d"))
            ),
            end_date_str=str(
                data.get("endDateStr", dt_range[1].strftime("%Y-%m-%d"))
            ),
            select_fuel_type=tuple(data.get("selectFuelType", ())),
            select_portfolio=tuple(data.get("selectPortfolio", ())),
            select_bmus=tuple(data.get("selectBMUs", ())),
        )


@dataclass
class LoadedInvestigation:
    """Container holding all prepared DataFrames and error states for an investigation."""

    request: InvestigationRequest
    filtered_operational_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    operational_load_error: Exception | None = None
    remit_by_bmu: dict[str, pd.DataFrame] = field(default_factory=dict)
    missing_remit_mapping_bmus: list[str] = field(default_factory=list)
    filtered_wholesale_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    selected_bod_bmus_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    bid_offer_load_error: Exception | None = None
    boa_instructions_df: pd.DataFrame | None = None
    boa_load_error: Exception | None = None
    dynamic_param_df: pd.DataFrame = field(default_factory=pd.DataFrame)
