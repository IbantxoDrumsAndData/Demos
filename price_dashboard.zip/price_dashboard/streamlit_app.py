import streamlit as st

# =============================
#   TITLE AND COLUMN CONFIG
# =============================
st.set_page_config(
    page_title="Market Monitoring Dashboard POC",
    layout="wide",
    initial_sidebar_state="expanded",
)

with st.sidebar:
    st.image("assets/logo.png", use_container_width=True)
demo_dashboard = st.Page("dashboards/demo_dashboard.py", title="Demo Dashboard 1")
test_dashboard = st.Page("dashboards/demo_dashboard_2.py", title="Demo Dashboard 2")


pg = st.navigation({"Dashboards": [demo_dashboard, test_dashboard]})

pg.run()
