import streamlit as st
import pandas as pd
from src.apis.enappsys import getWholesalePrices
from src.utils.dates import getDate

# =============================
#   TITLE AND COLUMN CONFIG
# =============================
st.set_page_config(
    page_title="Demo Dasboard 2,
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("Demo Dashboard 2")
