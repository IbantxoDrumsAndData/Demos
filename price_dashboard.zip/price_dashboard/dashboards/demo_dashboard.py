import streamlit as st
import pandas as pd
from src.apis.enappsys import getWholesalePrices
from src.utils.dates import getDate
import plotly.graph_objects as go
from src.apis.NEDBlob import getOperationalData
from src.apis.NEDBlob import getStakeholders
from src.apis.NEDBlob import getBidOfferData
from src.utils.figTrace import figTrace
from src.apis.elexon import getBMUMapping
from src.apis.elexon import getRemit
from src.apis.NEDBlob import getTimeFrames
from src.apis.NEDBlob import getBOAInstructionsData

# =============================
#   TITLE AND COLUMN CONFIG
# =============================
st.set_page_config(
    page_title="Demo Dashboard 1",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("Demo Dashboard 1")


PLOTLY_THEME = "plotly_white"
PLOTLY_BG_COLOR = "#FFFFFF"


# =============================
#      GET DATA SOURCES
# =============================
dataSources = getTimeFrames()

# =============================
#     GET OPERATIONAL DATA
# =============================
bmuMappingDF = getBMUMapping()

# =============================
#     GET OPERATIONAL DATA
# =============================
# st.header("Operational Data Test")

operationalData = getOperationalData()
operationalData["GMT_DATETIME"] = pd.to_datetime(operationalData["GMT_DATETIME"])

operationalData = operationalData.merge(bmuMappingDF, on="BMU_ID", how="left")

# st.dataframe(operationalData)


# =============================
#     GET WHOLESALE DATA
# =============================
# st.header("WholeSale Prices Test")

wholesalePrices = getWholesalePrices(
    getDate(days=10, string=True), getDate(string=True)
)

wholesalePrices["dateTime"] = pd.to_datetime(wholesalePrices["dateTime"])

# st.dataframe(wholesalePrices)

# =============================
#     GET BID/OFFER DATA
# =============================
# st.header("Bid/Offer Data Test")

bidOfferData = getBidOfferData()
bidOfferData["GMT_DATETIME"] = pd.to_datetime(bidOfferData["GMT_DATETIME"])
# st.dataframe(bidOfferData)

# =============================
#     GET STAKEHOLDER DATA
# =============================
# st.header("Stakeholder Data Test")

stakeholders, fuelTypes, leadParties = getStakeholders()
# st.dataframe(stakeholders)
# st.dataframe(fuelTypes)
# st.dataframe(leadParties)


# =============================
#      GET BOA Instructions
# =============================
bOAInstructionsData = getBOAInstructionsData()
bOAInstructionsData["GMT_DATETIME"] = pd.to_datetime(
    bOAInstructionsData["GMT_DATETIME"]
)

# =============================
#      SIDEBAR FILTERS
# =============================
with st.sidebar:

    st.header("Data Time Range (Need to fully implement)")

    selectedDataSources = st.multiselect("", options=dataSources)

    st.divider()

    st.header("Graph Builder - Need to implement")

    st.divider()

    st.header("Graphs/Tables")

    selectedGraphs = st.pills(
        "",
        options=[
            "Operational Data",
            "Wholesale Prices",
            "Ancillary Services",
            "Dynamic Parameters",
            "BOA Instructions",
            "Strike Prices",
            "Wind ROC Mappings",
        ],
        selection_mode="multi",
    )

    showOperationalGraph = "Operational Data" in selectedGraphs
    showWholesaleGraph = "Wholesale Prices" in selectedGraphs
    showAncillaryGraph = "Ancillary Services" in selectedGraphs
    showDynamicParamsGraph = "Dynamic Parameters" in selectedGraphs
    showBOAInstructionsTable = "BOA Instructions" in selectedGraphs
    showStrikePricesTable = "Strike Prices" in selectedGraphs
    showWindROCTable = "Wind ROC Mappings" in selectedGraphs

    st.divider()

    st.header("Information Overlays")

    showREMITOverlay = st.sidebar.toggle("REMIT Information", value=False)

    showBidOfferOverlay = st.sidebar.toggle("Bid / Offer Data", value=False)

    showDataTables = st.sidebar.toggle("Data Tables", value=False)

    st.divider()

    st.header("Filters")

    # =============================
    #       DATETIME SLIDER
    # =============================
    # Need to fix consistency between slider time values and graph dates
    operationalData["GMT_DATETIME"] = pd.to_datetime(operationalData["GMT_DATETIME"])

    data_min = operationalData["GMT_DATETIME"].min().to_pydatetime()
    data_max = operationalData["GMT_DATETIME"].max().to_pydatetime()

    datetimeRange = st.slider(
        "Date Range",
        min_value=data_min,
        max_value=data_max,
        value=(data_min, data_max),
        format="DD/MM/YYYY",
    )

    filteredOperationalData = operationalData[
        (operationalData["GMT_DATETIME"] >= datetimeRange[0])
        & (operationalData["GMT_DATETIME"] <= datetimeRange[1])
    ]

    # =============================
    #      BMU FILTER SELECTOR
    # =============================

    # This section allows you to choose a BMU, if you select fuel type and Portfolio, the stakeholder list data is used
    # If you just select a BMU, the NED query data is used

    st.text(
        "Filtering via Fuel Type and Portfolio will provide BMUs from stakeholder list within blob storage."
    )
    st.text(
        "Filtering via BMU alone will provide BMUs from NED data within blob storage."
    )

    selectFuelType = st.multiselect("Select Fuel Type", options=fuelTypes)

    bmusInSelectecdFuelType = stakeholders.copy()

    # This gets bmus that are only within the selected fuel type
    if selectFuelType:

        bmusInSelectecdFuelType = bmusInSelectecdFuelType[
            bmusInSelectecdFuelType["sheetName"].isin(selectFuelType)
        ]

    portfoliosInSelectedFuelType = sorted(
        bmusInSelectecdFuelType["Lead Party"].dropna().astype(str).unique().tolist()
    )

    selectPortfolio = st.multiselect(
        "Select Portfolio", options=portfoliosInSelectedFuelType
    )

    bmusInSelectecdPortfolio = bmusInSelectecdFuelType.copy()

    # This gets bmus that are only within the selected fuel type (and portfolio)
    if selectPortfolio:
        bmusInSelectecdPortfolio = bmusInSelectecdPortfolio[
            bmusInSelectecdPortfolio["Lead Party"].isin(selectPortfolio)
        ]

    if selectPortfolio and selectFuelType:
        bmus = sorted(
            bmusInSelectecdPortfolio["BMU ID"].dropna().astype(str).unique().tolist()
        )

    else:
        bmus = sorted(operationalData["BMU_ID"].dropna().astype(str).unique().tolist())

    selectBMUs = st.multiselect("Select BMU", options=bmus)


# =============================
#    PLOT OPERATIONAL DATA
# =============================

if showOperationalGraph and selectBMUs:

    graphsPerRow = 2  # Change to 3 if you want 3 graphs across

    for rowStart in range(0, len(selectBMUs), graphsPerRow):

        currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

        if len(currentBMUs) == 1:
            cols = [st.container()]
        else:
            cols = st.columns(graphsPerRow)

        for col, bmu in zip(cols, currentBMUs):

            with col:

                # graph code here

                bmuDF = filteredOperationalData[
                    filteredOperationalData["BMU_ID"] == bmu
                ].sort_values("GMT_DATETIME")

                operationalFig = go.Figure()

                # =============================
                # OPERATIONAL TRACES
                # =============================

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["MAXIMUM_EXPORT_LIMIT"],
                    "lines",
                    "MEL",
                    line=dict(width=3, dash="dot"),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["MAXIMUM_IMPORT_LIMIT"],
                    "lines",
                    "MIL",
                    line=dict(width=3),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["STABLEEXPORTLIMIT"],
                    "lines",
                    "SEL",
                    line=dict(width=3, dash="dot"),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["FINAL_PHYSICAL_NOTIFICATION_MW"],
                    "lines",
                    "FPN",
                    line=dict(width=3),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["OPERATIONAL_METERED_OUTPUT_MW"],
                    "lines",
                    "Metered Output",
                    line=dict(width=3, dash="dot"),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["PN4HRSAHEADOFEFFECTIVE_MW"],
                    "lines",
                    "4H PN",
                    line=dict(width=3),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["PN6HRSAHEADOFEFFECTIVE_MW"],
                    "lines",
                    "6H PN",
                    line=dict(width=3),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["PN8HRSAHEADOFEFFECTIVE_MW"],
                    "lines",
                    "8H PN",
                    line=dict(width=3),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["PN12HRSAHEADOFEFFECTIVE_MW"],
                    "lines",
                    "12H PN",
                    line=dict(width=3),
                )

                figTrace(
                    operationalFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["PN18HRSAHEADOFEFFECTIVE_MW"],
                    "lines",
                    "18H PN",
                    line=dict(width=3),
                )

                # =============================
                # REMIT DATA
                # =============================

                remitDF = getRemit(
                    bmuDF["ELEXON_BMU_ID"].iloc[0],
                    datetimeRange[0],
                    datetimeRange[1],
                )

                if showREMITOverlay and remitDF is not None and not remitDF.empty:

                    remitDF["eventStartTime"] = pd.to_datetime(
                        remitDF["eventStartTime"]
                    ).dt.tz_localize(None)

                    remitDF["eventEndTime"] = pd.to_datetime(
                        remitDF["eventEndTime"]
                    ).dt.tz_localize(None)

                    for _, remit in remitDF.iterrows():

                        if (
                            remit["eventEndTime"] < datetimeRange[0]
                            or remit["eventStartTime"] > datetimeRange[1]
                        ):
                            continue

                        overlayStart = max(
                            remit["eventStartTime"],
                            datetimeRange[0],
                        )

                        overlayEnd = min(
                            remit["eventEndTime"],
                            datetimeRange[1],
                        )

                        normalCapacity = remit["normalCapacity"]
                        unavailableCapacity = remit["unavailableCapacity"]

                        availableCapacity = normalCapacity - unavailableCapacity

                        operationalFig.add_shape(
                            type="rect",
                            x0=overlayStart,
                            x1=overlayEnd,
                            y0=availableCapacity,
                            y1=normalCapacity,
                            fillcolor="red",
                            opacity=0.3,
                            line_width=0,
                        )

                        operationalFig.add_trace(
                            go.Scatter(
                                x=[overlayStart, overlayEnd],
                                y=[
                                    availableCapacity,
                                    availableCapacity,
                                ],
                                mode="lines",
                                name=(
                                    f"REMIT | "
                                    f"{unavailableCapacity} MW | "
                                    f"{remit['eventStartTime'].strftime('%d %b')} → "
                                    f"{remit['eventEndTime'].strftime('%d %b')}"
                                ),
                                line=dict(
                                    color="red",
                                    width=2,
                                ),
                            )
                        )

                # =============================
                # LAYOUT
                # =============================

                operationalFig.update_layout(
                    template=PLOTLY_THEME,
                    # paper_bgcolor=PLOTLY_BG_COLOR,
                    # plot_bgcolor=PLOTLY_BG_COLOR,
                    title=f"{bmu} Operational Data",
                    xaxis_title="Date/Time",
                    yaxis_title="MW",
                    height=500,
                    hovermode="x unified",
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="left",
                        x=0,
                    ),
                    yaxis=dict(
                        showgrid=True,
                        gridcolor="#CBD5E1",
                        gridwidth=1,
                    ),
                )

                st.divider()
                st.plotly_chart(
                    operationalFig,
                    use_container_width=True,
                )

                if showREMITOverlay and remitDF is not None and not remitDF.empty:
                    # with st.expander(f"{bmu} REMIT Information"):
                    st.dataframe(remitDF)

    # =============================
    # DATA TABLE
    # =============================

    if showDataTables:

        selectedBMUsDF = filteredOperationalData[
            filteredOperationalData["BMU_ID"].isin(selectBMUs)
        ].sort_values("GMT_DATETIME")

        st.subheader("BMU(s) Operational Data")
        st.dataframe(selectedBMUsDF)


# =============================
#    PLOT WHOLESALE DATA
# =============================

if showWholesaleGraph:

    filteredWholesalePrices = wholesalePrices[
        (wholesalePrices["dateTime"] >= datetimeRange[0])
        & (wholesalePrices["dateTime"] <= datetimeRange[1])
    ]

    if showBidOfferOverlay:

        filteredBidOfferData = bidOfferData[
            (bidOfferData["GMT_DATETIME"] >= datetimeRange[0])
            & (bidOfferData["GMT_DATETIME"] <= datetimeRange[1])
        ]

        selectedBodBMUsDF = filteredBidOfferData[
            filteredBidOfferData["BMU_ID"].isin(selectBMUs)
        ]

        with st.sidebar:
            pairIDChoices = st.multiselect(
                "BO Pair IDs",
                options=sorted(selectedBodBMUsDF["BOPAIR_ID"].dropna().unique()),
                default=sorted(selectedBodBMUsDF["BOPAIR_ID"].dropna().unique()),
            )

    graphsPerRow = 2  # Change to 3 if preferred

    for rowStart in range(0, len(selectBMUs), graphsPerRow):

        currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

        if len(currentBMUs) == 1:
            cols = [st.container()]
        else:
            cols = st.columns(graphsPerRow)

        for col, bmu in zip(cols, currentBMUs):

            with col:

                wholesaleFig = go.Figure()

                # =============================
                # WHOLESALE PRICE TRACES
                # =============================

                figTrace(
                    wholesaleFig,
                    filteredWholesalePrices["dateTime"],
                    filteredWholesalePrices["ID_Forecast £/MWh"],
                    "lines",
                    "ID Forecast",
                    line=dict(width=3),
                )

                figTrace(
                    wholesaleFig,
                    filteredWholesalePrices["dateTime"],
                    filteredWholesalePrices["DA_Nordpool £/MWh"],
                    "lines",
                    "DA Forecast",
                    line=dict(width=3),
                )

                # =============================
                # BID / OFFER OVERLAY
                # =============================

                if showBidOfferOverlay:

                    bmuDF = selectedBodBMUsDF[selectedBodBMUsDF["BMU_ID"] == bmu]

                    for pairID in pairIDChoices:

                        pairDF = bmuDF[bmuDF["BOPAIR_ID"] == pairID].sort_values(
                            "GMT_DATETIME"
                        )

                        if pairDF.empty:
                            continue

                        figTrace(
                            wholesaleFig,
                            pairDF["GMT_DATETIME"],
                            pairDF["BID_PRICE_GBP_MWH"],
                            "lines",
                            f"Pair {pairID} BID",
                            line=dict(
                                width=3,
                                dash="dot",
                            ),
                        )

                        figTrace(
                            wholesaleFig,
                            pairDF["GMT_DATETIME"],
                            pairDF["OFFER_PRICE_GBP_MWH"],
                            "lines",
                            f"Pair {pairID} OFFER",
                            line=dict(
                                width=3,
                                dash="dot",
                            ),
                        )

                # =============================
                # LAYOUT
                # =============================

                wholesaleFig.update_layout(
                    template=PLOTLY_THEME,
                    title=f"{bmu} Wholesale Data",
                    xaxis_title="Date/Time",
                    yaxis_title="£/MWh",
                    height=500,
                    hovermode="x unified",
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="left",
                        x=0,
                    ),
                    yaxis=dict(
                        showgrid=True,
                        gridcolor="#CBD5E1",
                        gridwidth=1,
                    ),
                )

                st.divider()
                st.plotly_chart(
                    wholesaleFig,
                    use_container_width=True,
                )


# ===================================================
#  PIVOT TABLE TO HAVE WHOLESALE PRICES + BID/OFFERS
# ===================================================
if showWholesaleGraph and showDataTables and selectBMUs:

    filteredWholesalePricesDF = wholesalePrices[
        (wholesalePrices["dateTime"] >= datetimeRange[0])
        & (wholesalePrices["dateTime"] <= datetimeRange[1])
    ].copy()

    if showBidOfferOverlay:
        st.subheader("Wholesale + Bid/Offer Data")

        filteredBidOfferPricesDF = bidOfferData[
            (bidOfferData["GMT_DATETIME"] >= datetimeRange[0])
            & (bidOfferData["GMT_DATETIME"] <= datetimeRange[1])
            & (bidOfferData["BMU_ID"].isin(selectBMUs))
        ]

        bidOfferPairPricesPivotDF = filteredBidOfferPricesDF.pivot_table(
            index="GMT_DATETIME",
            columns=["BMU_ID", "BOPAIR_ID"],
            values=["BID_PRICE_GBP_MWH", "OFFER_PRICE_GBP_MWH"],
            aggfunc="first",
        )

        bidOfferPairPricesPivotDF.columns = [
            (
                f"{bmu} | Pair {pairID} | "
                f"{'Bid' if metric == 'BID_PRICE_GBP_MWH' else 'Offer'}"
            )
            for metric, bmu, pairID in bidOfferPairPricesPivotDF.columns
        ]

        bidOfferPairPricesPivotDF = bidOfferPairPricesPivotDF.reset_index()

        wholesalePriceComparisonDF = filteredWholesalePricesDF.merge(
            bidOfferPairPricesPivotDF,
            left_on="dateTime",
            right_on="GMT_DATETIME",
            how="left",
        ).drop(columns=["GMT_DATETIME"], errors="ignore")

        st.dataframe(wholesalePriceComparisonDF, use_container_width=True)

    else:
        st.subheader("Wholesale Data")
        st.dataframe(filteredWholesalePricesDF, use_container_width=True)


# =============================
#    PLOT DYNAMIC PARAMETERS
# =============================
if showDynamicParamsGraph and selectBMUs:

    graphsPerRow = 2

    dynamicParamDF = []

    for rowStart in range(0, len(selectBMUs), graphsPerRow):

        currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

        if len(currentBMUs) == 1:
            cols = [st.container()]
        else:
            cols = st.columns(graphsPerRow)

        for col, bmu in zip(cols, currentBMUs):

            with col:

                bmuDF = filteredOperationalData[
                    filteredOperationalData["BMU_ID"] == bmu
                ].sort_values("GMT_DATETIME")

                dynamicParamDF.append(
                    bmuDF[
                        [
                            "GMT_DATETIME",
                            "BMU_ID",
                            "AVERAGENOTICETODEVIATEFROMZERO_MINS",
                            "AVERAGEMINIMUMZEROTIME_MINS",
                            "AVERAGEMINIMUMNONZEROTIME_MINS",
                        ]
                    ]
                )

                dynamicParamFig = go.Figure()

                figTrace(
                    dynamicParamFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["AVERAGENOTICETODEVIATEFROMZERO_MINS"],
                    "lines",
                    "Average NDZ",
                    line=dict(width=3),
                )

                figTrace(
                    dynamicParamFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["AVERAGEMINIMUMZEROTIME_MINS"],
                    "lines",
                    "Average MZT",
                    line=dict(width=3),
                )

                figTrace(
                    dynamicParamFig,
                    bmuDF["GMT_DATETIME"],
                    bmuDF["AVERAGEMINIMUMNONZEROTIME_MINS"],
                    "lines",
                    "Average MNZT",
                    line=dict(width=3),
                )

                dynamicParamFig.update_layout(
                    template=PLOTLY_THEME,
                    title=f"{bmu} Dynamic Parameters",
                    xaxis_title="Date/Time",
                    yaxis_title="Time (Minutes)",
                    height=500,
                    hovermode="x unified",
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="left",
                        x=0,
                    ),
                    yaxis=dict(
                        showgrid=True,
                        gridcolor="#CBD5E1",
                        gridwidth=1,
                    ),
                )

                dynamicParamFig.update_xaxes(
                    range=[
                        datetimeRange[0],
                        datetimeRange[1],
                    ]
                )

                st.divider()
                st.plotly_chart(
                    dynamicParamFig,
                    use_container_width=True,
                )

    dynamicParamDF = pd.concat(
        dynamicParamDF,
        ignore_index=True,
    )

# =============================
# DYNAMIC PARAMETERS DATA TABLE
# =============================
if (
    showDynamicParamsGraph
    and showDataTables
    and selectBMUs
    and "dynamicParamDF" in locals()
    and len(dynamicParamDF) > 0
):
    st.subheader("Dynamic Parameters Data")
    st.dataframe(dynamicParamDF)


# THIS DATA IS CURRENTLY JUST PALCEHOLDER RIGHT NOW
# =====================================
# PLOT ANCILLARY SERVICES GRAPH + TABLE
# =====================================
if showAncillaryGraph and selectBMUs:

    graphsPerRow = 2

    ancillaryDF = []

    for rowStart in range(0, len(selectBMUs), graphsPerRow):

        currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

        if len(currentBMUs) == 1:
            cols = [st.container()]
        else:
            cols = st.columns(graphsPerRow)

        for col, bmu in zip(cols, currentBMUs):

            with col:

                bmuDF = filteredOperationalData[
                    filteredOperationalData["BMU_ID"] == bmu
                ].sort_values("GMT_DATETIME")

                ancillaryFig = go.Figure()

                # =====================================
                # ANCILLARY TRACES GO HERE
                # =====================================

                # Example:
                #
                # figTrace(
                #     ancillaryFig,
                #     bmuDF["GMT_DATETIME"],
                #     bmuDF["SOME_ANCILLARY_COLUMN"],
                #     "lines",
                #     "Some Ancillary Service",
                #     line=dict(width=3),
                # )

                ancillaryFig.update_layout(
                    template=PLOTLY_THEME,
                    title=f"{bmu} Ancillary Services",
                    xaxis_title="Date/Time",
                    yaxis_title="Value",
                    height=500,
                    hovermode="x unified",
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="left",
                        x=0,
                    ),
                    yaxis=dict(
                        showgrid=True,
                        gridcolor="#CBD5E1",
                        gridwidth=1,
                    ),
                )

                ancillaryFig.update_xaxes(
                    range=[
                        datetimeRange[0],
                        datetimeRange[1],
                    ]
                )

                st.divider()
                st.plotly_chart(
                    ancillaryFig,
                    use_container_width=True,
                )

                ancillaryDF.append(bmuDF)

    # =====================================
    # ANCILLARY DATA TABLE
    # =====================================
    if showDataTables and len(ancillaryDF) > 0:
        ancillaryDF = pd.concat(
            ancillaryDF,
            ignore_index=True,
        )

        st.subheader("Ancillary Services Data")

        st.dataframe(
            ancillaryDF,
            use_container_width=True,
        )

# =============================
#    BOA INSTRUCTIONS DATA
# =============================
if showBOAInstructionsTable and selectBMUs:

    graphsPerRow = 2

    for rowStart in range(0, len(selectBMUs), graphsPerRow):

        currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

        if len(currentBMUs) == 1:
            cols = [st.container()]
        else:
            cols = st.columns(graphsPerRow)

        for col, bmu in zip(cols, currentBMUs):

            with col:

                filteredBOAInstructionsData = bOAInstructionsData[
                    bOAInstructionsData["BMU_ID"] == bmu
                ].sort_values(
                    "GMT_DATETIME",
                    ascending=False,
                )

                filteredBOAInstructionsData = filteredBOAInstructionsData[
                    [
                        "GMT_DATETIME",
                        "BMU_ID",
                        "BOPAIR_ID",
                        "BID_PRICE",
                        "OFFER_PRICE",
                        "CST_GROUP",
                        "DIRECT_ACTION_COST",
                    ]
                ]

                st.divider()
                st.subheader(f"{bmu} BOA Instructions")

                st.dataframe(
                    filteredBOAInstructionsData,
                    use_container_width=True,
                )

# =============================
#   STRIKE PRICES DATA TABLE
# =============================
if showStrikePricesTable and selectBMUs:
    st.divider()
    st.header("Strike Prices")

# =============================
#      WIND ROC DATA TABLE
# =============================
if showWindROCTable and selectBMUs:
    st.divider()
    st.header("Wind ROC Mappings")
