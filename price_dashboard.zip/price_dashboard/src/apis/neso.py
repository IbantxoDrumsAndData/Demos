import streamlit as st
import pandas as pd
import requests

# =============================
#    GET ANCILLARY SERVICES
# =============================
@st.cache_data(ttl=3600, show_spinner="Loading Ancillary Service Data...")
def getAncillaryServices():
    return None
