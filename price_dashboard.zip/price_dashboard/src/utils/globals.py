import os

from azure.identity import DefaultAzureCredential

client_id = os.environ.get("DEFAULT_IDENTITY_CLIENT_ID")

credential = DefaultAzureCredential(
    managed_identity_client_id=client_id,
)

vault_url = "placeholder"

storage_account_url = "placeholder"

container_name = "placeholder"
