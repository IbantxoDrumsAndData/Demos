from azure.keyvault.secrets import SecretClient

import src.utils.globals as g


_secret_client = SecretClient(
    vault_url=g.vault_url,
    credential=g.credential,
)


def get_secret(secret_name: str) -> str:
    return _secret_client.get_secret(secret_name).value
