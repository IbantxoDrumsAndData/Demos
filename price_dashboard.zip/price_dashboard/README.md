# Dashboards
Proof of concept multi-page streamlit dashboard for Market Monitoring

## App Service Configuration

### Environment Variables
Settings > Environment variables:
- WEBSITES_PORT=8000
- SCM_DO_BUILD_DURING_DEPLOYMENT=true

### Startup Command
Settings > Configuration > Stack settings > Startup command:
- python -m streamlit run streamlit_app.py --server.port 8000 --server.address 0.0.0.0

## Pipeline Configurations

When code is pushed to the repository, the pipeline creates a deployment ZIP, deploys it to App Service using the configured Service Connection, and App Service then builds the application, installs dependencies from requirements.txt, and starts the Streamlit application using the configured startup command.

Work In Progress:
There is a second pipeline "azure-pipelines-NED-refresh.yml" that registers and deploys an AML job, to run jobs/ned_query.py. This runs the script (desired time to be set via cron job) which pulls the required BMU data from NED database.

### Variables
Within azure-pipelines.yml:
- azureSubscription: '<Azure DevOps Service Connection>'
- appName: '<Target App Service Name>'
- branch names in "trigger" section

### Deployment
The current web app is deployed at: app-aae-ncmm-fof-uks-01.azurewebsites.net This is currently using the prod (fof) deployment slot. This is not considered best practice, and appropriate deployment slots should be used for each aspect of development, for example, DEV, STG, PPROD, FOF, PROD etc etc. At the time of testing App Service, the appropriate permissions to create deployment slots was not granted. 

### Dashboard Configuration

The web application is made using streamlit, whose documentation can be found here: https://docs.streamlit.io/

The codebase is modular, with each dashboard being a seperate file within the dashboards directory. These are then initialised within streamlit_app.py by adding the following: 
- <dashboard_name> = st.Page("dashboards/<dashboard_name>py", title="dashboard title")

### APIs
API methods can be found in src/apis directory. API requests are categorized into files that contain requests all to the same domain. For example, all requests to elexon sit in elexon.py. Each API request is written as a seperate function. This is to allow requests to be cached.


### utils
Several helper functions, including keyvault and storage account connections, can be found in src/utils directory.

### Caching
Streamlit has a built-in caching system. Caching stores the results of function calls so they only need to be run once. caching is done by adding @st.cache_data above functions. You can also set a time to live (ttl) and show_spinner parameter, as shown below:
- @st.cache_data(ttl=3600, show_spinner="Loading BMU Mapping Data . . . ")


### Styling
Main styling themes can be found and configured in the .streamlit/config.toml file.

Styling of graphs is done individually for each graph when creating them, and example of stylings is shown below:

    figTrace(
                        dynamicParamFig,
                        bmuDF["GMT_DATETIME"],
                        bmuDF["AVERAGEMINIMUMNONZEROTIME_MINS"],
                        "lines",
                        "Average MNZT",
                        line=dict(width=3),
                    )

                    dynamicParamFig.update_layout(
                        template=PLOTLY_THEME,
                        title=f"{bmu} Dynamic Parameters",
                        xaxis_title="Date/Time",
                        yaxis_title="Time (Minutes)",
                        height=500,
                        hovermode="x unified",
                        legend=dict(
                            orientation="h",
                            yanchor="bottom",
                            y=1.02,
                            xanchor="left",
                            x=0,
                        ),
                        yaxis=dict(
                            showgrid=True,
                            gridcolor="#CBD5E1",
                            gridwidth=1,
                        )
                    )

The main graph themes are set as a standard for all graphs at the top of each dashboard page as follows::
- PLOTLY_THEME = "plotly_white"
- PLOTLY_BG_COLOR = "#FFFFFF"