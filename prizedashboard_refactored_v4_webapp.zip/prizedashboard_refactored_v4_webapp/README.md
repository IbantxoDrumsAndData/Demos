# Market Monitoring - Price Dashboard (Refactored v4 Release: Web App Deployment)

This release provides the v4 domain-modular implementation of the **Market Monitoring - Price Dashboard**, adding the **Constraint context overlay** (`NED/CONSTRAINTS/bmu_lookup_active_constraints.parquet`) aligned directly on source **`GMT_DATETIME`**, a **`Constraints` Data Table**, and updated Wholesale chart legend labels (**`DA Price`** first, followed by **`ID Forecast`**). Configured for **Azure App Service (Web App) deployment** with Managed Identity and Azure Key Vault.

---

## 1. Highlights in Refactored v4

* **Constraint Context Overlay (`NED/CONSTRAINTS/bmu_lookup_active_constraints.parquet`)**:
  * Independent sidebar toggle (`Constraints on operational charts`, unchecked by default; lazy-loaded and cached with `ttl=3600` matching other Blob Parquet readers).
  * Uses source `GMT_DATETIME` directly from NED for chart alignment and date filtering (consistent with all other NED Parquet datasets), keeping `SETT_DATE` and `SETT_PERIOD` for hover and audit reference.
  * Renders subtle light-grey per-settlement-period bars (`Constraint period`) behind operational traces and REMIT bands, bounded strictly to the unit's MW range.
  * Deduplicates simultaneous constraint groups into a single binary grey band per BMU/`GMT_DATETIME` while listing all applicable `CONSTRAINT_GROUP` values in hover text (`BMU`, `Group`, `Settlement date`, `Settlement period`, `Time` in GMT).
* **Constraints Data Table**: Added `Constraints` to `Data Tables` mirroring `REMIT`, displaying filtered `BMU_ID`, `CONSTRAINT_GROUP`, `BID_OFFER`, `GMT_DATETIME`, `SETT_DATE`, and `SETT_PERIOD`.
* **Wholesale Chart Legend Refinement**: Updated legend to display **`DA Price`** first, followed by **`ID Forecast`** (matching EnAppSys `GB_NORDPOOL_HR_DA.PRICE_GBP` and `GB_MIDP_PRICE_FORECAST.DM01`).
* **Retained v3 & v2 Capabilities**: Up to 6 simultaneous BMUs, `Current Year` / `YoY Comparison` dashboard switcher in the shared shell, compact `Date selection` modes, `DA PN` horizon (`#1E40AF`, `legendonly`), 6-trace Bid/Offer price chart, subtle yellow REMIT time bands, and overlap-proof HTML card titles.

---

## 2. Startup Command (Azure App Service)

```bash
python -m streamlit run streamlit_app.py --server.port 8000 --server.address 0.0.0.0
```
