"""NESO Data Portal: Interactive Streamlit explorer.

Official corporate design wrapper for National Energy System Operator open data.
"""

import streamlit as st

from neso_app import data, ui

st.set_page_config(
    page_title="NESO Data Portal",
    layout="wide",
    initial_sidebar_state="expanded",
)
ui.inject_css()

# Restore the selection from the URL (survives reloads and shared links).
for _param, _state in (("dataset", "sel_dataset"), ("resource", "sel_resource")):
    if _param in st.query_params and _state not in st.session_state:
        st.session_state[_state] = st.query_params[_param]

pages = [
    st.Page(ui.PAGES["catalogue"], title="Catalogue", default=True),
    st.Page(ui.PAGES["dataset"], title="Dataset Details"),
    st.Page(ui.PAGES["explorer"], title="Data Explorer"),
    st.Page(ui.PAGES["guide"], title="User Guide"),
]
nav = st.navigation(pages)

with st.sidebar:
    st.markdown(
        f"""<div style="padding:0.5rem 0 1rem;border-bottom:1px solid #E2E8F0;margin-bottom:1rem;">
              <img src="{ui.LOGO_IMG_SRC}" alt="National Energy System Operator" style="max-width:145px;display:block;margin-bottom:0.6rem;" />
              <div style="font-size:0.88rem;font-weight:600;color:#1E293B;">National Energy System Operator</div>
              <div style="font-size:0.75rem;color:#64748B;">Data Portal Explorer</div>
            </div>""",
        unsafe_allow_html=True,
    )
    if st.session_state.get("sel_dataset"):
        ds = data.get_dataset(st.session_state["sel_dataset"])
        if ds:
            st.caption(f"Active dataset: **{ds['title']}**")
    st.markdown('<div style="margin-top:1rem;"></div>', unsafe_allow_html=True)
    if st.button("Refresh portal cache", width="stretch"):
        st.cache_data.clear()
        st.session_state.pop("_prepared", None)
        st.session_state.pop("_export_cache", None)
    st.caption("Metadata is cached for 1 hour. Query results are cached for 15 minutes.")
    st.markdown(
        '<div style="margin-top:1.5rem;padding-top:0.85rem;border-top:1px solid #E2E8F0;font-size:0.72rem;color:#64748B;line-height:1.45;">'
        'Built with <a href="https://github.com/fboerman/neso-energy-py" target="_blank" style="color:#642846;text-decoration:none;font-weight:500;">neso-energy-py</a> by Frank Boerman-Lima (MIT License). Data from <a href="https://www.neso.energy/data-portal" target="_blank" style="color:#642846;text-decoration:none;font-weight:500;">NESO</a> (OGL v3.0).'
        '</div>',
        unsafe_allow_html=True,
    )

# Render top brand bar
ui.top_brand_bar()

nav.run()
