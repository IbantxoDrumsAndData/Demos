"""User Guide: Comprehensive instructions for exploring and extracting NESO portal materials."""

import streamlit as st

from neso_app import ui

ui.hero(
    "User Guide",
    "How to explore Great Britain's energy datasets, inspect column definitions, and extract tailored data slices.",
    eyebrow="Documentation",
    is_home=False,
)

tab_overview, tab_interactive, tab_python, tab_licensing = st.tabs([
    "Portal Structure & Data Types",
    "Interactive App Walkthrough",
    "Python API Integration",
    "Attribution & Licensing",
])

# --------------------------------------------------------------------------- #
# TAB 1: Structure & Data Types
# --------------------------------------------------------------------------- #
with tab_overview:
    ui.section("How the NESO Data Portal is Organised")
    st.markdown(
        """
        The National Energy System Operator (NESO) publishes open data via a CKAN-powered repository.
        To use this data effectively, it helps to understand how it is structured:

        * **131 Datasets (Packages):** High-level containers grouping related energy topics (e.g. *Historic Demand Data*,
          *14 Days Ahead Wind Forecasts*, *Transmission Entry Capacity Register*, *Carbon Intensity*).
        * **1,391 Resources:** The individual files and tables inside each dataset. For example, *Historic Demand Data*
          contains 27 separate annual files dating back to 2009.

        Resources come in two distinct flavours:
        """
    )

    c1, c2 = st.columns(2, gap="medium")
    with c1:
        with st.container(border=True, key="card_guide_datastore"):
            ui.badges([("Queryable", "green"), ("Datastore SQL", "plum")])
            st.markdown(
                """
                <div class="neso-card-title">Datastore Tables (90% of resources)</div>
                <div class="neso-card-text">
                  These tables are loaded into NESO's PostgreSQL database. This allows server-side SQL execution,
                  field-level data dictionaries, and targeted date-range queries without needing to download massive raw files first.
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.caption("Available in the Data Explorer with full preview, filtering, and multi-format export.")

    with c2:
        with st.container(border=True, key="card_guide_files"):
            ui.badges([("Direct Download", "amber"), ("Documents & Workbooks", "slate")])
            st.markdown(
                """
                <div class="neso-card-title">Supporting Documents & Spreadsheets (~140 files)</div>
                <div class="neso-card-text">
                  Static PDF methodology guides, Word FAQ documents, and standalone calculation workbooks.
                  These provide critical context on how forecasts and settlement data are calculated.
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.caption("Available directly from the Dataset Details page via direct download links.")


# --------------------------------------------------------------------------- #
# TAB 2: Interactive App Walkthrough
# --------------------------------------------------------------------------- #
with tab_interactive:
    ui.section("Step-by-Step: Extracting Materials via the App")

    st.markdown(
        """
        ### Step 1: Discover Datasets (Catalogue Page)
        1. Use the **search bar** to query by keyword (e.g. `wind forecast`, `demand`, `balancing`, `GSP`, `interconnector`).
        2. Filter results using the **Sort** dropdown (*Best match*, *Title A–Z*, or *Recently updated*).
        3. Review dataset cards for category tags, live status, and update timestamps.
        4. Click **View dataset** to inspect its documentation and contents.

        ---

        ### Step 2: Review Context & Tables (Dataset Details Page)
        1. Read the **Dataset description** and **Metadata** panel (publisher, licence, update schedule).
        2. Browse the **Data tables** section to identify the table you need.
        3. If you need calculation methodologies, acronym keys, or FAQs, scroll to **Documents and files** to download them.
        4. Click **Explore table** on any tabular card to launch the interactive analysis environment.

        ---

        ### Step 3: Filter & Export (Data Explorer Page)
        1. **Date Range Slicing:**
           - The app automatically detects date fields (e.g. `SETTLEMENT_DATE`) and calculates the minimum and maximum dates available.
           - Pick your desired start and end dates. The query runs **server-side**, saving you from downloading gigabytes of raw data.
        2. **Column Selection:**
           - In the **Visible columns** selector, deselect any variables you do not need to keep your download lean.
        3. **Data Dictionary:**
           - Switch to the **Data Dictionary** tab to view official definitions, units of measurement (e.g. `MW`, `£/MWh`), and expected values.
        4. **Export Formats:**
           - Choose your target format:
             - **CSV:** Standard text format compatible with any spreadsheet tool.
             - **Excel (`.xlsx`):** Formatted workbook with native date and numeric types.
             - **Parquet:** High-performance columnar format for data science pipelines (typically ~70% smaller than CSV).
        5. **Retrieving Large Datasets:**
           - For selections larger than 500 rows, click **Fetch all matching rows**. The app automatically pages through CKAN's 32,000-row limit and provides a progress indicator.
        """
    )


# --------------------------------------------------------------------------- #
# TAB 3: Python API Integration
# --------------------------------------------------------------------------- #
with tab_python:
    ui.section("Using the Backend Library in Python")

    st.markdown(
        """
        You can extract the exact same datasets directly in your own Python scripts, Jupyter notebooks,
        or automated data pipelines using the included `nesoenergy` library:
        """
    )

    st.code(
        """from nesoenergy import NesoClient

client = NesoClient()

# 1. List all 131 available dataset slugs
print(f"Total datasets: {len(client.DATASETS)}")
print(client.DATASETS[:5])

# 2. Inspect resources inside a dataset
tables_df = client.query_tables_from_set_name("historic-demand-data")
print(tables_df[["id", "name", "format", "datastore_active"]].head())

# 3. Download a full resource as a pandas DataFrame
df_csv = client.get_resource_csv_by_name(
    data_set="historic-demand-data",
    resource_name="historic_demand_data_2025"
)
print(f"Downloaded {len(df_csv):,} rows.")

# 4. Query with server-side SQL (filter applied on NESO's server)
df_filtered = client.query_resource_by_name(
    data_set="historic-demand-data",
    resource_name="historic_demand_data_2025",
    filter='"SETTLEMENT_DATE" >= \'2025-03-01\' AND "SETTLEMENT_DATE" < \'2025-04-01\' AND "ENGLAND_WALES_DEMAND" > 25000'
)
print(f"Filtered query returned {len(df_filtered):,} rows.")
""",
        language="python",
    )

    st.markdown(
        """
        ### Exporting Programmatically
        Once loaded into a pandas DataFrame, you can export directly to your preferred format:
        """
    )
    st.code(
        """# Export to Parquet (fast & compressed)
df_filtered.to_parquet("filtered_demand_march_2025.parquet", index=False)

# Export to Excel
df_filtered.to_excel("filtered_demand_march_2025.xlsx", index=False)
""",
        language="python",
    )

# --------------------------------------------------------------------------- #
# TAB 4: Attribution & Licensing
# --------------------------------------------------------------------------- #
with tab_licensing:
    ui.section("Software Licensing & Attribution")
    st.markdown(
        """
        This data portal application is an independent open-source wrapper engineered to make
        Great Britain's electricity system data easily discoverable, searchable, and exportable.
        """
    )

    c1, c2 = st.columns(2, gap="medium")
    with c1:
        with st.container(border=True, key="card_license_py"):
            ui.badges([("MIT License", "plum"), ("Open Source", "green")])
            st.markdown(
                """
                <div class="neso-card-title">neso-energy-py Client Library</div>
                <div class="neso-card-text">
                  The underlying Python client and CKAN API query abstractions are provided by the
                  open-source <code>neso-energy-py</code> project, created by <b>Frank Boerman-Lima</b>.
                  <br /><br />
                  Distributed under the permissive terms of the <b>MIT License</b>. Full copyright and
                  permission notices are preserved in the repository's <code>LICENSE.MD</code>.
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.link_button(
                "View neso-energy-py Repository",
                url="https://github.com/fboerman/neso-energy-py",
            )

    with c2:
        with st.container(border=True, key="card_license_data"):
            ui.badges([("OGL v3.0", "olive"), ("Official Data", "slate")])
            st.markdown(
                """
                <div class="neso-card-title">National Energy System Operator (NESO)</div>
                <div class="neso-card-text">
                  All underlying power system datasets, methodology documents, and portal metadata are
                  published and maintained by the <b>National Energy System Operator</b>.
                  <br /><br />
                  NESO open datasets are published under the <b>Open Government Licence v3.0 (OGL)</b>
                  or compatible open data terms unless specifically stated otherwise on individual packages.
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.link_button(
                "Visit Official NESO Data Portal",
                url="https://www.neso.energy/data-portal",
            )

