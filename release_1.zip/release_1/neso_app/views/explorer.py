"""Data explorer page: preview, filter by date and download any table."""

from __future__ import annotations

import re
from collections.abc import Callable
from datetime import date

import pandas as pd
import streamlit as st

from neso_app import data, ui

# --------------------------------------------------------------------------- #
# Selection
# --------------------------------------------------------------------------- #
try:
    catalogue = data.load_catalogue()
except data.NesoAppError as exc:
    st.error(f"Could not load the NESO catalogue: {exc}")
    st.stop()


def _sync_resource() -> None:
    st.session_state["sel_resource"] = st.session_state["explorer_res_picker"]


c_ds, c_res = st.columns(2)
with c_ds:
    ds_name = ui.dataset_picker(catalogue, "explorer_ds_picker")

ds = data.get_dataset(ds_name) if ds_name else None
tables = [r for r in ds["resources"] if r["explorable"]] if ds else []

if ds and tables:
    by_id = {r["id"]: r for r in tables}
    current = st.session_state.get("sel_resource")
    if current not in by_id:
        current = next((r["id"] for r in tables if r["datastore_active"]), tables[0]["id"])
        st.session_state["sel_resource"] = current
    if st.session_state.get("explorer_res_picker") != current:
        st.session_state["explorer_res_picker"] = current
    with c_res:
        rid = st.selectbox(
            "Table",
            options=list(by_id),
            format_func=lambda i: f"{by_id[i]['name']}  ·  {by_id[i]['format']}"
            + ("" if by_id[i]["datastore_active"] else "  (file)"),
            key="explorer_res_picker",
            on_change=_sync_resource,
        )
    res = by_id[rid]
else:
    res = None

if ds is None:
    ui.hero("Data Explorer", "Choose a dataset and table above to inspect schemas, filter and export data.", eyebrow="Explorer", is_home=False)
    st.stop()
if res is None:
    ui.hero(ds["title"], "This dataset does not have tabular data tables to explore.", eyebrow="Explorer", is_home=False)
    if st.button("View dataset documents"):
        ui.open_dataset(ds["name"])
    st.stop()

ui.hero(res["name"], ui.snippet(res["description"], 260), eyebrow=ds["title"], is_home=False)

h1, h2, h3, _ = st.columns([1.2, 1.1, 1.2, 2.5])
with h1:
    ui.badges([
        (res["format"], "plum"),
        ("Datastore SQL" if res["datastore_active"] else "Direct File", "green" if res["datastore_active"] else "amber"),
    ])
if h2.button("Dataset details", width="stretch"):
    ui.open_dataset(ds["name"])
if res["url"]:
    h3.link_button("Download original", res["url"], width="stretch")


# --------------------------------------------------------------------------- #
# Shared widgets
# --------------------------------------------------------------------------- #
def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")[:80] or "data"


def filter_panel(
    key: str,
    all_cols: list[str],
    date_cols: list[str],
    bounds: Callable[[str], tuple[date | None, date | None]],
) -> tuple[str | None, date | None, date | None, list[str]]:
    """Date-range + column filters. Returns (date_col, start, end, columns).

    ``start``/``end`` are ``None`` when the full range is selected.
    """
    date_col = start = end = None
    with st.container(border=True, key=f"card_filters_{key}"):
        f1, f2, f3 = st.columns([1.1, 1.4, 2.5])
        if date_cols:
            date_col = f1.selectbox("Date column", date_cols, key=f"dcol_{key}")
            try:
                lo, hi = bounds(date_col)
            except data.NesoAppError as exc:
                lo = hi = None
                f2.caption(f"Could not read date range: {exc}")
            if lo and hi:
                rng = f2.date_input(
                    "Date range", value=(lo, hi), min_value=lo, max_value=hi,
                    format="DD/MM/YYYY", key=f"drange_{key}_{date_col}",
                )
                if isinstance(rng, (tuple, list)) and len(rng) == 2:
                    if tuple(rng) != (lo, hi):
                        start, end = rng
                else:
                    f2.caption("Select an end date to apply the range.")
        else:
            f1.caption("No date column detected in table schema.")
        cols = f3.multiselect("Visible columns", all_cols, default=all_cols, key=f"cols_{key}")
    return date_col, start, end, cols


def column_config(schema: pd.DataFrame) -> dict:
    cfg = {}
    for row in schema.itertuples():
        help_text = " ".join(x for x in (row.title, row.description, f"Unit: {row.unit}" if row.unit else "") if x)
        if row.type == "date":
            cfg[row.column] = st.column_config.DateColumn(format="YYYY-MM-DD", help=help_text or None)
        else:
            cfg[row.column] = st.column_config.Column(help=help_text or None)
    return cfg


def download_panel(df: pd.DataFrame, sig: tuple, base_name: str) -> None:
    fmt = st.segmented_control(
        "Export format", list(data.EXPORT_FORMATS), default="CSV",
        key="export_fmt", selection_mode="single",
    ) or "CSV"
    ext, mime = data.EXPORT_FORMATS[fmt]
    cache = st.session_state.get("_export_cache")
    key = (sig, fmt, len(df))
    if not cache or cache["key"] != key:
        try:
            with st.spinner(f"Preparing {fmt} export…"):
                payload = data.export_bytes(df, fmt)
        except data.NesoAppError as exc:
            st.warning(str(exc))
            return
        cache = {"key": key, "bytes": payload}
        st.session_state["_export_cache"] = cache
    st.download_button(
        f"Download {len(df):,} rows as {fmt} ({ui.human_size(len(cache['bytes']))})",
        data=cache["bytes"], file_name=f"{base_name}.{ext}", mime=mime,
        type="primary", key="download_btn",
    )


def _range_suffix(start: date | None, end: date | None) -> str:
    return f"_{start:%Y%m%d}-{end:%Y%m%d}" if start and end else ""


# --------------------------------------------------------------------------- #
# Datastore tables: server-side SQL
# --------------------------------------------------------------------------- #
def render_datastore() -> None:
    rid = res["id"]
    try:
        with st.spinner("Loading table schema from NESO…"):
            schema, total = data.get_datastore_schema(rid)
    except data.NesoAppError as exc:
        st.error(str(exc))
        return

    tab_data, tab_dict = st.tabs(["Preview & Export", "Data Dictionary"])

    with tab_dict:
        st.caption("Official field definitions and metadata provided by NESO.")
        st.dataframe(schema, hide_index=True, width="stretch", height=min(600, 38 + 35 * len(schema)))

    with tab_data:
        all_cols = schema["column"].tolist()
        date_cols = schema.loc[schema["type"].isin(data.DATE_TYPES), "column"].tolist()
        date_col, start, end, cols = filter_panel(rid, all_cols, date_cols, lambda c: data.date_bounds(rid, c))
        if not cols:
            st.warning("Please select at least one column.")
            return
        columns = None if len(cols) == len(all_cols) else tuple(cols)
        where = data.build_where(date_col, start, end)

        try:
            with st.spinner("Querying NESO datastore…"):
                matched = total if where is None else data.count_rows(rid, where)
                preview = data.coerce_types(data.preview_rows(rid, columns, where), schema)
        except data.NesoAppError as exc:
            st.error(str(exc))
            return

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Rows", f"{total:,}")
        m2.metric("Matching Rows", f"{matched:,}")
        m3.metric("Selected Columns", f"{len(cols)} / {len(all_cols)}")
        m4.metric("Last Updated", ui.fmt_date(res["last_modified"]))

        ui.section("Data Preview")
        st.dataframe(preview, hide_index=True, width="stretch", height=420, column_config=column_config(schema))
        st.caption(f"Displaying first {len(preview):,} of {matched:,} matching rows. Hover on column headers for definitions.")

        ui.section("Export Data")
        sig = (rid, columns, where)
        base = f"{ds['name']}__{_slug(res['name'])}{_range_suffix(start, end)}"
        if matched <= len(preview):
            download_panel(preview, sig, base)
            return

        prepared = st.session_state.get("_prepared")
        if prepared and prepared["sig"] == sig:
            download_panel(prepared["df"], sig, base)
            return

        if matched > 1_000_000:
            st.warning(f"Selection contains {matched:,} rows. Specifying a date range will accelerate export.")
        st.caption(f"Full dataset will be retrieved from NESO in pages of {data.CKAN_ROWS_MAX:,} rows.")
        if st.button(f"Fetch all {matched:,} matching rows", type="primary"):
            bar = st.progress(0.0, text="Initiating download…")
            try:
                full = data.fetch_all(
                    rid, columns, where, matched,
                    on_progress=lambda p, n: bar.progress(p, text=f"Retrieved {n:,} of {matched:,} rows"),
                )
            except data.NesoAppError as exc:
                bar.empty()
                st.error(str(exc))
                return
            bar.empty()
            st.session_state["_prepared"] = {"sig": sig, "df": data.coerce_types(full, schema)}
            st.rerun()


# --------------------------------------------------------------------------- #
# Plain CSV / Excel files: download once, filter locally
# --------------------------------------------------------------------------- #
def render_file() -> None:
    size = ui.human_size(res["size"])
    try:
        with st.spinner(f"Downloading {res['format']} file{f' ({size})' if size else ''} from NESO…"):
            df, date_cols = data.load_table_file(res["url"], res["format"])
    except data.NesoAppError as exc:
        st.error(str(exc))
        return

    schema = pd.DataFrame({
        "column": [str(c) for c in df.columns],
        "type": [str(t) for t in df.dtypes],
        "title": "",
        "description": "",
        "unit": "",
        "example": [str(df[c].dropna().iloc[0]) if df[c].notna().any() else "" for c in df.columns],
    })

    tab_data, tab_dict = st.tabs(["Preview & Export", "Columns"])
    with tab_dict:
        st.caption("Schema inferred directly from the file.")
        st.dataframe(schema[["column", "type", "example"]], hide_index=True, width="stretch")

    with tab_data:
        def bounds(col: str):
            s = df[col].dropna()
            return (s.min().date(), s.max().date()) if not s.empty else (None, None)

        all_cols = list(df.columns)
        date_col, start, end, cols = filter_panel(res["id"], all_cols, date_cols, bounds)
        if not cols:
            st.warning("Please select at least one column.")
            return
        filtered = data.filter_by_date(df, date_col, start, end) if date_col and (start or end) else df
        filtered = filtered[cols]

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Rows", f"{len(df):,}")
        m2.metric("Matching Rows", f"{len(filtered):,}")
        m3.metric("Selected Columns", f"{len(cols)} / {len(all_cols)}")
        m4.metric("Last Updated", ui.fmt_date(res["last_modified"]))

        ui.section("Data Preview")
        st.dataframe(filtered.head(data.PREVIEW_ROWS), hide_index=True, width="stretch", height=420)
        st.caption(f"Displaying first {min(len(filtered), data.PREVIEW_ROWS):,} of {len(filtered):,} matching rows.")

        ui.section("Export Data")
        sig = (res["id"], tuple(cols), date_col, start, end)
        download_panel(filtered, sig, f"{ds['name']}__{_slug(res['name'])}{_range_suffix(start, end)}")


if res["datastore_active"]:
    render_datastore()
else:
    render_file()
