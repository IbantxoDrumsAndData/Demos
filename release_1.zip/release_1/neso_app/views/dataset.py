"""Dataset detail page: full description, metadata and every resource."""

import html

import streamlit as st

from neso_app import data, ui

try:
    catalogue = data.load_catalogue()
except data.NesoAppError as exc:
    st.error(f"Could not load the NESO catalogue: {exc}")
    st.stop()

c_pick, c_back = st.columns([4, 1], vertical_alignment="bottom")
with c_pick:
    name = ui.dataset_picker(catalogue, "dataset_page_picker")
if c_back.button("Back to catalogue", width="stretch"):
    st.switch_page(ui.PAGES["catalogue"])

if not name:
    ui.hero("Select a dataset", "Choose a dataset above or return to the catalogue to search.", eyebrow="Dataset Details")
    st.stop()

ds = data.get_dataset(name)
if ds is None:
    st.error(f"Dataset '{name}' was not found on the NESO portal.")
    st.stop()

ui.hero(ds["title"], ui.snippet(ds["notes"], 260), eyebrow=ds["org_title"], is_home=False)

tables = [r for r in ds["resources"] if r["explorable"]]
files = [r for r in ds["resources"] if not r["explorable"]]

ui.badges(
    [(ds["status"], ui.status_tone(ds["status"])),
     (f"{len(tables)} tables", "green"),
     (f"{len(files)} documents", "slate"),
     (ds["license_title"], "plum")]
    + [(t, "slate") for t in ds["tags"][:6]]
)

a1, a2, _ = st.columns([1, 1, 3])
a1.link_button("View on neso.energy", ds["portal_url"], width="stretch")
first_table = next((r for r in tables if r["datastore_active"]), tables[0] if tables else None)
if first_table and a2.button("Explore table", type="primary", width="stretch"):
    ui.open_explorer(ds["name"], first_table["id"])

# --- Description and details -------------------------------------------------
left, right = st.columns([2, 1], gap="large")
with left:
    ui.section("Dataset description")
    clean_desc = ui.clean_notes(ds["notes"])
    st.markdown(clean_desc or "No detailed description provided by NESO.")
with right:
    ui.section("Metadata")
    with st.container(border=True, key="card_details"):
        rows = [
            ("Category", ds["org_title"]),
            ("Publisher", ds["author"] or "National Energy System Operator"),
            ("Status", ds["status"] or "Live"),
            ("Created", ui.fmt_date(ds["created"])),
            ("Updated", ui.fmt_date(ds["modified"])),
            ("Licence", ds["license_title"] or "NESO Open Data Licence"),
            ("Slug", ds["name"]),
        ]
        st.markdown(
            '<dl class="neso-kv">'
            + "".join(f"<dt>{html.escape(k)}</dt><dd>{html.escape(str(v))}</dd>" for k, v in rows)
            + "</dl>",
            unsafe_allow_html=True,
        )
        if ds["org_description"]:
            st.caption(f"**{ds['org_title']}**: {ds['org_description']}")

# --- Data tables -------------------------------------------------------------
ui.section(f"Data tables ({len(tables)})")
if not tables:
    st.info("This dataset does not contain tabular data tables. See the documents listed below.")
for i in range(0, len(tables), 2):
    cols = st.columns(2, gap="medium")
    for col, res in zip(cols, tables[i: i + 2]):
        with col.container(border=True, key=f"card_res_{res['id']}"):
            ui.badges([
                (res["format"], "plum"),
                ("Datastore SQL" if res["datastore_active"] else "Direct File", "green" if res["datastore_active"] else "amber"),
            ])
            st.markdown(
                f'<div class="neso-card-title">{html.escape(res["name"])}</div>'
                f'<div class="neso-card-text">{html.escape(ui.snippet(res["description"], 220) or "No description provided.")}</div>'
                f'<div class="neso-meta">Updated <b>{ui.fmt_date(res["last_modified"])}</b>'
                f'{" · " + ui.human_size(res["size"]) if ui.human_size(res["size"]) else ""}</div>',
                unsafe_allow_html=True,
            )
            st.write("")
            b1, b2 = st.columns(2)
            if b1.button("Explore table", key=f"explore_{res['id']}", type="primary", width="stretch"):
                ui.open_explorer(ds["name"], res["id"])
            if res["url"]:
                b2.link_button("Download original", res["url"], width="stretch")

# --- Other files -------------------------------------------------------------
if files:
    ui.section(f"Documents and files ({len(files)})")
    for res in files:
        with st.container(border=True, key=f"card_file_{res['id']}"):
            c1, c2 = st.columns([5, 1], vertical_alignment="center")
            with c1:
                st.markdown(
                    f'{ui.badge(res["format"], "slate")} <span class="neso-card-title">{html.escape(res["name"])}</span>'
                    f'<div class="neso-meta">{html.escape(ui.snippet(res["description"], 260))}</div>',
                    unsafe_allow_html=True,
                )
            if res["url"]:
                c2.link_button("Download document", res["url"], width="stretch")
