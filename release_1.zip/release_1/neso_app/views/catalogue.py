"""Catalogue page: search and browse every NESO dataset."""

import html

import streamlit as st

from neso_app import data, ui

PAGE_SIZE = 24
COLS = 3

ui.hero(
    "NESO Open Data Explorer",
    "Fast search, schema inspection, and targeted exports for Great Britain's electricity system data.",
    eyebrow="Independent Explorer",
    is_home=True,
)

try:
    catalogue = data.load_catalogue()
except data.NesoAppError as exc:
    st.error(f"Could not load the NESO catalogue: {exc}")
    st.stop()

# --- Search and sort --------------------------------------------------------
c_search, c_sort = st.columns([4, 1])
query = c_search.text_input(
    "Search datasets",
    placeholder="Search by keyword, e.g. demand forecast, wind, balancing costs, GSP, carbon intensity…",
    key="catalogue_query",
    label_visibility="collapsed",
)
sort = c_sort.selectbox(
    "Sort", ["Best match", "Title (A–Z)", "Recently updated"],
    key="catalogue_sort", label_visibility="collapsed",
)

results = data.search_catalogue(catalogue, query)
if sort == "Title (A–Z)":
    results = sorted(results, key=lambda d: d["title"].lower())
elif sort == "Recently updated":
    results = sorted(results, key=lambda d: d["modified"] or "", reverse=True)

# --- Summary metrics ---------------------------------------------------------
m1, m2, m3, m4 = st.columns(4)
m1.metric("Total Datasets", f"{len(catalogue):,}")
m2.metric("Matching Results", f"{len(results):,}")
m3.metric("Total Resources", f"{sum(len(d['resources']) for d in catalogue):,}")
m4.metric("Datastore Tables", f"{sum(d['n_queryable'] for d in catalogue):,}")

if not results:
    st.info("No datasets match your search criteria. Please try a different query.")
    st.stop()

# --- Pagination state --------------------------------------------------------
sig = (query, sort)
if st.session_state.get("_catalogue_sig") != sig:
    st.session_state["_catalogue_sig"] = sig
    st.session_state["catalogue_page"] = 0
n_pages = (len(results) - 1) // PAGE_SIZE + 1
page = min(st.session_state.get("catalogue_page", 0), n_pages - 1)
visible = results[page * PAGE_SIZE: (page + 1) * PAGE_SIZE]

st.write("")

# --- Card grid ---------------------------------------------------------------
for row_start in range(0, len(visible), COLS):
    cols = st.columns(COLS, gap="medium")
    for col, ds in zip(cols, visible[row_start: row_start + COLS]):
        with col.container(border=True, key=f"card_{ds['name']}"):
            ui.badges([(ds["org_title"], "plum"), (ds["status"], ui.status_tone(ds["status"]))])
            st.markdown(
                f'<div class="neso-card-title">{html.escape(ds["title"])}</div>'
                f'<div class="neso-card-text">{html.escape(ui.snippet(ds["notes"]) or "No description provided.")}</div>',
                unsafe_allow_html=True,
            )
            if ds["tags"]:
                ui.badges([(t, "slate") for t in ds["tags"][:3]])
            st.markdown(
                f'<div class="neso-meta"><b>{len(ds["resources"])}</b> resources · '
                f'<b>{ds["n_queryable"]}</b> datastore · updated {ui.fmt_date(ds["modified"])}</div>',
                unsafe_allow_html=True,
            )
            st.write("")
            if st.button("View dataset", key=f"open_{ds['name']}", type="primary", width="stretch"):
                ui.open_dataset(ds["name"])

# --- Pager -------------------------------------------------------------------
if n_pages > 1:
    st.write("")
    p_prev, p_info, p_next = st.columns([1, 2, 1])
    if p_prev.button("Previous page", disabled=page == 0, width="stretch"):
        st.session_state["catalogue_page"] = page - 1
        st.rerun()
    p_info.markdown(
        f'<div class="neso-meta" style="text-align:center;padding-top:.55rem">'
        f'Page <b>{page + 1}</b> of <b>{n_pages}</b> · showing {len(visible)} of {len(results)}</div>',
        unsafe_allow_html=True,
    )
    if p_next.button("Next page", disabled=page >= n_pages - 1, width="stretch"):
        st.session_state["catalogue_page"] = page + 1
        st.rerun()
