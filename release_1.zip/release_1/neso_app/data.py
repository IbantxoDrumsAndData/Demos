"""Data-access layer for the NESO Streamlit explorer.

Builds on :class:`nesoenergy.NesoClient` and adds a few extra CKAN calls that
the library does not expose (``package_search`` for the full catalogue and
``datastore_search`` for the column data dictionary). Everything that touches
the network is cached with Streamlit so the app stays snappy.
"""

from __future__ import annotations

import io
import re
from datetime import date, timedelta
from collections.abc import Callable

import pandas as pd
import requests
import streamlit as st

from nesoenergy import NesoClient

PORTAL_URL = "https://www.neso.energy/data-portal"
CKAN_ROWS_MAX = 32_000  # CKAN default `ckan.datastore.search.rows_max`
PREVIEW_ROWS = 500
EXCEL_MAX_ROWS = 1_048_575  # Excel sheet limit minus the header row

DATE_TYPES = {"date", "timestamp", "timestamptz"}
NUMERIC_TYPES = {"numeric", "float8", "float4", "int2", "int4", "int8", "integer", "number"}
FILE_TABULAR_FORMATS = {"CSV", "XLSX", "XLS"}
DATE_NAME_HINT = re.compile(r"date|time|day|month|year|start|end|period", re.IGNORECASE)

EXPORT_FORMATS = {
    "CSV": ("csv", "text/csv"),
    "Excel": ("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    "Parquet": ("parquet", "application/vnd.apache.parquet"),
}


class NesoAppError(Exception):
    """User-facing error raised by the data layer."""


# --------------------------------------------------------------------------- #
# Low-level helpers
# --------------------------------------------------------------------------- #
@st.cache_resource(show_spinner="Connecting to the NESO API…")
def get_client() -> NesoClient:
    try:
        return NesoClient()
    except requests.RequestException as exc:
        raise NesoAppError(f"Could not reach the NESO API: {exc}") from exc


def _ckan_error(exc: requests.HTTPError) -> str:
    """Extract CKAN's error message from an HTTP error response if possible."""
    try:
        err = exc.response.json().get("error", {})
    except (ValueError, AttributeError):
        return str(exc)
    for field in ("sql", "query"):
        if field in err:
            msg = err[field][0] if isinstance(err[field], list) else str(err[field])
            msg = re.sub(r"^\(psycopg2\.\w+\)\s*", "", msg)
            return msg.split("\n")[0]
    if "info" in err and isinstance(err["info"], dict) and err["info"].get("orig"):
        orig = err["info"]["orig"]
        return orig[0] if isinstance(orig, list) else str(orig)
    return err.get("message") or str(exc)


def _action(action: str, **params):
    client = get_client()
    try:
        r = client.s.get(f"{client.BASE_URL}/api/3/action/{action}", params=params, timeout=60)
        r.raise_for_status()
        payload = r.json()
    except requests.HTTPError as exc:
        raise NesoAppError(f"NESO API error ({action}): {_ckan_error(exc)}") from exc
    except requests.RequestException as exc:
        raise NesoAppError(f"NESO API request failed ({action}): {exc}") from exc
    except ValueError as exc:
        raise NesoAppError(f"NESO API returned invalid JSON ({action}).") from exc
    if not payload.get("success"):
        err = payload.get("error", {})
        raise NesoAppError(err.get("message") or str(err))
    return payload["result"]


def q_ident(name: str) -> str:
    """Quote an SQL identifier (column / table name)."""
    return '"' + str(name).replace('"', '""') + '"'


def _is_text(s: pd.Series) -> bool:
    return pd.api.types.is_object_dtype(s) or pd.api.types.is_string_dtype(s)


def run_sql(sql: str) -> pd.DataFrame:
    """Run SQL through ``NesoClient.query_resource`` with friendly errors."""
    try:
        return get_client().query_resource(sql)
    except requests.HTTPError as exc:
        raise NesoAppError(f"Query failed: {_ckan_error(exc)}") from exc
    except requests.RequestException as exc:
        raise NesoAppError(f"Query request failed: {exc}") from exc
    except Exception as exc:  # library raises bare Exception for SQL errors
        raise NesoAppError(str(exc)) from exc


# --------------------------------------------------------------------------- #
# Catalogue
# --------------------------------------------------------------------------- #
def _clean_resource(res: dict) -> dict:
    fmt = (res.get("format") or "").upper().strip()
    datastore = bool(res.get("datastore_active"))
    return {
        "id": res["id"],
        "name": res.get("name") or res["id"],
        "description": (res.get("description") or "").strip(),
        "format": fmt or "—",
        "datastore_active": datastore,
        "explorable": datastore or fmt in FILE_TABULAR_FORMATS,
        "url": res.get("url") or res.get("path") or "",
        "last_modified": res.get("last_modified") or res.get("metadata_modified") or res.get("created"),
        "size": res.get("size"),
    }


def _clean_dataset(pkg: dict) -> dict:
    org = pkg.get("organization") or {}
    extras = {e.get("key"): e.get("value") for e in pkg.get("extras") or []}
    resources = [_clean_resource(r) for r in pkg.get("resources") or []]
    return {
        "name": pkg["name"],
        "title": pkg.get("title") or pkg["name"],
        "notes": (pkg.get("notes") or "").strip(),
        "org_title": org.get("title") or "Uncategorised",
        "org_description": (org.get("description") or "").strip(),
        "tags": sorted({t.get("display_name") or t.get("name") for t in pkg.get("tags") or []}),
        "status": extras.get("Status") or "",
        "license_title": pkg.get("license_title") or "",
        "license_url": pkg.get("license_url") or "",
        "author": pkg.get("author") or "",
        "created": pkg.get("metadata_created"),
        "modified": pkg.get("metadata_modified"),
        "resources": resources,
        "n_queryable": sum(r["datastore_active"] for r in resources),
        "portal_url": f"{PORTAL_URL}/{pkg['name']}",
    }


@st.cache_data(ttl=3600, show_spinner="Loading the NESO dataset catalogue…")
def load_catalogue() -> list[dict]:
    """Every dataset with full metadata, via paginated ``package_search``."""
    datasets: list[dict] = []
    start = 0
    while True:
        res = _action("package_search", rows=1000, start=start)
        batch = res.get("results", [])
        datasets.extend(_clean_dataset(p) for p in batch)
        start += len(batch)
        if not batch or start >= int(res.get("count", 0)):
            break
    return sorted(datasets, key=lambda d: d["title"].lower())


def get_dataset(name: str) -> dict | None:
    for ds in load_catalogue():
        if ds["name"] == name:
            return ds
    try:
        return _clean_dataset(_action("package_show", id=name))
    except NesoAppError:
        return None


def search_catalogue(catalogue: list[dict], query: str) -> list[dict]:
    """Free-text search: all tokens must match; title hits rank highest."""
    tokens = [t for t in re.split(r"\s+", query.lower().strip()) if t]
    if not tokens:
        return list(catalogue)
    scored = []
    for ds in catalogue:
        title = ds["title"].lower()
        tags = " ".join(ds["tags"]).lower()
        hay = " ".join(
            [title, ds["name"], ds["notes"].lower(), tags, ds["org_title"].lower(),
             " ".join(r["name"].lower() for r in ds["resources"])]
        )
        if all(t in hay for t in tokens):
            score = sum(3 * (t in title) + 2 * (t in tags) + 1 for t in tokens)
            scored.append((score, ds))
    scored.sort(key=lambda x: (-x[0], x[1]["title"].lower()))
    return [ds for _, ds in scored]


# --------------------------------------------------------------------------- #
# Datastore (server-side SQL) resources
# --------------------------------------------------------------------------- #
@st.cache_data(ttl=3600, show_spinner=False)
def get_datastore_schema(resource_id: str) -> tuple[pd.DataFrame, int]:
    """Column data dictionary + total row count for a datastore resource."""
    res = _action("datastore_search", id=resource_id, limit=0)
    rows = []
    for f in res.get("fields", []):
        if f["id"] in ("_id", "_full_text"):
            continue
        info = f.get("info") or {}
        rows.append({
            "column": f["id"],
            "type": f.get("type", ""),
            "title": info.get("title") or "",
            "description": info.get("description") or "",
            "unit": info.get("unit") or "",
            "example": info.get("example") or "",
        })
    cols = ["column", "type", "title", "description", "unit", "example"]
    return pd.DataFrame(rows, columns=cols), int(res.get("total") or 0)


def build_where(date_col: str | None, start: date | None, end: date | None) -> str | None:
    if not date_col or (start is None and end is None):
        return None
    parts = []
    if start is not None:
        parts.append(f"{q_ident(date_col)} >= '{start.isoformat()}'")
    if end is not None:
        parts.append(f"{q_ident(date_col)} < '{(end + timedelta(days=1)).isoformat()}'")
    return " AND ".join(parts)


def _select_sql(resource_id: str, columns: tuple | None, where: str | None,
                limit: int, offset: int = 0) -> str:
    cols = ", ".join(q_ident(c) for c in columns) if columns else "*"
    sql = f"SELECT {cols} FROM {q_ident(resource_id)}"
    if where:
        sql += f" WHERE {where}"
    return sql + f' ORDER BY "_id" ASC LIMIT {int(limit)} OFFSET {int(offset)}'


@st.cache_data(ttl=900, show_spinner=False)
def preview_rows(resource_id: str, columns: tuple | None, where: str | None,
                 limit: int = PREVIEW_ROWS) -> pd.DataFrame:
    df = run_sql(_select_sql(resource_id, columns, where, limit))
    return df[[c for c in columns if c in df.columns]] if columns else df


@st.cache_data(ttl=900, show_spinner=False)
def count_rows(resource_id: str, where: str | None) -> int:
    sql = f"SELECT COUNT(*) AS n FROM {q_ident(resource_id)}"
    if where:
        sql += f" WHERE {where}"
    df = run_sql(sql)
    return int(df["n"].iloc[0]) if not df.empty else 0


@st.cache_data(ttl=3600, show_spinner=False)
def date_bounds(resource_id: str, column: str) -> tuple[date | None, date | None]:
    col = q_ident(column)
    df = run_sql(f"SELECT MIN({col}) AS lo, MAX({col}) AS hi FROM {q_ident(resource_id)}")
    if df.empty:
        return None, None
    lo, hi = (pd.to_datetime(df[c].iloc[0], errors="coerce") for c in ("lo", "hi"))
    return (None if pd.isna(lo) else lo.date()), (None if pd.isna(hi) else hi.date())


@st.cache_data(ttl=900, show_spinner=False, max_entries=128)
def _fetch_page(resource_id: str, columns: tuple | None, where: str | None, offset: int) -> pd.DataFrame:
    df = run_sql(_select_sql(resource_id, columns, where, CKAN_ROWS_MAX, offset))
    return df[[c for c in columns if c in df.columns]] if columns else df


def fetch_all(resource_id: str, columns: tuple | None, where: str | None, total: int,
              on_progress: Callable[[float, int], None] | None = None) -> pd.DataFrame:
    """Download every matching row, paging around CKAN's per-query row cap."""
    frames, offset = [], 0
    while offset < total:
        page = _fetch_page(resource_id, columns, where, offset)
        if page.empty:
            break
        frames.append(page)
        offset += len(page)
        if on_progress:
            on_progress(min(offset / max(total, 1), 1.0), offset)
    if not frames:
        return pd.DataFrame(columns=list(columns or []))
    return pd.concat(frames, ignore_index=True)


def coerce_types(df: pd.DataFrame, schema: pd.DataFrame) -> pd.DataFrame:
    """Apply datastore column types (dates / numerics) and schema column order."""
    order = [c for c in schema["column"] if c in df.columns]
    out = df[order + [c for c in df.columns if c not in order]].copy()
    types = dict(zip(schema["column"], schema["type"]))
    for col in out.columns:
        t = types.get(col, "")
        if t in DATE_TYPES:
            out[col] = pd.to_datetime(out[col], errors="coerce")
        elif t in NUMERIC_TYPES and _is_text(out[col]):
            converted = pd.to_numeric(out[col], errors="coerce")
            if converted.notna().sum() >= out[col].notna().sum():
                out[col] = converted
    return out


# --------------------------------------------------------------------------- #
# Plain file resources (CSV / Excel not loaded into the datastore)
# --------------------------------------------------------------------------- #
def load_file(url: str, fmt: str) -> pd.DataFrame:
    client = get_client()
    try:
        if fmt == "CSV":
            return client.get_resource_csv_by_path(url)  # NesoClient -> DataFrame
        r = client.s.get(url, timeout=300)
        r.raise_for_status()
        return pd.read_excel(io.BytesIO(r.content))
    except requests.RequestException as exc:
        raise NesoAppError(f"Could not download file: {exc}") from exc
    except Exception as exc:
        raise NesoAppError(f"Could not parse {fmt} file: {exc}") from exc


@st.cache_data(ttl=3600, show_spinner=False, max_entries=8)
def load_table_file(url: str, fmt: str) -> tuple[pd.DataFrame, list[str]]:
    """Download a CSV/Excel resource and detect its date columns (cached)."""
    return detect_date_columns(load_file(url, fmt))


def detect_date_columns(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Find (and convert) date-like columns in a locally loaded file."""
    out = df.copy()
    found = []
    for col in out.columns:
        s = out[col]
        if pd.api.types.is_datetime64_any_dtype(s):
            found.append(col)
            continue
        if not _is_text(s) or not DATE_NAME_HINT.search(str(col)):
            continue
        sample = s.dropna().astype(str).head(200)
        if sample.empty:
            continue
        parsed = pd.to_datetime(sample, errors="coerce", dayfirst="/" in sample.iloc[0], format="mixed")
        if parsed.notna().mean() > 0.9:
            out[col] = pd.to_datetime(s, errors="coerce", dayfirst="/" in sample.iloc[0], format="mixed")
            found.append(col)
    return out, found


def filter_by_date(df: pd.DataFrame, col: str, start: date | None, end: date | None) -> pd.DataFrame:
    s = df[col]
    if getattr(s.dt, "tz", None) is not None:
        s = s.dt.tz_localize(None)
    mask = pd.Series(True, index=df.index)
    if start is not None:
        mask &= s >= pd.Timestamp(start)
    if end is not None:
        mask &= s < pd.Timestamp(end + timedelta(days=1))
    return df[mask]


# --------------------------------------------------------------------------- #
# Export
# --------------------------------------------------------------------------- #
def export_bytes(df: pd.DataFrame, fmt: str) -> bytes:
    if fmt == "CSV":
        return df.to_csv(index=False).encode("utf-8")
    buf = io.BytesIO()
    if fmt == "Excel":
        if len(df) > EXCEL_MAX_ROWS:
            raise NesoAppError(
                f"Excel supports at most {EXCEL_MAX_ROWS:,} rows; this selection has {len(df):,}. "
                "Narrow the date range or choose CSV / Parquet."
            )
        out = df.copy()
        for col in out.select_dtypes(include=["datetimetz"]).columns:
            out[col] = out[col].dt.tz_localize(None)
        out.to_excel(buf, index=False, sheet_name="data", engine="openpyxl")
        return buf.getvalue()
    if fmt == "Parquet":
        try:
            df.to_parquet(buf, index=False)
        except Exception:  # mixed-type object columns -> stringify and retry
            out = df.copy()
            for col in out.select_dtypes(include=["object", "string"]).columns:
                out[col] = out[col].astype("string")
            buf = io.BytesIO()
            out.to_parquet(buf, index=False)
        return buf.getvalue()
    raise NesoAppError(f"Unsupported export format: {fmt}")
