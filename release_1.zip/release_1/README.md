# NESO Data Portal (Release 1)

Minimal, self-contained interactive data explorer for National Energy System Operator (NESO) open energy datasets.

---

## Running with Conda (Anaconda / Miniconda)

### 1. Open the Folder in VS Code
1. Launch **VS Code**.
2. Click **File > Open Folder...** and select this folder.

### 2. Create the Conda Environment
Open the VS Code terminal (`Ctrl` + `~` or **Terminal > New Terminal**) and run:

```bash
conda env create -f environment.yml
```

### 3. Activate the Environment
```bash
conda activate neso-portal
```



### 4. Run the Application
Either:
- Press **F5** in VS Code (pre-configured in `.vscode/launch.json`), or
- Run directly in the terminal:
```bash
streamlit run app.py
```

The application will open in your default browser at `http://localhost:8501`.

---

## Alternative: Running with Standard Python (`venv`)

If you prefer using standard Python without Conda:

### 1. Create and Activate Virtual Environment
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

### 2. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 3. Run
```powershell
streamlit run app.py
```

---

## What is in this Folder?
- `app.py`: Main Streamlit application entrypoint.
- `environment.yml`: Conda environment definition (`conda env create -f environment.yml`).
- `requirements.txt`: Pip dependencies list (`pip install -r requirements.txt`).
- `requirement.txt`: Duplicate copy of pip requirements.
- `.streamlit/config.toml`: Official NESO corporate theme and layout settings.
- `.vscode/launch.json`: VS Code launch configuration for F5 execution.
- `neso_app/`: Application data logic, UI design system, vector logo, self-contained Poppins font assets (`assets/fonts/`), and multi-page views (Catalogue, Dataset Details, Data Explorer, User Guide).
- `nesoenergy/`: Core NESO CKAN and datastore API client.
- `LICENSE.MD`: MIT License notice.

