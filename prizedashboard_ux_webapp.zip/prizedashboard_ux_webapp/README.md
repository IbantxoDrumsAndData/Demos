# Market Monitoring - Price Dashboard (UX Revamp: Web App Deployment)

This release implements the approved analyst investigation UX while preserving the original file and folder structure (`streamlit_app.py`, `dashboards/demo_dashboard.py`, `src/apis/*`, `src/utils/*`) for **Azure App Service (Web App) deployment**, with all performance and correctness improvements from `prizedashboard_original_structure_webapp_PASS` retained.

---

## 1. File Structure

```text
prizedashboard_ux_webapp/
├── .streamlit/
│   └── config.toml
├── assets/
│   └── logo.png
├── azure-pipelines.yaml
├── azure-pipelines-NED-refresh.yml
├── requirements.txt
├── requirements-NED.txt
├── streamlit_app.py
├── dashboards/
│   └── demo_dashboard.py          # Investigation UX dashboard (tabs, paired BMU charts, caching)
├── src/
│   ├── apis/
│   │   ├── NEDBlob.py             # Cached Blob Parquet loaders with in-cache datetime parsing
│   │   ├── elexon.py              # Cached Elexon BMU mapping & guarded REMIT loader
│   │   ├── enappsys.py            # Cached EnAppSys wholesale loader with lazy KeyVault lookup
│   │   ├── lowcarboncontracts.py
│   │   └── neso.py
│   └── utils/
│       ├── dates.py
│       ├── figTrace.py
│       ├── globals.py             # Managed Identity credential & Azure endpoint configuration
│       └── keyvault.py            # Lazy SecretClient initialization
├── jobs/
│   └── ned_query.py
└── setup/
```

---

## 2. UX & Functional Summary

1. **Sidebar Investigation Controls (`Select units, period and overlays`)**:
   - Cross-technology BMU selection (`Fuel types (optional) -> Portfolio (optional) -> BMUs (up to 4)`).
   - Year-first date selection (`Year` defaulting to current calendar year) with drill-down by `Single Day`, `Week` (ISO Monday-Sunday, supporting boundary weeks), `Month`, or `Custom Date Range` (supporting cross-year historical queries).
   - Explicit `REMIT on operational charts` and `Bid/offer lines on price charts` checkboxes, with preset Bid/Offer pair selection (`Pair -1` default, `Pair +1`, `Pairs -1 and +1`, `All pairs`, `Custom selection`).
   - Explicit `Load investigation` gate and compact NESO branding at the bottom of the sidebar.
2. **Investigation Summary Cards**:
   - Five individual horizontal responsive cards displaying `BMUs`, `Fuel types`, `Portfolio`, `Loaded period`, and `Bid/offer`.
3. **Tabbed Analytical Views**:
   - `Unit & Prices`: Stacks up to 4 selected BMUs vertically, pairing each BMU's real `Operational Data` chart (left) and `Wholesale Data` + Bid/Offer chart (right) side-by-side on white cards.
   - `Dynamic Parameters`: 2-column grid of per-BMU Dynamic Parameters charts.
   - `Ancillary Services`, `Strike Prices`, and `ROC`: Dedicated tabs with clear corporate notices for upcoming data integrations.
   - `BOA Instructions`: 2-column grid of per-BMU BOA instruction tables filtered by BMU and date range.
   - `Data Tables`: Dedicated view for `Operational`, `Wholesale / bid-offer`, `Dynamic Parameters`, and `REMIT` datasets.

---

## 3. Startup Command (Azure App Service)

```bash
python -m streamlit run streamlit_app.py --server.port 8000 --server.address 0.0.0.0
```
