"""Primary controller for the Market Monitoring - Price Dashboard."""

from __future__ import annotations

from time import perf_counter
import pandas as pd
import streamlit as st

import src.apis.elexon as elexon_api
import src.apis.enappsys as enappsys_api
import src.apis.NEDBlob as ned_blob_api
from src.apis.elexon import getBMUMapping, getRemit
from src.apis.enappsys import getWholesalePrices
from src.apis.NEDBlob import (
    getBidOfferData,
    getBOAInstructionsData,
    getOperationalData,
    getStakeholders,
)
from src.components.operational_chart import (
    build_dynamic_params_figure as _build_dynamic_params_figure,
    build_operational_figure as _build_operational_figure,
)
from src.components.price_chart import (
    build_wholesale_figure as _build_wholesale_figure,
)
from src.components.sidebar import render_sidebar
from src.components.styles import (
    inject_ux_styles as _inject_ux_styles,
    render_notice as _render_notice,
    render_page_header,
)
from src.components.summary_cards import (
    render_pending_changes_banner,
    render_summary_cards as _render_summary_cards,
)
from src.models.investigation import (
    INVESTIGATION_TABS,
    MAX_BMU_SELECTIONS,
    PLOTLY_BG_COLOR,
    PLOTLY_THEME,
    InvestigationRequest,
    LoadedInvestigation,
)
from src.services.date_service import (
    format_iso_week_label,
    format_month_label,
    get_iso_week_count,
    resolve_compact_dates,
    to_datetime_bounds,
)
from src.services.diagnostics_service import (
    record_source_diagnostic as _record_source_diagnostic,
    timed_step,
)
from src.services.filter_service import (
    build_summary_fields,
    has_uncommitted_changes,
    resolve_bmu_fuel_summary,
)
from src.services.operational_service import (
    filter_operational_data as _filter_operational_data,
    prepare_operational_with_mapping as _prepare_operational_with_mapping,
)
from src.services.price_service import (
    build_wholesale_comparison_table as _build_wholesale_comparison_table,
    filter_wholesale_prices,
    prepare_bid_offer_selection,
)
from src.views import (
    render_ancillary_services_tab,
    render_boa_instructions_tab,
    render_data_tables_tab,
    render_dynamic_parameters_tab,
    render_roc_tab,
    render_strike_prices_tab,
    render_unit_prices_tab,
    render_yoy_comparison_view,
)


def _load_stakeholder_metadata(
    timings: dict[str, float],
) -> tuple[pd.DataFrame, list[str], list[str]]:
    """Load lightweight stakeholder metadata on initial page load."""
    try:
        with timed_step("stakeholder_metadata_load", timings):
            stakeholders, fuel_types, lead_parties = ned_blob_api.getStakeholders()
        _record_source_diagnostic(
            "Stakeholder Metadata",
            loaded=True,
            df=stakeholders,
            load_s=timings.get("stakeholder_metadata_load", 0.0),
        )
        return stakeholders, fuel_types, lead_parties
    except Exception as error:
        _record_source_diagnostic(
            "Stakeholder Metadata",
            loaded=False,
            load_s=timings.get("stakeholder_metadata_load", 0.0),
            message=str(error),
        )
        st.error("Stakeholder metadata could not be loaded.")
        st.exception(error)
        return (
            pd.DataFrame(columns=["sheetName", "Lead Party", "BMU ID"]),
            [],
            [],
        )


def _load_investigation_data(
    request: InvestigationRequest,
    timings: dict[str, float],
) -> LoadedInvestigation:
    """Load and prepare all active datasets for a submitted investigation request."""
    investigation = LoadedInvestigation(request=request)
    select_bmus = list(request.select_bmus)
    datetime_range = request.datetime_range
    show_remit = request.show_remit_overlay
    show_bid_offer = request.show_bid_offer_overlay

    # 1. Operational Data & Elexon BMU Mapping
    try:
        with timed_step("operational_data_load", timings):
            operational_data = ned_blob_api.getOperationalData()
    except Exception as error:
        investigation.operational_load_error = error
        _record_source_diagnostic(
            "NED Operational Data",
            loaded=False,
            load_s=timings.get("operational_data_load", 0.0),
            message=str(error),
        )
        operational_data = None

    if operational_data is not None:
        with timed_step("bmu_mapping_load", timings):
            bmu_mapping_df = elexon_api.getBMUMapping()
        _record_source_diagnostic(
            "Elexon BMU Mapping",
            loaded=bmu_mapping_df is not None,
            df=bmu_mapping_df,
            load_s=timings.get("bmu_mapping_load", 0.0),
        )

        with timed_step("operational_data_preparation", timings):
            prepared_operational = _prepare_operational_with_mapping(
                operational_data, bmu_mapping_df
            )
            if (
                not prepared_operational.empty
                and "GMT_DATETIME" in prepared_operational.columns
            ):
                st.session_state["operational_min_dt"] = (
                    prepared_operational["GMT_DATETIME"].min().to_pydatetime()
                )
                st.session_state["operational_max_dt"] = (
                    prepared_operational["GMT_DATETIME"].max().to_pydatetime()
                )

            investigation.filtered_operational_df = _filter_operational_data(
                prepared_operational,
                datetime_range[0],
                datetime_range[1],
                tuple(select_bmus),
            )

        _record_source_diagnostic(
            "NED Operational Data",
            loaded=True,
            df=operational_data,
            filtered_df=investigation.filtered_operational_df,
            timestamp_col="GMT_DATETIME",
            load_s=timings.get("operational_data_load", 0.0),
            prep_s=timings.get("operational_data_preparation", 0.0),
        )

    # 2. REMIT Data (Conditional on show_remit)
    remit_total_load_time = 0.0
    remit_row_count = 0
    filtered_op_df = investigation.filtered_operational_df

    if show_remit and not filtered_op_df.empty:
        for bmu in select_bmus:
            bmu_rows = filtered_op_df[filtered_op_df["BMU_ID"] == bmu]
            if bmu_rows.empty:
                continue
            elexon_bmu = (
                bmu_rows["ELEXON_BMU_ID"].iloc[0]
                if "ELEXON_BMU_ID" in bmu_rows.columns
                else None
            )
            if pd.notna(elexon_bmu) and str(elexon_bmu).strip():
                t_remit = perf_counter()
                remit_df = elexon_api.getRemit(
                    elexon_bmu,
                    datetime_range[0],
                    datetime_range[1],
                )
                remit_total_load_time += perf_counter() - t_remit
                if remit_df is not None and not remit_df.empty:
                    tagged_remit = remit_df.copy()
                    if "BMU_ID" not in tagged_remit.columns:
                        tagged_remit.insert(0, "BMU_ID", bmu)
                    investigation.remit_by_bmu[bmu] = tagged_remit
                    remit_row_count += len(tagged_remit)
            else:
                investigation.missing_remit_mapping_bmus.append(bmu)

    timings["remit_load_total"] = remit_total_load_time
    _record_source_diagnostic(
        "Elexon REMIT",
        loaded=show_remit,
        load_s=remit_total_load_time,
        message=(
            f"Loaded {remit_row_count} REMIT rows."
            if show_remit
            else "Skipped (REMIT overlay disabled)."
        ),
    )

    # 3. Wholesale Prices & Conditional Bid/Offer Data
    start_str = datetime_range[0].strftime("%Y%m%d%H%M")
    end_str = datetime_range[1].strftime("%Y%m%d%H%M")

    with timed_step("wholesale_api_load", timings):
        wholesale_prices = enappsys_api.getWholesalePrices(start_str, end_str)

    if wholesale_prices is not None and not wholesale_prices.empty:
        investigation.filtered_wholesale_df = filter_wholesale_prices(
            wholesale_prices,
            datetime_range[0],
            datetime_range[1],
        )
        _record_source_diagnostic(
            "EnAppSys Wholesale Prices",
            loaded=True,
            df=wholesale_prices,
            filtered_df=investigation.filtered_wholesale_df,
            timestamp_col="dateTime",
            load_s=timings.get("wholesale_api_load", 0.0),
        )
    else:
        _record_source_diagnostic(
            "EnAppSys Wholesale Prices",
            loaded=False,
            load_s=timings.get("wholesale_api_load", 0.0),
            message="No wholesale price data returned for submitted date range.",
        )

    if show_bid_offer:
        try:
            with timed_step("bid_offer_data_load", timings):
                bid_offer_data = ned_blob_api.getBidOfferData()
        except Exception as error:
            investigation.bid_offer_load_error = error
            _record_source_diagnostic(
                "NED Bid/Offer Data",
                loaded=False,
                load_s=timings.get("bid_offer_data_load", 0.0),
                message=str(error),
            )
            bid_offer_data = None

        if bid_offer_data is not None:
            with timed_step("bid_offer_preparation", timings):
                investigation.selected_bod_bmus_df = prepare_bid_offer_selection(
                    bid_offer_df=bid_offer_data,
                    start_dt=datetime_range[0],
                    end_dt=datetime_range[1],
                    select_bmus=select_bmus,
                )

            _record_source_diagnostic(
                "NED Bid/Offer Data",
                loaded=True,
                df=bid_offer_data,
                filtered_df=investigation.selected_bod_bmus_df,
                timestamp_col="GMT_DATETIME",
                load_s=timings.get("bid_offer_data_load", 0.0),
                prep_s=timings.get("bid_offer_preparation", 0.0),
            )
    else:
        _record_source_diagnostic(
            "NED Bid/Offer Data",
            loaded=False,
            message="Skipped (Bid/Offer overlay disabled).",
        )

    # 4. BOA Instructions Data
    try:
        with timed_step("boa_data_load", timings):
            investigation.boa_instructions_df = ned_blob_api.getBOAInstructionsData()
    except Exception as error:
        investigation.boa_load_error = error
        _record_source_diagnostic(
            "NED BOA Instructions",
            loaded=False,
            load_s=timings.get("boa_data_load", 0.0),
            message=str(error),
        )

    return investigation


def main() -> None:
    """Execute the Market Monitoring - Price Dashboard workflow."""
    _inject_ux_styles()
    render_page_header()

    if "step_timings" not in st.session_state:
        st.session_state["step_timings"] = {}
    timings = st.session_state["step_timings"]

    stakeholders, fuel_types, _ = _load_stakeholder_metadata(timings)
    draft_state = render_sidebar(stakeholders=stakeholders, fuel_types=fuel_types)

    if draft_state.get("selectedDashboard") == "YoY Comparison":
        render_yoy_comparison_view()
        return

    submitted = st.session_state.get("submitted_request")
    if submitted is None:
        st.info(
            f"Select up to {MAX_BMU_SELECTIONS} BMUs, choose a period and overlays in the sidebar, "
            "then click 'Load investigation'."
        )
        st.stop()
        return

    if has_uncommitted_changes(draft_state, submitted):
        render_pending_changes_banner()

    request = InvestigationRequest.from_session_dict(submitted)
    if not request.select_bmus:
        st.warning(
            f"Select between 1 and {MAX_BMU_SELECTIONS} BMUs and click 'Load investigation'."
        )
        st.stop()
        return

    _render_summary_cards(build_summary_fields(request, stakeholders))

    with timed_step("complete_submitted_request_duration", timings):
        investigation = _load_investigation_data(request, timings)

        (
            tab_unit_prices,
            tab_dynamic,
            tab_ancillary,
            tab_boa,
            tab_strike,
            tab_roc,
            tab_tables,
        ) = st.tabs(INVESTIGATION_TABS)

        with tab_unit_prices:
            render_unit_prices_tab(investigation, timings)

        with tab_dynamic:
            render_dynamic_parameters_tab(investigation, timings)

        with tab_ancillary:
            render_ancillary_services_tab()

        with tab_boa:
            render_boa_instructions_tab(investigation, timings)

        with tab_strike:
            render_strike_prices_tab()

        with tab_roc:
            render_roc_tab()

        with tab_tables:
            render_data_tables_tab(investigation)


if __name__ == "__main__":
    main()
