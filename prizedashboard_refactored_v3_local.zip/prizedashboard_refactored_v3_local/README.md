# Market Monitoring - Price Dashboard (Refactored v3 Release: Local Laptop / Windows 11 + VS Code + Conda + `.env`)

This release provides the v3 domain-modular implementation of the **Market Monitoring - Price Dashboard**, expanding BMU selection to **up to 6 BMUs** and wiring the sidebar `Dashboards` picker to switch between **`Current Year`** and a **`YoY Comparison`** placeholder within the shared dashboard shell. Configured for **local execution on a Windows 11 laptop** using **VS Code**, **Conda** (`python=3.11`), `DefaultAzureCredential()` (`az login`), and a local **`.env`** file for EnAppSys credentials.

---

## 1. Quick Start on Windows 11 (VS Code + Conda)

### Step 1: Open in VS Code
Open the `prizedashboard_refactored_v3_local` folder in Visual Studio Code (`File > Open Folder...`).

### Step 2: Create & Activate the Conda Environment
In the VS Code terminal (**Command Prompt** or **Anaconda Prompt**):

```bat
conda env create -f environment.yml
conda activate price-dashboard-local
```
*(Or run `setup_conda_env.bat`.)*

Select the **`price-dashboard-local`** Conda interpreter in VS Code (`Ctrl+Shift+P` -> `Python: Select Interpreter` -> `price-dashboard-local`).

### Step 3: Verify `.env` & Authenticate with Azure
1. If `.env` is not already present, copy `.env.example` to `.env` in the project root:
   ```bat
   copy .env.example .env
   ```
2. Verify your EnAppSys credentials and Azure Blob Storage settings in `.env`:
   ```dotenv
   ENAPPUSR=your_enappsys_username
   ENAPP=your_enappsys_password

   AZURE_STORAGE_ACCOUNT_URL=https://<your-storage-account>.blob.core.windows.net
   AZURE_STORAGE_CONTAINER_NAME=<your-container-name>
   ```
3. Run `az login` in your terminal so `DefaultAzureCredential()` can read from Azure Blob Storage:
   ```bat
   az login
   ```

### Step 4: Run the Dashboard
```bat
python -m streamlit run streamlit_app.py --server.port 8000
```
*(Or press **`F5`** in VS Code and choose **`Streamlit: Run Market Monitoring Dashboard`**, or run **`run_dashboard.bat`**.)*

---

## 2. Highlights in Refactored v3

* **Expanded BMU Selection Limit**: Analysts can select **up to 6 BMUs** (`MAX_BMU_SELECTIONS = 6`) for side-by-side comparison.
* **Dashboard Switcher (`Current Year` & `YoY Comparison`)**: The bottom `Dashboards` picker offers `Current Year` (full single-period investigation view) and `YoY Comparison` (preserving the same sidebar/shell design with a clear notice that YoY comparison will be developed in a future iteration).
* **Retained v2 Enhancements**: Compact `Date selection` radio controls (`Specific Day`, `Specific Week` [`Week 48 - 23-29 Nov 2026`], `Specific Month`, `Custom Date Range`), `DA PN` horizon (`#1E40AF`, `legendonly`), 6-trace legend-driven Bid/Offer price chart, subtle yellow REMIT time bands bounded to the unit's MW range, and overlap-proof HTML card headings above every Plotly canvas.
