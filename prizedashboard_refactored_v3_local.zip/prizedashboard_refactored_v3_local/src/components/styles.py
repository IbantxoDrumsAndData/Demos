"""Dashboard CSS styling, page header, and informational notice banners."""

from __future__ import annotations

import html
import streamlit as st


def inject_ux_styles() -> None:
    """Inject UAT-approved CSS styles for layout, cards, sidebar, and calendar pop-up."""
    st.markdown(
        """
        <style>
        [data-testid="stMainBlockContainer"] {
            max-width: none;
            padding-left: 10mm;
            padding-right: 10mm;
        }

        .ux-head {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 8px;
        }

        .ux-head h2 {
            font-size: 25px;
            margin: 0 0 4px 0;
            color: #233044;
        }

        .ux-muted {
            color: #657387;
            font-size: 12px;
            margin: 0;
        }

        .ux-pending {
            color: #77460C;
            background: #FFF0D7;
            border: 1px solid #F0D4A8;
            padding: 9px 12px;
            border-radius: 5px;
            font-size: 12px;
            margin: 12px 0;
        }

        .ux-summary-grid {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 12px;
            margin: 16px 0 20px 0;
        }

        .ux-summary-card {
            min-width: 0;
            background: #FFFFFF;
            border: 1px solid #D5DCE5;
            border-radius: 9px;
            padding: 15px 16px;
            box-shadow: 0 2px 6px rgba(25, 35, 50, 0.035);
        }

        .ux-summary-card span {
            display: block;
            color: #667286;
            font-size: 11px;
            margin-bottom: 4px;
        }

        .ux-summary-card strong {
            display: block;
            color: #233044;
            font-size: 13px;
            overflow-wrap: anywhere;
            line-height: 1.5;
        }

        .ux-notice {
            padding: 14px 16px;
            border-radius: 6px;
            background: #E2E9F6;
            color: #364D71;
            font-size: 12px;
            border: 1px solid #C8D6EC;
        }

        .ux-card-title {
            font-size: 16px;
            font-weight: 700;
            color: #233044;
            margin: 0 0 8px 0;
            padding-bottom: 6px;
            border-bottom: 1px solid #EEF2F6;
            line-height: 1.3;
        }

        .ux-sidebar-title {
            font-size: 19px;
            font-weight: 700;
            color: #FFFFFF;
            margin: 0 0 8px 0;
            line-height: 1.3;
        }

        .ux-sidebar-help {
            font-size: 12px;
            color: #E1C9DD;
            margin: 4px 0 10px 0;
        }

        .ux-sidebar-section-label {
            font-size: 12px;
            font-weight: 650;
            color: #FFFFFF;
            margin: 12px 0 6px 0;
        }

        .ux-sidebar-foot {
            border-top: 1px solid #78456E;
            padding-top: 14px;
            margin-top: 18px;
        }

        .ux-sidebar-foot-note {
            display: block;
            color: #DEC7D9;
            font-size: 10px;
            margin: 4px 0 0 0;
            line-height: 1.4;
        }

        [data-testid="stMain"] [data-testid="stVerticalBlockBorderWrapper"] {
            background-color: #FFFFFF;
            border: 1px solid #D5DCE5;
            border-radius: 8px;
        }

        [data-testid="stSidebar"] button[kind="primary"] {
            background-color: #BD88B9 !important;
            color: #290723 !important;
            font-weight: 700 !important;
            border: 0 !important;
        }

        @media (max-width: 1200px) {
            .ux-summary-grid {
                grid-template-columns: repeat(3, minmax(0, 1fr));
            }
        }

        @media (max-width: 760px) {
            .ux-summary-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 400px) {
            .ux-summary-grid {
                grid-template-columns: minmax(0, 1fr);
            }
        }

        /*
         * Streamlit calendar day numbers.
         *
         * The rendered DOM uses React Aria pressable divs rather
         * than standard HTML buttons.
         */
        div[data-react-aria-pressable="true"]
        [role="button"] {
            color: #FFFFFF !important;
            -webkit-text-fill-color: #FFFFFF !important;
        }

        /*
         * Direct selector for current Streamlit calendar day elements.
         * aria-label contains the full date.
         */
        div[data-react-aria-pressable="true"][role="button"][aria-label] {
            color: #FFFFFF !important;
            -webkit-text-fill-color: #FFFFFF !important;
        }

        /*
         * Dates outside the current month remain visible,
         * but visually secondary.
         */
        div[data-react-aria-pressable="true"]
        [role="button"][aria-label][data-disabled="true"],
        div[data-react-aria-pressable="true"]
        [role="button"][aria-label][data-outside-month="true"],
        div[data-react-aria-pressable="true"][role="button"]
        [aria-label][data-disabled="true"],
        div[data-react-aria-pressable="true"][role="button"]
        [aria-label][data-outside-month="true"] {
            color: rgba(255, 255, 255, 0.40) !important;
            -webkit-text-fill-color:
                rgba(255, 255, 255, 0.40) !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_page_header() -> None:
    """Render the dashboard title and subtitle block."""
    st.markdown(
        """
        <div class="ux-head">
            <div>
                <h2>Market Monitoring - Price Dashboard</h2>
                <p class="ux-muted">Operational behaviour and prices together for each BMU.</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_notice(text: str) -> None:
    """Render a clean corporate informational banner."""
    st.markdown(
        f'<div class="ux-notice">{html.escape(text)}</div>',
        unsafe_allow_html=True,
    )


def render_card_title(text: str) -> None:
    """Render a chart card heading above the Plotly canvas so legends can never overlap it."""
    st.markdown(
        f'<div class="ux-card-title">{html.escape(text)}</div>',
        unsafe_allow_html=True,
    )

