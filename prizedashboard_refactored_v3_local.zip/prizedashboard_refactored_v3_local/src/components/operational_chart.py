"""Plotly figure builders for Operational Data (with subtle yellow REMIT time bands) and Dynamic Parameters."""

from __future__ import annotations

from datetime import datetime
from typing import Any
import pandas as pd
import plotly.graph_objects as go

from src.models.investigation import (
    CHART_HEIGHT,
    PLOTLY_BG_COLOR,
    PLOTLY_THEME,
)
from src.services.operational_service import prepare_remit_time_bands
from src.utils.figTrace import figTrace

REMIT_BAND_FILL = "rgba(250, 204, 21, 0.20)"
REMIT_BAND_BORDER = "rgba(234, 179, 8, 0.35)"

CORE_OPERATIONAL_SERIES: list[dict[str, Any]] = [
    {
        "column": "FINAL_PHYSICAL_NOTIFICATION_MW",
        "name": "FPN",
        "color": "#702082",
        "width": 3.5,
        "dash": "solid",
    },
    {
        "column": "OPERATIONAL_METERED_OUTPUT_MW",
        "name": "Metered Output",
        "color": "#E74B20",
        "width": 3.5,
        "dash": "solid",
    },
    {
        "column": "MAXIMUM_EXPORT_LIMIT",
        "name": "MEL",
        "color": "#25256A",
        "width": 2.5,
        "dash": "dash",
    },
    {
        "column": "STABLEEXPORTLIMIT",
        "name": "SEL",
        "color": "#CAA51A",
        "width": 2.5,
        "dash": "dash",
    },
    {
        "column": "MAXIMUM_IMPORT_LIMIT",
        "name": "MIL",
        "color": "#2EA44F",
        "width": 2.5,
        "dash": "solid",
    },
]

PN_HORIZON_SERIES: list[dict[str, str]] = [
    {
        "column": "DAYAHEADIPNSUBMISSION_MW",
        "name": "DA PN",
        "color": "#1E40AF",
    },
    {
        "column": "PN4HRSAHEADOFEFFECTIVE_MW",
        "name": "4H PN",
        "color": "#62B5D8",
    },
    {
        "column": "PN6HRSAHEADOFEFFECTIVE_MW",
        "name": "6H PN",
        "color": "#58B8AE",
    },
    {
        "column": "PN8HRSAHEADOFEFFECTIVE_MW",
        "name": "8H PN",
        "color": "#D66AA5",
    },
    {
        "column": "PN12HRSAHEADOFEFFECTIVE_MW",
        "name": "12H PN",
        "color": "#D83F91",
    },
    {
        "column": "PN18HRSAHEADOFEFFECTIVE_MW",
        "name": "18H PN",
        "color": "#6F9423",
    },
]


def build_operational_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    show_remit: bool,
    remit_df: pd.DataFrame | None,
) -> go.Figure:
    """Build the operational Plotly figure with core series, optional PN horizons, and yellow REMIT bands."""
    operational_fig = go.Figure()

    # Core operational series
    for series in CORE_OPERATIONAL_SERIES:
        if series["column"] not in bmu_df.columns:
            continue
        operational_fig.add_trace(
            go.Scatter(
                x=bmu_df["GMT_DATETIME"],
                y=bmu_df[series["column"]],
                mode="lines",
                name=series["name"],
                line=dict(
                    color=series["color"],
                    width=series["width"],
                    dash=series["dash"],
                ),
                hovertemplate=(
                    f"<b>{series['name']}</b><br>"
                    "%{x|%d %b %Y %H:%M}<br>"
                    "%{y:,.1f} MW"
                    "<extra></extra>"
                ),
            )
        )

    # Optional PN horizons (legendonly by default, including DA PN)
    for horizon in PN_HORIZON_SERIES:
        if horizon["column"] not in bmu_df.columns:
            continue
        operational_fig.add_trace(
            go.Scatter(
                x=bmu_df["GMT_DATETIME"],
                y=bmu_df[horizon["column"]],
                mode="lines",
                name=horizon["name"],
                line=dict(
                    color=horizon["color"],
                    width=2,
                    dash="dot",
                ),
                hovertemplate=(
                    f"<b>{horizon['name']}</b><br>"
                    "%{x|%d %b %Y %H:%M}<br>"
                    "%{y:,.1f} MW"
                    "<extra></extra>"
                ),
                visible="legendonly",
            )
        )

    # Subtle yellow REMIT time bands bounded cleanly from x-axis baseline (0 / min MW) to max MW
    if show_remit:
        remit_bands = prepare_remit_time_bands(remit_df, start_dt, end_dt)
        remit_traces: list[go.Bar] = []

        core_cols = [
            s["column"]
            for s in CORE_OPERATIONAL_SERIES
            if s["column"] in bmu_df.columns
        ]
        if core_cols and not bmu_df.empty:
            numeric_vals = pd.concat(
                [pd.to_numeric(bmu_df[col], errors="coerce") for col in core_cols],
                ignore_index=True,
            ).dropna()
            min_mw = float(numeric_vals.min()) if not numeric_vals.empty else 0.0
            max_mw = float(numeric_vals.max()) if not numeric_vals.empty else 1.0
        else:
            min_mw = 0.0
            max_mw = 1.0

        band_base = min(0.0, min_mw)
        band_top = max(max_mw, band_base + 1.0)
        band_height = band_top - band_base

        for idx, band in enumerate(remit_bands):
            remit_traces.append(
                go.Bar(
                    x=[band["midpoint"]],
                    y=[band_height],
                    width=[band["width_ms"]],
                    base=[band_base],
                    name="REMIT",
                    legendgroup="REMIT",
                    marker=dict(
                        color=REMIT_BAND_FILL,
                        line=dict(
                            color=REMIT_BAND_BORDER,
                            width=1,
                        ),
                    ),
                    hovertemplate=band["hover_text"],
                    showlegend=(idx == 0),
                )
            )

        if remit_traces:
            operational_fig.add_traces(remit_traces)

    layout_kwargs: dict[str, Any] = dict(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        xaxis_title="Date/Time",
        yaxis_title="MW",
        height=CHART_HEIGHT,
        margin=dict(
            l=55,
            r=20,
            t=36,
            b=55,
            autoexpand=True,
        ),
        hovermode="x unified",
        barmode="overlay",
        legend=dict(
            orientation="h",
            x=0,
            xanchor="left",
            y=1.02,
            yanchor="bottom",
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )

    operational_fig.update_layout(**layout_kwargs)
    return operational_fig


def build_dynamic_params_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
) -> go.Figure:
    """Build the Dynamic Parameters Plotly figure for a single BMU."""
    dynamic_fig = go.Figure()

    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGENOTICETODEVIATEFROMZERO_MINS"],
        "lines",
        "Average NDZ",
        line=dict(width=3),
    )
    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGEMINIMUMZEROTIME_MINS"],
        "lines",
        "Average MZT",
        line=dict(width=3),
    )
    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGEMINIMUMNONZEROTIME_MINS"],
        "lines",
        "Average MNZT",
        line=dict(width=3),
    )

    dynamic_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        xaxis_title="Date/Time",
        yaxis_title="Time (Minutes)",
        height=CHART_HEIGHT,
        margin=dict(
            l=55,
            r=20,
            t=36,
            b=55,
            autoexpand=True,
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    dynamic_fig.update_xaxes(range=[start_dt, end_dt])
    return dynamic_fig
