"""Pure date and timestamp boundary resolution helpers for compact Date Selection."""

from __future__ import annotations

import calendar
from datetime import date, datetime, time


def get_iso_week_count(year: int) -> int:
    """Return total number of ISO weeks (52 or 53) for the given calendar year."""
    return date(int(year), 12, 28).isocalendar()[1]


def format_iso_week_label(iso_year: int, iso_week: int) -> str:
    """Format an ISO week (Monday-Sunday) as 'Week 48 - 23-29 Nov 2026'."""
    start_d = date.fromisocalendar(int(iso_year), int(iso_week), 1)
    end_d = date.fromisocalendar(int(iso_year), int(iso_week), 7)

    if start_d.year == end_d.year and start_d.month == end_d.month:
        return (
            f"Week {iso_week} - "
            f"{start_d.strftime('%d')}-{end_d.strftime('%d %b %Y')}"
        )
    if start_d.year == end_d.year:
        return (
            f"Week {iso_week} - "
            f"{start_d.strftime('%d %b')}-{end_d.strftime('%d %b %Y')}"
        )
    return (
        f"Week {iso_week} - "
        f"{start_d.strftime('%d %b %Y')}-{end_d.strftime('%d %b %Y')}"
    )


def get_recent_iso_week_options(reference_date: date) -> list[tuple[int, int]]:
    """Return (iso_year, iso_week) tuples for current and previous calendar year, newest first."""
    curr_year = reference_date.year
    options: list[tuple[int, int]] = []
    for yr in (curr_year, curr_year - 1):
        max_w = get_iso_week_count(yr)
        for wk in range(max_w, 0, -1):
            options.append((yr, wk))
    return options


def format_month_label(year: int, month: int) -> str:
    """Format a calendar month as 'November 2026'."""
    return date(int(year), int(month), 1).strftime("%B %Y")


def get_recent_month_options(reference_date: date) -> list[tuple[int, int]]:
    """Return (year, month) tuples for current and previous calendar year, newest first."""
    curr_year = reference_date.year
    options: list[tuple[int, int]] = []
    for yr in (curr_year, curr_year - 1):
        for mo in range(12, 0, -1):
            options.append((yr, mo))
    return options


def resolve_compact_dates(
    mode: str,
    selected_day: date | None = None,
    selected_iso_week: tuple[int, int] | None = None,
    selected_year_month: tuple[int, int] | None = None,
    custom_start: date | None = None,
    custom_end: date | None = None,
    reference_date: date | None = None,
) -> tuple[date, date]:
    """Resolve inclusive start and end calendar dates for the compact Date Selection modes."""
    ref = reference_date or date.today()

    if mode == "Specific Day":
        day_val = selected_day if selected_day is not None else ref
        return day_val, day_val

    if mode == "Specific Week":
        if selected_iso_week is None:
            iso_cal = ref.isocalendar()
            iso_year, iso_week = int(iso_cal[0]), int(iso_cal[1])
        else:
            iso_year, iso_week = int(selected_iso_week[0]), int(selected_iso_week[1])
        max_w = get_iso_week_count(iso_year)
        wk = max(1, min(iso_week, max_w))
        return date.fromisocalendar(iso_year, wk, 1), date.fromisocalendar(
            iso_year, wk, 7
        )

    if mode == "Specific Month":
        if selected_year_month is None:
            yr, mo = ref.year, ref.month
        else:
            yr, mo = int(selected_year_month[0]), int(selected_year_month[1])
        mo = max(1, min(mo, 12))
        last_day = calendar.monthrange(yr, mo)[1]
        return date(yr, mo, 1), date(yr, mo, last_day)

    start_val = custom_start if custom_start is not None else date(ref.year, ref.month, 1)
    end_val = custom_end if custom_end is not None else ref
    return start_val, end_val


def to_datetime_bounds(start_d: date, end_d: date) -> tuple[datetime, datetime]:
    """Convert inclusive start and end dates into full-day datetime boundaries."""
    return (
        datetime.combine(start_d, time(0, 0, 0)),
        datetime.combine(end_d, time(23, 59, 59)),
    )
