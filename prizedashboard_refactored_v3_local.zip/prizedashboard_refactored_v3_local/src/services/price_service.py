"""Wholesale price filtering, Bid/Offer pivot table, and BOA instruction filtering helpers."""

from __future__ import annotations

from datetime import datetime
import pandas as pd
import streamlit as st

from src.models.investigation import (
    ALLOWED_BID_OFFER_PAIR_IDS,
    BID_OFFER_TRACE_SPECS,
    BOA_DISPLAY_COLUMNS,
)


def filter_wholesale_prices(
    wholesale_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
) -> pd.DataFrame:
    """Filter wholesale price DataFrame to the submitted datetime range."""
    if wholesale_df is None or wholesale_df.empty:
        return pd.DataFrame()

    return wholesale_df[
        (wholesale_df["dateTime"] >= start_dt) & (wholesale_df["dateTime"] <= end_dt)
    ]


def prepare_bid_offer_selection(
    bid_offer_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
    select_bmus: list[str] | tuple[str, ...],
) -> pd.DataFrame:
    """Filter Bid/Offer data by date, BMU, and allowed pairs (-3..-1 Bids, +1..+3 Offers)."""
    if bid_offer_df is None or bid_offer_df.empty:
        return pd.DataFrame()

    filtered_bod = bid_offer_df[
        (bid_offer_df["GMT_DATETIME"] >= start_dt)
        & (bid_offer_df["GMT_DATETIME"] <= end_dt)
        & (bid_offer_df["BMU_ID"].isin(select_bmus))
        & (bid_offer_df["BOPAIR_ID"].isin(ALLOWED_BID_OFFER_PAIR_IDS))
    ]
    return filtered_bod


@st.cache_data(ttl=3600, show_spinner=False)
def build_wholesale_comparison_table(
    filtered_wholesale_df: pd.DataFrame,
    filtered_bid_offer_df: pd.DataFrame,
) -> pd.DataFrame:
    """Pivot Bid (-1,-2,-3) and Offer (+1,+2,+3) columns and left-join against wholesale prices."""
    if filtered_bid_offer_df is None or filtered_bid_offer_df.empty:
        return (
            filtered_wholesale_df.copy()
            if filtered_wholesale_df is not None
            else pd.DataFrame()
        )

    bmus = sorted(filtered_bid_offer_df["BMU_ID"].dropna().astype(str).unique().tolist())
    series_frames: list[pd.Series] = []

    for bmu in bmus:
        bmu_df = filtered_bid_offer_df[filtered_bid_offer_df["BMU_ID"] == bmu]
        for spec in BID_OFFER_TRACE_SPECS:
            pair_id = spec["pair_id"]
            col_name = spec["column"]
            trace_label = spec["name"]
            pair_df = bmu_df[bmu_df["BOPAIR_ID"] == pair_id]
            if pair_df.empty or col_name not in pair_df.columns:
                continue
            s = (
                pair_df.groupby("GMT_DATETIME", sort=True)[col_name]
                .first()
                .rename(f"{bmu} | {trace_label}")
            )
            series_frames.append(s)

    if not series_frames:
        return (
            filtered_wholesale_df.copy()
            if filtered_wholesale_df is not None
            else pd.DataFrame()
        )

    bid_offer_pivot_df = pd.concat(series_frames, axis=1).reset_index()

    if filtered_wholesale_df is None or filtered_wholesale_df.empty:
        return bid_offer_pivot_df

    return (
        filtered_wholesale_df.copy()
        .merge(
            bid_offer_pivot_df,
            left_on="dateTime",
            right_on="GMT_DATETIME",
            how="left",
        )
        .drop(columns=["GMT_DATETIME"], errors="ignore")
    )


def filter_boa_instructions_for_bmu(
    boa_df: pd.DataFrame | None,
    bmu: str,
    start_dt: datetime,
    end_dt: datetime,
) -> pd.DataFrame:
    """Filter BOA instructions by BMU and datetime range, sorted descending with standard 7 columns."""
    if boa_df is None or boa_df.empty:
        return pd.DataFrame(columns=BOA_DISPLAY_COLUMNS)

    filtered = boa_df[
        (boa_df["BMU_ID"] == bmu)
        & (boa_df["GMT_DATETIME"] >= start_dt)
        & (boa_df["GMT_DATETIME"] <= end_dt)
    ].sort_values(
        "GMT_DATETIME",
        ascending=False,
    )
    return filtered[BOA_DISPLAY_COLUMNS]
