"""Placeholder view for the Year-on-Year (YoY) Comparison dashboard."""

from __future__ import annotations

import streamlit as st

from src.components.styles import render_notice


def render_yoy_comparison_view() -> None:
    """Render the YoY Comparison placeholder inside the shared dashboard shell."""
    st.subheader("Year-on-Year (YoY) Comparison")
    render_notice(
        "Year-on-Year (YoY) Comparison will be developed in a future iteration. "
        "Select 'Current Year' under Dashboards in the sidebar to return to single-period investigations."
    )
