"""Per-tab analytical view modules for the Market Monitoring dashboard."""

from src.views.ancillary_services_view import render_ancillary_services_tab
from src.views.boa_instructions_view import render_boa_instructions_tab
from src.views.data_tables_view import render_data_tables_tab
from src.views.dynamic_parameters_view import render_dynamic_parameters_tab
from src.views.roc_view import render_roc_tab
from src.views.strike_prices_view import render_strike_prices_tab
from src.views.unit_prices_view import render_unit_prices_tab
from src.views.yoy_comparison_view import render_yoy_comparison_view

__all__ = [
    "render_ancillary_services_tab",
    "render_boa_instructions_tab",
    "render_data_tables_tab",
    "render_dynamic_parameters_tab",
    "render_roc_tab",
    "render_strike_prices_tab",
    "render_unit_prices_tab",
    "render_yoy_comparison_view",
]

