"""Shared UI helpers: NESO official design system, colors, badges and navigation."""

from __future__ import annotations

import base64
import html
import re
from collections.abc import Iterable
from datetime import datetime
from pathlib import Path

import streamlit as st

PAGES = {
    "catalogue": "neso_app/views/catalogue.py",
    "dataset": "neso_app/views/dataset.py",
    "explorer": "neso_app/views/explorer.py",
    "guide": "neso_app/views/guide.py",
}

# Load the local NESO SVG logo
_LOGO_PATH = Path(__file__).parent / "assets" / "neso_logo.svg"
try:
    _LOGO_SVG = _LOGO_PATH.read_text(encoding="utf-8")
    _LOGO_B64 = base64.b64encode(_LOGO_SVG.encode("utf-8")).decode("ascii")
    LOGO_IMG_SRC = f"data:image/svg+xml;base64,{_LOGO_B64}"
except Exception:
    LOGO_IMG_SRC = "https://www.neso.energy/themes/custom/neso_theme/logo.svg"

# NESO Official Design System CSS
# Primary Brand: #642846 (NESO Plum)
# Secondary Accent: #547047 (NESO Olive Green)
# Background: #F8F9FA
# Cards: #FFFFFF with #E2E8F0 borders
_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

html, body, [class*="css"], .stApp {
  font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
  color: #1E293B;
  background-color: #F8F9FA;
}

h1, h2, h3, h4, h5, h6 {
  font-family: 'Poppins', sans-serif !important;
  color: #1E293B !important;
  font-weight: 600 !important;
  letter-spacing: -0.01em;
}

/* Completely hide Streamlit's fixed header chrome, deploy button, and toolbar so nothing overlaps or clips the banner */
header,
header[data-testid="stHeader"],
.stAppHeader,
[data-testid="stHeader"],
[data-testid="stAppHeader"],
[data-testid="stToolbar"],
[data-testid="stHeaderActionElements"],
[data-testid="stDeployButton"],
[data-testid="stDecoration"],
[data-testid="stMainMenu"] {
  display: none !important;
  visibility: hidden !important;
  height: 0 !important;
  min-height: 0 !important;
  max-height: 0 !important;
  padding: 0 !important;
  margin: 0 !important;
  border: 0 !important;
  opacity: 0 !important;
  pointer-events: none !important;
  position: absolute !important;
  top: -9999px !important;
}

.stMainBlockContainer, [data-testid="stMainBlockContainer"], .block-container, [data-testid="block-container"] {
  padding-top: 3.5rem !important;
  padding-bottom: 3.5rem !important;
  max-width: 1280px !important;
}

/* NESO Top Brand Bar - All 4 corners rounded, dedicated top margin */
.neso-top-bar {
  background-color: #642846 !important;
  color: #FFFFFF !important;
  padding: 1.15rem 1.75rem !important;
  border-radius: 14px !important;
  -webkit-border-radius: 14px !important;
  border: 1px solid #501937 !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  margin-top: 1.5rem !important;
  margin-bottom: 2rem !important;
  box-shadow: 0 4px 16px rgba(100, 40, 70, 0.12) !important;
  overflow: hidden !important;
  position: relative !important;
  z-index: 10 !important;
}
.neso-top-bar .brand-title {
  font-size: 1.05rem;
  font-weight: 600;
  color: #FFFFFF;
  letter-spacing: 0.02em;
}
.neso-top-bar .brand-sub {
  font-size: 0.82rem;
  color: #F1DCE6;
}

/* NESO Official Hero Banner (Olive Green pill shape as seen on neso.energy/data-portal) */
.neso-hero {
  background-color: #547047;
  color: #FFFFFF;
  padding: 2.4rem 2.2rem;
  border-radius: 16px;
  text-align: center;
  margin-bottom: 1.75rem;
  border: 1px solid #48613D;
  box-shadow: 0 4px 16px rgba(84, 112, 71, 0.12);
}
.neso-hero .neso-eyebrow {
  text-transform: uppercase;
  letter-spacing: 0.14em;
  font-size: 0.76rem;
  font-weight: 600;
  color: #D3E7CB;
  margin-bottom: 0.45rem;
}
.neso-hero h1 {
  font-size: 2.15rem !important;
  color: #FFFFFF !important;
  margin: 0 0 0.55rem !important;
  line-height: 1.25;
  font-weight: 600 !important;
}
.neso-hero p {
  color: #E6F0E2;
  font-size: 1rem;
  max-width: 780px;
  margin: 0 auto;
  line-height: 1.55;
  font-weight: 400;
}

/* Sub-page Header (Clean, professional card) */
.neso-sub-hero {
  background-color: #FFFFFF;
  border: 1px solid #E2E8F0;
  border-left: 5px solid #642846;
  padding: 1.5rem 1.75rem;
  border-radius: 8px;
  margin-bottom: 1.4rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.03);
}
.neso-sub-hero .neso-eyebrow {
  text-transform: uppercase;
  letter-spacing: 0.12em;
  font-size: 0.74rem;
  font-weight: 600;
  color: #642846;
  margin-bottom: 0.25rem;
}
.neso-sub-hero h1 {
  font-size: 1.85rem !important;
  color: #1E293B !important;
  margin: 0 0 0.4rem !important;
  line-height: 1.25;
}
.neso-sub-hero p {
  color: #64748B;
  font-size: 0.95rem;
  margin: 0;
  line-height: 1.5;
}

/* Badges (Corporate style, clean outlines, no icons) */
.neso-badges {
  margin: 0.35rem 0 0.5rem;
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
}
.neso-badge {
  display: inline-block;
  white-space: nowrap;
  padding: 0.22rem 0.65rem;
  border-radius: 4px;
  font-size: 0.74rem;
  font-weight: 500;
  border: 1px solid;
  letter-spacing: 0.01em;
}
.tone-plum   { color: #642846; background: #FAF0F4; border-color: #E8CCD9; }
.tone-green  { color: #166534; background: #ECFDF5; border-color: #BBF7D0; }
.tone-olive  { color: #354E2C; background: #F2F7F0; border-color: #CDDDCA; }
.tone-amber  { color: #92400E; background: #FFFBEB; border-color: #FDE68A; }
.tone-slate  { color: #475569; background: #F1F5F9; border-color: #E2E8F0; }

/* Dataset and Resource Cards */
[class*="st-key-card_"] {
  background: #FFFFFF !important;
  border: 1px solid #E2E8F0 !important;
  border-radius: 8px !important;
  padding: 1.2rem 1.25rem !important;
  box-shadow: 0 1px 3px rgba(0,0,0,0.03);
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
[class*="st-key-card_"]:hover {
  border-color: #642846 !important;
  box-shadow: 0 4px 12px rgba(100, 40, 70, 0.08);
}
.neso-card-title {
  font-size: 1.05rem;
  font-weight: 600;
  color: #1E293B;
  line-height: 1.35;
  margin: 0.25rem 0 0.4rem;
}
.neso-card-text {
  color: #64748B;
  font-size: 0.86rem;
  line-height: 1.55;
  min-height: 4.5em;
  margin-bottom: 0.5rem;
}
.neso-meta {
  color: #64748B;
  font-size: 0.78rem;
}
.neso-meta b {
  color: #334155;
  font-weight: 600;
}
.neso-section {
  font-size: 1.2rem;
  font-weight: 600;
  color: #1E293B;
  margin: 1.5rem 0 0.65rem;
  padding-bottom: 0.35rem;
  border-bottom: 2px solid #E2E8F0;
}
.neso-kv {
  display: grid;
  grid-template-columns: 110px 1fr;
  gap: 0.45rem 0.8rem;
  font-size: 0.86rem;
}
.neso-kv dt {
  color: #64748B;
  font-weight: 500;
}
.neso-kv dd {
  color: #1E293B;
  margin: 0;
}

/* Metric Cards */
[data-testid="stMetric"] {
  background: #FFFFFF !important;
  border: 1px solid #E2E8F0 !important;
  border-radius: 8px !important;
  padding: 0.9rem 1.1rem !important;
  box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}
[data-testid="stMetricValue"] {
  font-family: 'Poppins', sans-serif !important;
  color: #642846 !important;
  font-weight: 600 !important;
  font-size: clamp(1.4rem, 2vw, 1.85rem) !important;
}
[data-testid="stMetricLabel"] p {
  color: #64748B !important;
  font-size: 0.82rem !important;
  font-weight: 500 !important;
}

/* Professional Buttons (NESO Plum and clean outlines) */
.stButton > button, .stDownloadButton > button {
  border-radius: 6px !important;
  font-family: 'Poppins', sans-serif !important;
  font-weight: 600 !important;
  font-size: 0.875rem !important;
  padding: 0.45rem 1rem !important;
  transition: all 0.15s ease !important;
}
.stButton > button[kind="primary"], .stDownloadButton > button[kind="primary"] {
  background-color: #642846 !important;
  color: #FFFFFF !important;
  border: 1px solid #642846 !important;
}
.stButton > button[kind="primary"]:hover, .stDownloadButton > button[kind="primary"]:hover {
  background-color: #4E1D35 !important;
  border-color: #4E1D35 !important;
}
.stButton > button[kind="secondary"], .stDownloadButton > button[kind="secondary"], .stLinkButton > a {
  background-color: #FFFFFF !important;
  color: #334155 !important;
  border: 1px solid #CBD5E1 !important;
  border-radius: 6px !important;
  font-family: 'Poppins', sans-serif !important;
  font-weight: 500 !important;
  font-size: 0.875rem !important;
}
.stButton > button[kind="secondary"]:hover, .stDownloadButton > button[kind="secondary"]:hover, .stLinkButton > a:hover {
  border-color: #642846 !important;
  color: #642846 !important;
}

/* Sidebar */
[data-testid="stSidebar"] {
  background-color: #FFFFFF !important;
  border-right: 1px solid #E2E8F0 !important;
}

/* Clean Form Controls */
.stTextInput input, .stSelectbox [data-baseweb="select"] {
  border-radius: 6px !important;
}

/* Tabs indicator in NESO Plum */
button[data-baseweb="tab"][aria-selected="true"] {
  color: #642846 !important;
  border-bottom-color: #642846 !important;
}
"""


def inject_css() -> None:
    st.markdown(f"<style>{_CSS}</style>", unsafe_allow_html=True)


def top_brand_bar() -> None:
    """Render the official NESO burgundy top brand bar."""
    st.markdown(
        f"""<div class="neso-top-bar" style="background-color:#642846;color:#FFFFFF;padding:1.15rem 1.75rem;border-radius:14px;-webkit-border-radius:14px;border:1px solid #501937;display:flex;align-items:center;justify-content:space-between;margin-top:1.5rem;margin-bottom:2rem;box-shadow:0 4px 16px rgba(100,40,70,0.12);overflow:hidden;position:relative;z-index:10;">
              <div style="display:flex;align-items:center;gap:1.25rem;">
                <img src="{LOGO_IMG_SRC}" alt="National Energy System Operator" height="38" style="vertical-align:middle;filter:brightness(0) invert(1);" />
                <div>
                  <div class="brand-title">National Energy System Operator</div>
                  <div class="brand-sub">Official Data Portal Wrapper</div>
                </div>
              </div>
              <div>
                <a href="https://www.neso.energy/data-portal" target="_blank"
                   style="color:#FFFFFF;text-decoration:none;font-size:0.82rem;font-weight:500;padding:0.4rem 0.8rem;border:1px solid rgba(255,255,255,0.4);border-radius:4px;">
                  neso.energy portal
                </a>
              </div>
            </div>""",
        unsafe_allow_html=True,
    )


def hero(title: str, subtitle: str = "", eyebrow: str = "National Energy System Operator", is_home: bool = False) -> None:
    if is_home:
        st.markdown(
            f"""<section class="neso-hero">
                  <div class="neso-eyebrow">{html.escape(eyebrow)}</div>
                  <h1>{html.escape(title)}</h1>
                  {f"<p>{html.escape(subtitle)}</p>" if subtitle else ""}
                </section>""",
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f"""<section class="neso-sub-hero">
                  <div class="neso-eyebrow">{html.escape(eyebrow)}</div>
                  <h1>{html.escape(title)}</h1>
                  {f"<p>{html.escape(subtitle)}</p>" if subtitle else ""}
                </section>""",
            unsafe_allow_html=True,
        )


def badge(text: str, tone: str = "slate") -> str:
    return f'<span class="neso-badge tone-{tone}">{html.escape(str(text))}</span>'


def badges(items: Iterable[tuple[str, str]]) -> None:
    content = "".join(badge(t, tone) for t, tone in items if t)
    if content:
        st.markdown(f'<div class="neso-badges">{content}</div>', unsafe_allow_html=True)


def section(title: str) -> None:
    st.markdown(f'<div class="neso-section">{html.escape(title)}</div>', unsafe_allow_html=True)


def status_tone(status: str) -> str:
    s = (status or "").lower()
    return "green" if s == "live" else "amber" if s else "slate"


def strip_html(text: str) -> str:
    text = re.sub(r"<[^>]+>", " ", text or "")
    text = re.sub(r"[#*_`>\[\]]", "", html.unescape(text))
    return re.sub(r"\s+", " ", text).strip()


def clean_notes(text: str) -> str:
    """Convert raw CKAN HTML notes into clean, readable Markdown."""
    if not text:
        return ""
    # Strip iframe embeds completely
    s = re.sub(r"<iframe[^>]*>.*?</iframe>", "", text, flags=re.IGNORECASE | re.DOTALL)
    # Convert line break tags to double newlines
    s = re.sub(r"<\s*/?\s*br\s*/?\s*>", "\n\n", s, flags=re.IGNORECASE)
    # Convert paragraph tags to newlines
    s = re.sub(r"<\s*/?\s*p[^>]*>", "\n\n", s, flags=re.IGNORECASE)
    # Convert links <a href="url">text</a> -> [text](url)
    s = re.sub(r"<a\s+[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", r"[\2](\1)", s, flags=re.IGNORECASE | re.DOTALL)
    # Remove HTML bold tags (markdown asterisks are already used in the portal text)
    s = re.sub(r"<\s*/?\s*(?:b|strong)\s*>", "", s, flags=re.IGNORECASE)
    # Convert italic tags to markdown
    s = re.sub(r"<\s*/?\s*(?:i|em)\s*>", "*", s, flags=re.IGNORECASE)
    # Strip any remaining HTML tags (span, font, u, div, hr, etc.)
    s = re.sub(r"<[^>]+>", " ", s)
    # Decode HTML entities (&nbsp;, &pound;, &amp;, etc.)
    s = html.unescape(s)
    # Clean up non-breaking spaces
    s = s.replace("\xa0", " ")
    # Normalize markdown bolding
    s = re.sub(r"\*{3,}", "**", s)
    s = re.sub(r"\*\*\s*([^\*\n]+?)\s*\*\*", r"**\1**", s)
    # Clean up whitespace
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\r\n|\r|\n", "\n", s)
    s = re.sub(r"\n[ \t]+", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def snippet(text: str, n: int = 170) -> str:
    clean = strip_html(text)
    return clean if len(clean) <= n else clean[: n].rsplit(" ", 1)[0] + "…"


def fmt_date(value: str | None) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value).replace("Z", "")).strftime("%d %b %Y")
    except ValueError:
        return str(value)[:10]


def human_size(size) -> str:
    try:
        size = float(size)
    except (TypeError, ValueError):
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:,.0f} {unit}" if unit == "B" else f"{size:,.1f} {unit}"
        size /= 1024
    return f"{size:,.1f} TB"


def open_dataset(name: str) -> None:
    st.session_state["sel_dataset"] = name
    st.session_state.pop("sel_resource", None)
    st.switch_page(PAGES["dataset"])


def open_explorer(dataset: str, resource_id: str) -> None:
    st.session_state["sel_dataset"] = dataset
    st.session_state["sel_resource"] = resource_id
    st.switch_page(PAGES["explorer"])


def _sync_dataset(widget_key: str) -> None:
    st.session_state["sel_dataset"] = st.session_state[widget_key]
    st.session_state.pop("sel_resource", None)


def dataset_picker(catalogue: list[dict], widget_key: str) -> str | None:
    """Dataset selectbox whose value persists across pages via ``sel_dataset``."""
    titles = {d["name"]: d["title"] for d in catalogue}
    current = st.session_state.get("sel_dataset")
    if current not in titles:
        current = None
    if st.session_state.get(widget_key) != current:
        st.session_state[widget_key] = current
    return st.selectbox(
        "Dataset",
        options=list(titles),
        format_func=lambda n: titles.get(n, n),
        index=None,
        placeholder="Choose a dataset…",
        key=widget_key,
        on_change=_sync_dataset,
        args=(widget_key,),
    )
