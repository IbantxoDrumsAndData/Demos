# Market Monitoring - Price Dashboard (Refactored v2 Release: Local Laptop / Windows 11 + VS Code + Conda + `.env`)

This release provides the v2 domain-modular implementation of the **Market Monitoring - Price Dashboard**, incorporating the compact sidebar date controls, `DA PN` operational horizon, 6-trace legend-driven Bid/Offer price chart, subtle yellow REMIT time bands, and responsive HTML card titles above every Plotly chart. Configured for **local execution on a Windows 11 laptop** using **VS Code**, **Conda** (`python=3.11`), `DefaultAzureCredential()` (`az login`), and a local **`.env`** file for EnAppSys credentials.

---

## 1. Quick Start on Windows 11 (VS Code + Conda)

### Step 1: Open in VS Code
Open the `prizedashboard_refactored_v2_local` folder in Visual Studio Code (`File > Open Folder...`).

### Step 2: Create & Activate the Conda Environment
In the VS Code terminal (**Command Prompt** or **Anaconda Prompt**):

```bat
conda env create -f environment.yml
conda activate price-dashboard-local
```
*(Or run `setup_conda_env.bat`.)*

Select the **`price-dashboard-local`** Conda interpreter in VS Code (`Ctrl+Shift+P` -> `Python: Select Interpreter` -> `price-dashboard-local`).

### Step 3: Verify `.env` & Authenticate with Azure
1. If `.env` is not already present, copy `.env.example` to `.env` in the project root:
   ```bat
   copy .env.example .env
   ```
2. Verify your EnAppSys credentials and Azure Blob Storage settings in `.env`:
   ```dotenv
   ENAPPUSR=your_enappsys_username
   ENAPP=your_enappsys_password

   AZURE_STORAGE_ACCOUNT_URL=https://<your-storage-account>.blob.core.windows.net
   AZURE_STORAGE_CONTAINER_NAME=<your-container-name>
   ```
3. Run `az login` in your terminal so `DefaultAzureCredential()` can read from Azure Blob Storage:
   ```bat
   az login
   ```

### Step 4: Run the Dashboard
```bat
python -m streamlit run streamlit_app.py --server.port 8000
```
*(Or press **`F5`** in VS Code and choose **`Streamlit: Run Market Monitoring Dashboard`**, or run **`run_dashboard.bat`**.)*

---

## 2. Highlights in Refactored v2

* **Compact Date Selection**: Single radio selector (`Specific Day`, `Specific Week` [`Week 48 - 23-29 Nov 2026`, ISO Monday–Sunday], `Specific Month` [`November 2026`], `Custom Date Range`) showing only the relevant date control for the chosen mode.
* **Operational Chart**: Includes `DA PN` (`DAYAHEADIPNSUBMISSION_MW`, royal blue `#1E40AF`, `legendonly`) alongside `4H–18H PN`, and represents active REMIT notices as subtle yellow vertical time bands bounded to the unit's MW data range (`0 / min MW` to `max MW`) with a single `"REMIT"` legend toggle.
* **Wholesale & Bid/Offer Chart**: Pair selection removed from sidebar and handled directly in the chart legend across six explicit traces (`Pair -1 Bid` and `Pair +1 Offer` visible by default; `Pair -2/-3 Bid` and `Pair +2/+3 Offer` hidden in legend).
* **Responsive Card Titles**: Chart headings sit outside and above each Plotly canvas (`autoexpand=True`) so legends never overlap titles at any screen size.
