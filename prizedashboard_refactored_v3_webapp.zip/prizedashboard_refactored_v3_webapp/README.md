# Market Monitoring - Price Dashboard (Refactored v3 Release: Web App Deployment)

This release provides the v3 domain-modular implementation of the **Market Monitoring - Price Dashboard**, expanding BMU selection to **up to 6 BMUs** and wiring the sidebar `Dashboards` picker to switch between **`Current Year`** and a **`YoY Comparison`** placeholder within the shared dashboard shell. Configured for **Azure App Service (Web App) deployment** with Managed Identity and Azure Key Vault.

---

## 1. Highlights in Refactored v3

* **Expanded BMU Selection Limit**: Analysts can select **up to 6 BMUs** (`MAX_BMU_SELECTIONS = 6`) for side-by-side comparison.
* **Dashboard Switcher (`Current Year` & `YoY Comparison`)**: The bottom `Dashboards` picker offers `Current Year` (full single-period investigation view) and `YoY Comparison` (preserving the same sidebar/shell design with a clear notice that YoY comparison will be developed in a future iteration).
* **Retained v2 Enhancements**: Compact `Date selection` radio controls (`Specific Day`, `Specific Week` [`Week 48 - 23-29 Nov 2026`], `Specific Month`, `Custom Date Range`), `DA PN` horizon (`#1E40AF`, `legendonly`), 6-trace legend-driven Bid/Offer price chart, subtle yellow REMIT time bands bounded to the unit's MW range, and overlap-proof HTML card headings above every Plotly canvas.

---

## 2. Startup Command (Azure App Service)

```bash
python -m streamlit run streamlit_app.py --server.port 8000 --server.address 0.0.0.0
```
