import streamlit as st
import pandas as pd

# =============================
#   TITLE AND COLUMN CONFIG
# =============================
st.set_page_config(
    page_title="Demo Dashboard 2 - Data Diagnostics",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("Demo Dashboard 2 — Data Diagnostics")
st.caption(
    "Displays source load status, durations, row counts, and timestamp bounds "
    "from the last submitted execution without triggering additional data loads."
)

submitted = st.session_state.get("submitted_request")
if submitted is not None:
    st.subheader("Last Submitted Request")
    st.json(
        {
            "selectedGraphs": list(submitted["selectedGraphs"]),
            "showREMITOverlay": submitted["showREMITOverlay"],
            "showBidOfferOverlay": submitted["showBidOfferOverlay"],
            "showDataTables": submitted["showDataTables"],
            "start_datetime": str(submitted["datetimeRange"][0]),
            "end_datetime": str(submitted["datetimeRange"][1]),
            "selectFuelType": list(submitted["selectFuelType"]),
            "selectPortfolio": list(submitted["selectPortfolio"]),
            "selectBMUs": list(submitted["selectBMUs"]),
            "pairIDChoices": list(submitted["pairIDChoices"]),
        }
    )
else:
    st.info("No dashboard request has been submitted yet in Demo Dashboard 1.")

st.subheader("Source Status & Diagnostics")
diagnostics_dict = st.session_state.get("source_diagnostics", {})
if diagnostics_dict:
    st.dataframe(
        pd.DataFrame(list(diagnostics_dict.values())),
        width="stretch",
    )
else:
    st.info("No source diagnostics recorded yet.")

st.subheader("Execution Step Timings (perf_counter)")
timings = st.session_state.get("step_timings", {})
if timings:
    st.dataframe(
        pd.DataFrame(
            [{"Step": k, "Duration (s)": round(v, 5)} for k, v in timings.items()]
        ),
        width="stretch",
    )
else:
    st.info("No execution timings recorded yet.")
