from contextlib import contextmanager
from datetime import datetime, timezone
from time import perf_counter
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from src.apis.enappsys import getWholesalePrices
from src.utils.dates import getDate
from src.apis.NEDBlob import getOperationalData
from src.apis.NEDBlob import getStakeholders
from src.apis.NEDBlob import getBidOfferData
from src.utils.figTrace import figTrace
from src.apis.elexon import getBMUMapping
from src.apis.elexon import getRemit
from src.apis.NEDBlob import getTimeFrames
from src.apis.NEDBlob import getBOAInstructionsData

# =============================
#   TITLE AND COLUMN CONFIG
# =============================
st.set_page_config(
    page_title="Demo Dashboard 1",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("Demo Dashboard 1")


PLOTLY_THEME = "plotly_white"
PLOTLY_BG_COLOR = "#FFFFFF"


# =============================
#   TIMING & CACHED HELPERS
# =============================
@contextmanager
def timed_step(name: str, timings: dict[str, float]):
    started = perf_counter()
    try:
        yield
    finally:
        timings[name] = perf_counter() - started


def _record_source_diagnostic(
    source_name: str,
    loaded: bool,
    df: pd.DataFrame = None,
    filtered_df: pd.DataFrame = None,
    timestamp_col: str = None,
    load_s: float = 0.0,
    prep_s: float = 0.0,
    render_s: float = 0.0,
    message: str = "OK",
):
    if "source_diagnostics" not in st.session_state:
        st.session_state["source_diagnostics"] = {}

    if not loaded or df is None:
        st.session_state["source_diagnostics"][source_name] = {
            "Source Name": source_name,
            "Status": "Not Loaded",
            "Load Duration (s)": round(load_s, 4),
            "Prep Duration (s)": round(prep_s, 4),
            "Chart Render Duration (s)": round(render_s, 4),
            "Total Rows": 0,
            "Selected-BMU Rows": 0,
            "Min Timestamp": None,
            "Max Timestamp": None,
            "Last Loaded (UTC)": None,
            "Details": message,
        }
        return

    target_df = filtered_df if filtered_df is not None else df
    min_ts = None
    max_ts = None
    if (
        timestamp_col
        and timestamp_col in target_df.columns
        and not target_df.empty
        and target_df[timestamp_col].notna().any()
    ):
        ts_series = pd.to_datetime(target_df[timestamp_col], errors="coerce").dropna()
        if not ts_series.empty:
            min_ts = str(ts_series.min())
            max_ts = str(ts_series.max())

    st.session_state["source_diagnostics"][source_name] = {
        "Source Name": source_name,
        "Status": "Loaded",
        "Load Duration (s)": round(load_s, 4),
        "Prep Duration (s)": round(prep_s, 4),
        "Chart Render Duration (s)": round(render_s, 4),
        "Total Rows": len(df),
        "Selected-BMU Rows": len(target_df),
        "Min Timestamp": min_ts,
        "Max Timestamp": max_ts,
        "Last Loaded (UTC)": datetime.now(timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S UTC"
        ),
        "Details": (
            "No rows matched submitted BMUs and date range."
            if len(target_df) == 0
            else message
        ),
    }


@st.cache_data(ttl=3600, show_spinner=False)
def _prepare_operational_with_mapping(
    operational_df: pd.DataFrame,
    bmu_mapping_df: pd.DataFrame,
) -> pd.DataFrame:
    df = operational_df.copy()
    df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])
    if (
        bmu_mapping_df is not None
        and not bmu_mapping_df.empty
        and {"BMU_ID", "ELEXON_BMU_ID"}.issubset(bmu_mapping_df.columns)
    ):
        df = df.merge(bmu_mapping_df, on="BMU_ID", how="left")
    elif "ELEXON_BMU_ID" not in df.columns:
        df["ELEXON_BMU_ID"] = pd.NA
    return df


@st.cache_data(ttl=3600, show_spinner=False)
def _filter_operational_data(
    prepared_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    bmus_tuple: tuple[str, ...],
) -> pd.DataFrame:
    mask = (prepared_df["GMT_DATETIME"] >= start_dt) & (
        prepared_df["GMT_DATETIME"] <= end_dt
    )
    if bmus_tuple:
        mask = mask & prepared_df["BMU_ID"].isin(bmus_tuple)
    return prepared_df.loc[mask].sort_values("GMT_DATETIME")


@st.cache_data(ttl=3600, show_spinner=False)
def _build_wholesale_comparison_table(
    filtered_wholesale_df: pd.DataFrame,
    filtered_bid_offer_df: pd.DataFrame,
) -> pd.DataFrame:
    if filtered_bid_offer_df is None or filtered_bid_offer_df.empty:
        return filtered_wholesale_df.copy()

    bid_offer_pivot_df = filtered_bid_offer_df.pivot_table(
        index="GMT_DATETIME",
        columns=["BMU_ID", "BOPAIR_ID"],
        values=["BID_PRICE_GBP_MWH", "OFFER_PRICE_GBP_MWH"],
        aggfunc="first",
    )

    bid_offer_pivot_df.columns = [
        (
            f"{bmu} | Pair {pair_id} | "
            f"{'Bid' if metric == 'BID_PRICE_GBP_MWH' else 'Offer'}"
        )
        for metric, bmu, pair_id in bid_offer_pivot_df.columns
    ]

    bid_offer_pivot_df = bid_offer_pivot_df.reset_index()

    return (
        filtered_wholesale_df.copy()
        .merge(
            bid_offer_pivot_df,
            left_on="dateTime",
            right_on="GMT_DATETIME",
            how="left",
        )
        .drop(columns=["GMT_DATETIME"], errors="ignore")
    )


if "step_timings" not in st.session_state:
    st.session_state["step_timings"] = {}
timings = st.session_state["step_timings"]


# =============================
#     GET STAKEHOLDER DATA
# =============================
# Only lightweight stakeholder metadata is loaded on initial page load.
try:
    with timed_step("stakeholder_metadata_load", timings):
        stakeholders, fuelTypes, leadParties = getStakeholders()
    _record_source_diagnostic(
        "Stakeholder Metadata",
        loaded=True,
        df=stakeholders,
        load_s=timings.get("stakeholder_metadata_load", 0.0),
    )
except Exception as error:
    _record_source_diagnostic(
        "Stakeholder Metadata",
        loaded=False,
        load_s=timings.get("stakeholder_metadata_load", 0.0),
        message=str(error),
    )
    st.error("Stakeholder metadata could not be loaded.")
    st.exception(error)
    stakeholders = pd.DataFrame(columns=["sheetName", "Lead Party", "BMU ID"])
    fuelTypes = []
    leadParties = []


# =============================
#      SIDEBAR FILTERS
# =============================
with st.sidebar:

    st.header("Data Time Range (Need to fully implement)")

    selectedDataSources = st.multiselect(
        "Select Data Time Range",
        options=[],
        disabled=True,
        label_visibility="collapsed",
    )

    st.divider()

    st.header("Graph Builder - Need to implement")

    st.divider()

    st.header("Graphs/Tables")

    draftSelectedGraphs = st.pills(
        "Select Graphs/Tables",
        options=[
            "Operational Data",
            "Wholesale Prices",
            "Ancillary Services",
            "Dynamic Parameters",
            "BOA Instructions",
            "Strike Prices",
            "Wind ROC Mappings",
        ],
        selection_mode="multi",
        label_visibility="collapsed",
    )

    st.divider()

    st.header("Information Overlays")

    draftShowREMITOverlay = st.sidebar.toggle("REMIT Information", value=False)

    draftShowBidOfferOverlay = st.sidebar.toggle("Bid / Offer Data", value=False)

    draftShowDataTables = st.sidebar.toggle("Data Tables", value=False)

    st.divider()

    st.header("Filters")

    # =============================
    #       DATETIME SLIDER
    # =============================
    default_min = st.session_state.get(
        "operational_min_dt", getDate(days=10, string=False)
    )
    default_max = st.session_state.get(
        "operational_max_dt", getDate(days=0, string=False)
    )
    if default_min >= default_max:
        default_min = getDate(days=10, string=False)
        default_max = datetime.now().replace(
            hour=23, minute=30, second=0, microsecond=0
        )

    draftDatetimeRange = st.slider(
        "Date Range",
        min_value=default_min,
        max_value=default_max,
        value=(default_min, default_max),
        format="DD/MM/YYYY",
    )

    # =============================
    #      BMU FILTER SELECTOR
    # =============================
    st.text(
        "Filtering via Fuel Type and Portfolio will provide BMUs from stakeholder list within blob storage."
    )

    draftFuelType = st.multiselect("Select Fuel Type", options=fuelTypes)

    bmusInSelectedFuelType = stakeholders.copy()
    if draftFuelType and "sheetName" in bmusInSelectedFuelType.columns:
        bmusInSelectedFuelType = bmusInSelectedFuelType[
            bmusInSelectedFuelType["sheetName"].isin(draftFuelType)
        ]

    portfoliosInSelectedFuelType = (
        sorted(
            bmusInSelectedFuelType["Lead Party"].dropna().astype(str).unique().tolist()
        )
        if "Lead Party" in bmusInSelectedFuelType.columns
        else []
    )

    draftPortfolio = st.multiselect(
        "Select Portfolio", options=portfoliosInSelectedFuelType
    )

    bmusInSelectedPortfolio = bmusInSelectedFuelType.copy()
    if draftPortfolio and "Lead Party" in bmusInSelectedPortfolio.columns:
        bmusInSelectedPortfolio = bmusInSelectedPortfolio[
            bmusInSelectedPortfolio["Lead Party"].isin(draftPortfolio)
        ]

    bmus = (
        sorted(bmusInSelectedPortfolio["BMU ID"].dropna().astype(str).unique().tolist())
        if "BMU ID" in bmusInSelectedPortfolio.columns
        else []
    )

    draftBMUs = st.multiselect("Select BMU", options=bmus)

    knownPairIDs = st.session_state.get(
        "available_pair_ids", [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]
    )
    draftPairIDChoices = st.multiselect(
        "BO Pair IDs (empty = all available)",
        options=knownPairIDs,
        default=[],
    )

    loadDashboardClicked = st.button(
        "Load dashboard",
        type="primary",
        width="stretch",
    )

    if loadDashboardClicked:
        st.session_state["submitted_request"] = {
            "selectedGraphs": tuple(draftSelectedGraphs or ()),
            "showREMITOverlay": bool(draftShowREMITOverlay),
            "showBidOfferOverlay": bool(draftShowBidOfferOverlay),
            "showDataTables": bool(draftShowDataTables),
            "datetimeRange": (draftDatetimeRange[0], draftDatetimeRange[1]),
            "selectFuelType": tuple(draftFuelType),
            "selectPortfolio": tuple(draftPortfolio),
            "selectBMUs": tuple(draftBMUs),
            "pairIDChoices": tuple(draftPairIDChoices),
        }


# =============================
#    SUBMITTED EXECUTION GATE
# =============================
submitted = st.session_state.get("submitted_request")
if submitted is None:
    st.info(
        "Configure your filters and graph selections in the sidebar, then click "
        "'Load dashboard' to load only the required data sources."
    )
    st.stop()

selectedGraphs = list(submitted["selectedGraphs"])
showOperationalGraph = "Operational Data" in selectedGraphs
showWholesaleGraph = "Wholesale Prices" in selectedGraphs
showAncillaryGraph = "Ancillary Services" in selectedGraphs
showDynamicParamsGraph = "Dynamic Parameters" in selectedGraphs
showBOAInstructionsTable = "BOA Instructions" in selectedGraphs
showStrikePricesTable = "Strike Prices" in selectedGraphs
showWindROCTable = "Wind ROC Mappings" in selectedGraphs

showREMITOverlay = submitted["showREMITOverlay"]
showBidOfferOverlay = submitted["showBidOfferOverlay"]
showDataTables = submitted["showDataTables"]
datetimeRange = submitted["datetimeRange"]
selectBMUs = list(submitted["selectBMUs"])
requestedPairIDs = list(submitted["pairIDChoices"])

if not selectedGraphs:
    st.warning("Select at least one graph or table view and click 'Load dashboard'.")
    st.stop()


with timed_step("complete_submitted_request_duration", timings):

    # =============================
    #     GET OPERATIONAL DATA
    # =============================
    filteredOperationalData = pd.DataFrame()
    if (showOperationalGraph or showDynamicParamsGraph) and selectBMUs:
        try:
            with timed_step("operational_data_load", timings):
                operationalData = getOperationalData()
        except Exception as error:
            _record_source_diagnostic(
                "NED Operational Data",
                loaded=False,
                load_s=timings.get("operational_data_load", 0.0),
                message=str(error),
            )
            st.error("Operational data could not be loaded.")
            st.exception(error)
            st.stop()

        with timed_step("bmu_mapping_load", timings):
            bmuMappingDF = getBMUMapping()
        _record_source_diagnostic(
            "Elexon BMU Mapping",
            loaded=bmuMappingDF is not None,
            df=bmuMappingDF,
            load_s=timings.get("bmu_mapping_load", 0.0),
        )

        with timed_step("operational_data_preparation", timings):
            preparedOperationalData = _prepare_operational_with_mapping(
                operationalData, bmuMappingDF
            )
            if (
                not preparedOperationalData.empty
                and "GMT_DATETIME" in preparedOperationalData.columns
            ):
                st.session_state["operational_min_dt"] = (
                    preparedOperationalData["GMT_DATETIME"].min().to_pydatetime()
                )
                st.session_state["operational_max_dt"] = (
                    preparedOperationalData["GMT_DATETIME"].max().to_pydatetime()
                )

            filteredOperationalData = _filter_operational_data(
                preparedOperationalData,
                datetimeRange[0],
                datetimeRange[1],
                tuple(selectBMUs),
            )
    else:
        _record_source_diagnostic(
            "NED Operational Data",
            loaded=False,
            message="Skipped (not required by submitted views).",
        )
        _record_source_diagnostic(
            "Elexon BMU Mapping",
            loaded=False,
            message="Skipped (not required by submitted views).",
        )

    # =============================
    #    PLOT OPERATIONAL DATA
    # =============================
    if showOperationalGraph and selectBMUs:
        with timed_step("operational_chart_render", timings):
            if filteredOperationalData.empty:
                st.info(
                    "No operational data was found for the submitted BMUs and date range."
                )
            else:
                graphsPerRow = 2  # Change to 3 if you want 3 graphs across
                remitTotalLoadTime = 0.0
                remitRowCount = 0

                for rowStart in range(0, len(selectBMUs), graphsPerRow):

                    currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

                    if len(currentBMUs) == 1:
                        cols = [st.container()]
                    else:
                        cols = st.columns(graphsPerRow)

                    for col, bmu in zip(cols, currentBMUs):

                        with col:

                            bmuDF = filteredOperationalData[
                                filteredOperationalData["BMU_ID"] == bmu
                            ].sort_values("GMT_DATETIME")

                            if bmuDF.empty:
                                st.divider()
                                st.info(
                                    f"No operational data was found for BMU '{bmu}' in the selected date range."
                                )
                                continue

                            operationalFig = go.Figure()

                            # =============================
                            # OPERATIONAL TRACES
                            # =============================

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["MAXIMUM_EXPORT_LIMIT"],
                                "lines",
                                "MEL",
                                line=dict(width=3, dash="dot"),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["MAXIMUM_IMPORT_LIMIT"],
                                "lines",
                                "MIL",
                                line=dict(width=3),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["STABLEEXPORTLIMIT"],
                                "lines",
                                "SEL",
                                line=dict(width=3, dash="dot"),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["FINAL_PHYSICAL_NOTIFICATION_MW"],
                                "lines",
                                "FPN",
                                line=dict(width=3),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["OPERATIONAL_METERED_OUTPUT_MW"],
                                "lines",
                                "Metered Output",
                                line=dict(width=3, dash="dot"),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["PN4HRSAHEADOFEFFECTIVE_MW"],
                                "lines",
                                "4H PN",
                                line=dict(width=3),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["PN6HRSAHEADOFEFFECTIVE_MW"],
                                "lines",
                                "6H PN",
                                line=dict(width=3),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["PN8HRSAHEADOFEFFECTIVE_MW"],
                                "lines",
                                "8H PN",
                                line=dict(width=3),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["PN12HRSAHEADOFEFFECTIVE_MW"],
                                "lines",
                                "12H PN",
                                line=dict(width=3),
                            )

                            figTrace(
                                operationalFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["PN18HRSAHEADOFEFFECTIVE_MW"],
                                "lines",
                                "18H PN",
                                line=dict(width=3),
                            )

                            # =============================
                            # REMIT DATA (CONDITIONAL)
                            # =============================
                            remitDF = pd.DataFrame()

                            if showREMITOverlay:
                                elexonBMU = (
                                    bmuDF["ELEXON_BMU_ID"].iloc[0]
                                    if "ELEXON_BMU_ID" in bmuDF.columns
                                    else None
                                )
                                if pd.notna(elexonBMU) and str(elexonBMU).strip():
                                    t_remit = perf_counter()
                                    remitDF = getRemit(
                                        elexonBMU,
                                        datetimeRange[0],
                                        datetimeRange[1],
                                    )
                                    remitTotalLoadTime += perf_counter() - t_remit
                                    if remitDF is not None:
                                        remitRowCount += len(remitDF)
                                else:
                                    st.warning(
                                        f"{bmu}: No Elexon BMU mapping available; skipping REMIT lookup."
                                    )

                            if (
                                showREMITOverlay
                                and remitDF is not None
                                and not remitDF.empty
                            ):

                                remitDF = remitDF.copy()
                                remitDF["eventStartTime"] = pd.to_datetime(
                                    remitDF["eventStartTime"]
                                ).dt.tz_localize(None)

                                remitDF["eventEndTime"] = pd.to_datetime(
                                    remitDF["eventEndTime"]
                                ).dt.tz_localize(None)

                                for _, remit in remitDF.iterrows():

                                    if (
                                        remit["eventEndTime"] < datetimeRange[0]
                                        or remit["eventStartTime"] > datetimeRange[1]
                                    ):
                                        continue

                                    overlayStart = max(
                                        remit["eventStartTime"],
                                        datetimeRange[0],
                                    )

                                    overlayEnd = min(
                                        remit["eventEndTime"],
                                        datetimeRange[1],
                                    )

                                    normalCapacity = remit["normalCapacity"]
                                    unavailableCapacity = remit["unavailableCapacity"]

                                    availableCapacity = (
                                        normalCapacity - unavailableCapacity
                                    )

                                    operationalFig.add_shape(
                                        type="rect",
                                        x0=overlayStart,
                                        x1=overlayEnd,
                                        y0=availableCapacity,
                                        y1=normalCapacity,
                                        fillcolor="red",
                                        opacity=0.3,
                                        line_width=0,
                                    )

                                    operationalFig.add_trace(
                                        go.Scatter(
                                            x=[overlayStart, overlayEnd],
                                            y=[
                                                availableCapacity,
                                                availableCapacity,
                                            ],
                                            mode="lines",
                                            name=(
                                                f"REMIT | "
                                                f"{unavailableCapacity} MW | "
                                                f"{remit['eventStartTime'].strftime('%d %b')} → "
                                                f"{remit['eventEndTime'].strftime('%d %b')}"
                                            ),
                                            line=dict(
                                                color="red",
                                                width=2,
                                            ),
                                        )
                                    )

                            # =============================
                            # LAYOUT
                            # =============================

                            operationalFig.update_layout(
                                template=PLOTLY_THEME,
                                title=f"{bmu} Operational Data",
                                xaxis_title="Date/Time",
                                yaxis_title="MW",
                                height=500,
                                hovermode="x unified",
                                legend=dict(
                                    orientation="h",
                                    yanchor="bottom",
                                    y=1.02,
                                    xanchor="left",
                                    x=0,
                                ),
                                yaxis=dict(
                                    showgrid=True,
                                    gridcolor="#CBD5E1",
                                    gridwidth=1,
                                ),
                            )

                            st.divider()
                            st.plotly_chart(
                                operationalFig,
                                width="stretch",
                            )

                            if (
                                showREMITOverlay
                                and remitDF is not None
                                and not remitDF.empty
                            ):
                                st.dataframe(remitDF, width="stretch")

                timings["remit_load_total"] = remitTotalLoadTime
                _record_source_diagnostic(
                    "Elexon REMIT",
                    loaded=showREMITOverlay,
                    load_s=remitTotalLoadTime,
                    message=(
                        f"Loaded {remitRowCount} REMIT rows."
                        if showREMITOverlay
                        else "Skipped (REMIT overlay disabled)."
                    ),
                )

                # =============================
                # DATA TABLE
                # =============================

                if showDataTables:

                    selectedBMUsDF = filteredOperationalData[
                        filteredOperationalData["BMU_ID"].isin(selectBMUs)
                    ].sort_values("GMT_DATETIME")

                    st.subheader("BMU(s) Operational Data")
                    st.dataframe(selectedBMUsDF, width="stretch")

    elif showOperationalGraph and not selectBMUs:
        st.info("Select at least one BMU to view Operational Data.")

    if (showOperationalGraph or showDynamicParamsGraph) and selectBMUs:
        _record_source_diagnostic(
            "NED Operational Data",
            loaded=True,
            df=operationalData,
            filtered_df=filteredOperationalData,
            timestamp_col="GMT_DATETIME",
            load_s=timings.get("operational_data_load", 0.0),
            prep_s=timings.get("operational_data_preparation", 0.0),
            render_s=timings.get("operational_chart_render", 0.0),
        )

    # =============================
    #    PLOT WHOLESALE DATA
    # =============================

    if showWholesaleGraph and selectBMUs:

        start_str = datetimeRange[0].strftime("%Y%m%d%H%M")
        end_str = datetimeRange[1].strftime("%Y%m%d%H%M")

        with timed_step("wholesale_api_load", timings):
            wholesalePrices = getWholesalePrices(start_str, end_str)

        if wholesalePrices is None or wholesalePrices.empty:
            _record_source_diagnostic(
                "EnAppSys Wholesale Prices",
                loaded=False,
                load_s=timings.get("wholesale_api_load", 0.0),
                message="No wholesale price data returned for submitted date range.",
            )
            st.info("No wholesale price data was found for the submitted date range.")
        else:
            filteredWholesalePrices = wholesalePrices[
                (wholesalePrices["dateTime"] >= datetimeRange[0])
                & (wholesalePrices["dateTime"] <= datetimeRange[1])
            ]

            selectedBodBMUsDF = pd.DataFrame()
            pairIDChoices = []

            if showBidOfferOverlay:
                try:
                    with timed_step("bid_offer_data_load", timings):
                        bidOfferData = getBidOfferData()
                except Exception as error:
                    _record_source_diagnostic(
                        "NED Bid/Offer Data",
                        loaded=False,
                        load_s=timings.get("bid_offer_data_load", 0.0),
                        message=str(error),
                    )
                    st.error("Bid/Offer data could not be loaded.")
                    st.exception(error)
                    st.stop()

                with timed_step("bid_offer_preparation", timings):
                    filteredBidOfferData = bidOfferData[
                        (bidOfferData["GMT_DATETIME"] >= datetimeRange[0])
                        & (bidOfferData["GMT_DATETIME"] <= datetimeRange[1])
                    ]

                    selectedBodBMUsDF = filteredBidOfferData[
                        filteredBidOfferData["BMU_ID"].isin(selectBMUs)
                    ]

                    availablePairs = sorted(
                        selectedBodBMUsDF["BOPAIR_ID"].dropna().unique().tolist()
                    )
                    st.session_state["available_pair_ids"] = availablePairs
                    pairIDChoices = (
                        [p for p in availablePairs if p in requestedPairIDs]
                        if requestedPairIDs
                        else availablePairs
                    )

                _record_source_diagnostic(
                    "NED Bid/Offer Data",
                    loaded=True,
                    df=bidOfferData,
                    filtered_df=selectedBodBMUsDF,
                    timestamp_col="GMT_DATETIME",
                    load_s=timings.get("bid_offer_data_load", 0.0),
                    prep_s=timings.get("bid_offer_preparation", 0.0),
                )
            else:
                _record_source_diagnostic(
                    "NED Bid/Offer Data",
                    loaded=False,
                    message="Skipped (Bid/Offer overlay disabled).",
                )

            with timed_step("wholesale_chart_render", timings):
                graphsPerRow = 2  # Change to 3 if preferred

                for rowStart in range(0, len(selectBMUs), graphsPerRow):

                    currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

                    if len(currentBMUs) == 1:
                        cols = [st.container()]
                    else:
                        cols = st.columns(graphsPerRow)

                    for col, bmu in zip(cols, currentBMUs):

                        with col:

                            wholesaleFig = go.Figure()

                            # =============================
                            # WHOLESALE PRICE TRACES
                            # =============================

                            figTrace(
                                wholesaleFig,
                                filteredWholesalePrices["dateTime"],
                                filteredWholesalePrices["ID_Forecast £/MWh"],
                                "lines",
                                "ID Forecast",
                                line=dict(width=3),
                            )

                            figTrace(
                                wholesaleFig,
                                filteredWholesalePrices["dateTime"],
                                filteredWholesalePrices["DA_Nordpool £/MWh"],
                                "lines",
                                "DA Forecast",
                                line=dict(width=3),
                            )

                            # =============================
                            # BID / OFFER OVERLAY
                            # =============================

                            if showBidOfferOverlay and not selectedBodBMUsDF.empty:

                                bmuDF = selectedBodBMUsDF[
                                    selectedBodBMUsDF["BMU_ID"] == bmu
                                ]

                                for pairID in pairIDChoices:

                                    pairDF = bmuDF[
                                        bmuDF["BOPAIR_ID"] == pairID
                                    ].sort_values("GMT_DATETIME")

                                    if pairDF.empty:
                                        continue

                                    figTrace(
                                        wholesaleFig,
                                        pairDF["GMT_DATETIME"],
                                        pairDF["BID_PRICE_GBP_MWH"],
                                        "lines",
                                        f"Pair {pairID} BID",
                                        line=dict(
                                            width=3,
                                            dash="dot",
                                        ),
                                    )

                                    figTrace(
                                        wholesaleFig,
                                        pairDF["GMT_DATETIME"],
                                        pairDF["OFFER_PRICE_GBP_MWH"],
                                        "lines",
                                        f"Pair {pairID} OFFER",
                                        line=dict(
                                            width=3,
                                            dash="dot",
                                        ),
                                    )

                            # =============================
                            # LAYOUT
                            # =============================

                            wholesaleFig.update_layout(
                                template=PLOTLY_THEME,
                                title=f"{bmu} Wholesale Data",
                                xaxis_title="Date/Time",
                                yaxis_title="£/MWh",
                                height=500,
                                hovermode="x unified",
                                legend=dict(
                                    orientation="h",
                                    yanchor="bottom",
                                    y=1.02,
                                    xanchor="left",
                                    x=0,
                                ),
                                yaxis=dict(
                                    showgrid=True,
                                    gridcolor="#CBD5E1",
                                    gridwidth=1,
                                ),
                            )

                            st.divider()
                            st.plotly_chart(
                                wholesaleFig,
                                width="stretch",
                            )

                # ===================================================
                #  PIVOT TABLE TO HAVE WHOLESALE PRICES + BID/OFFERS
                # ===================================================
                if showDataTables and selectBMUs:

                    if showBidOfferOverlay:
                        st.subheader("Wholesale + Bid/Offer Data")
                        wholesalePriceComparisonDF = _build_wholesale_comparison_table(
                            filteredWholesalePrices,
                            selectedBodBMUsDF,
                        )
                        st.dataframe(wholesalePriceComparisonDF, width="stretch")

                    else:
                        st.subheader("Wholesale Data")
                        st.dataframe(filteredWholesalePrices.copy(), width="stretch")

            _record_source_diagnostic(
                "EnAppSys Wholesale Prices",
                loaded=True,
                df=wholesalePrices,
                filtered_df=filteredWholesalePrices,
                timestamp_col="dateTime",
                load_s=timings.get("wholesale_api_load", 0.0),
                render_s=timings.get("wholesale_chart_render", 0.0),
            )
    elif showWholesaleGraph and not selectBMUs:
        st.info("Select at least one BMU to view Wholesale Prices.")
    else:
        _record_source_diagnostic(
            "EnAppSys Wholesale Prices",
            loaded=False,
            message="Skipped (Wholesale Prices view not selected).",
        )
        _record_source_diagnostic(
            "NED Bid/Offer Data",
            loaded=False,
            message="Skipped (Wholesale Prices view not selected).",
        )

    # =============================
    #    PLOT DYNAMIC PARAMETERS
    # =============================
    if showDynamicParamsGraph and selectBMUs:
        with timed_step("dynamic_params_chart_render", timings):
            if filteredOperationalData.empty:
                st.info(
                    "No dynamic parameters data was found for the submitted BMUs and date range."
                )
            else:
                graphsPerRow = 2

                dynamicParamDF = []

                for rowStart in range(0, len(selectBMUs), graphsPerRow):

                    currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

                    if len(currentBMUs) == 1:
                        cols = [st.container()]
                    else:
                        cols = st.columns(graphsPerRow)

                    for col, bmu in zip(cols, currentBMUs):

                        with col:

                            bmuDF = filteredOperationalData[
                                filteredOperationalData["BMU_ID"] == bmu
                            ].sort_values("GMT_DATETIME")

                            if bmuDF.empty:
                                continue

                            dynamicParamDF.append(
                                bmuDF[
                                    [
                                        "GMT_DATETIME",
                                        "BMU_ID",
                                        "AVERAGENOTICETODEVIATEFROMZERO_MINS",
                                        "AVERAGEMINIMUMZEROTIME_MINS",
                                        "AVERAGEMINIMUMNONZEROTIME_MINS",
                                    ]
                                ]
                            )

                            dynamicParamFig = go.Figure()

                            figTrace(
                                dynamicParamFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["AVERAGENOTICETODEVIATEFROMZERO_MINS"],
                                "lines",
                                "Average NDZ",
                                line=dict(width=3),
                            )

                            figTrace(
                                dynamicParamFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["AVERAGEMINIMUMZEROTIME_MINS"],
                                "lines",
                                "Average MZT",
                                line=dict(width=3),
                            )

                            figTrace(
                                dynamicParamFig,
                                bmuDF["GMT_DATETIME"],
                                bmuDF["AVERAGEMINIMUMNONZEROTIME_MINS"],
                                "lines",
                                "Average MNZT",
                                line=dict(width=3),
                            )

                            dynamicParamFig.update_layout(
                                template=PLOTLY_THEME,
                                title=f"{bmu} Dynamic Parameters",
                                xaxis_title="Date/Time",
                                yaxis_title="Time (Minutes)",
                                height=500,
                                hovermode="x unified",
                                legend=dict(
                                    orientation="h",
                                    yanchor="bottom",
                                    y=1.02,
                                    xanchor="left",
                                    x=0,
                                ),
                                yaxis=dict(
                                    showgrid=True,
                                    gridcolor="#CBD5E1",
                                    gridwidth=1,
                                ),
                            )

                            dynamicParamFig.update_xaxes(
                                range=[
                                    datetimeRange[0],
                                    datetimeRange[1],
                                ]
                            )

                            st.divider()
                            st.plotly_chart(
                                dynamicParamFig,
                                width="stretch",
                            )

                if dynamicParamDF:
                    dynamicParamDF = pd.concat(
                        dynamicParamDF,
                        ignore_index=True,
                    )
                    if showDataTables and len(dynamicParamDF) > 0:
                        st.subheader("Dynamic Parameters Data")
                        st.dataframe(dynamicParamDF, width="stretch")

    # =====================================
    # ANCILLARY SERVICES (UNFINISHED STATUS)
    # =====================================
    if showAncillaryGraph:
        st.divider()
        st.subheader("Ancillary Services")
        st.info("Ancillary Services: Not yet implemented")

    # =============================
    #    BOA INSTRUCTIONS DATA
    # =============================
    if showBOAInstructionsTable and selectBMUs:
        try:
            with timed_step("boa_data_load", timings):
                bOAInstructionsData = getBOAInstructionsData()
        except Exception as error:
            _record_source_diagnostic(
                "NED BOA Instructions",
                loaded=False,
                load_s=timings.get("boa_data_load", 0.0),
                message=str(error),
            )
            st.error("BOA instructions data could not be loaded.")
            st.exception(error)
            st.stop()

        with timed_step("boa_table_render", timings):
            graphsPerRow = 2
            boaMatchedFrames = []

            for rowStart in range(0, len(selectBMUs), graphsPerRow):

                currentBMUs = selectBMUs[rowStart : rowStart + graphsPerRow]

                if len(currentBMUs) == 1:
                    cols = [st.container()]
                else:
                    cols = st.columns(graphsPerRow)

                for col, bmu in zip(cols, currentBMUs):

                    with col:

                        filteredBOAInstructionsData = bOAInstructionsData[
                            (bOAInstructionsData["BMU_ID"] == bmu)
                            & (bOAInstructionsData["GMT_DATETIME"] >= datetimeRange[0])
                            & (bOAInstructionsData["GMT_DATETIME"] <= datetimeRange[1])
                        ].sort_values(
                            "GMT_DATETIME",
                            ascending=False,
                        )

                        filteredBOAInstructionsData = filteredBOAInstructionsData[
                            [
                                "GMT_DATETIME",
                                "BMU_ID",
                                "BOPAIR_ID",
                                "BID_PRICE",
                                "OFFER_PRICE",
                                "CST_GROUP",
                                "DIRECT_ACTION_COST",
                            ]
                        ]
                        boaMatchedFrames.append(filteredBOAInstructionsData)

                        st.divider()
                        st.subheader(f"{bmu} BOA Instructions")

                        if filteredBOAInstructionsData.empty:
                            st.info(
                                f"No BOA instructions found for BMU '{bmu}' in the submitted date range."
                            )
                        else:
                            st.dataframe(
                                filteredBOAInstructionsData,
                                width="stretch",
                            )

            allFilteredBOA = (
                pd.concat(boaMatchedFrames, ignore_index=True)
                if boaMatchedFrames
                else pd.DataFrame()
            )
            _record_source_diagnostic(
                "NED BOA Instructions",
                loaded=True,
                df=bOAInstructionsData,
                filtered_df=allFilteredBOA,
                timestamp_col="GMT_DATETIME",
                load_s=timings.get("boa_data_load", 0.0),
                render_s=timings.get("boa_table_render", 0.0),
            )
    elif showBOAInstructionsTable and not selectBMUs:
        st.info("Select at least one BMU to view BOA Instructions.")
    else:
        _record_source_diagnostic(
            "NED BOA Instructions",
            loaded=False,
            message="Skipped (BOA Instructions view not selected).",
        )

    # =============================
    #   STRIKE PRICES DATA TABLE
    # =============================
    if showStrikePricesTable:
        st.divider()
        st.header("Strike Prices")
        st.info("Strike Prices: Not yet implemented")

    # =============================
    #      WIND ROC DATA TABLE
    # =============================
    if showWindROCTable:
        st.divider()
        st.header("Wind ROC Mappings")
        st.info("Wind ROC Mappings: Not yet implemented")


# =============================
#   INLINE DATA DIAGNOSTICS
# =============================
st.divider()
with st.expander("Execution Timings & Data Diagnostics"):
    diagnostics_dict = st.session_state.get("source_diagnostics", {})
    if diagnostics_dict:
        st.dataframe(
            pd.DataFrame(list(diagnostics_dict.values())),
            width="stretch",
        )
    if timings:
        st.dataframe(
            pd.DataFrame(
                [{"Step": k, "Duration (s)": round(v, 5)} for k, v in timings.items()]
            ),
            width="stretch",
        )
