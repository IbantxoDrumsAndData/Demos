@echo off
REM Create or update the Conda environment for the Local Blob-Only Dashboard on Windows 11
echo Creating/updating Conda environment 'price-dashboard-local' from environment.yml...
call conda env update --file "%~dp0environment.yml" --prune
if %ERRORLEVEL% NEQ 0 (
    echo Failed to create/update Conda environment. Ensure Anaconda/Miniconda is installed and on PATH.
    exit /b %ERRORLEVEL%
)
echo.
echo Environment 'price-dashboard-local' is ready.
echo Activate it with: conda activate price-dashboard-local
