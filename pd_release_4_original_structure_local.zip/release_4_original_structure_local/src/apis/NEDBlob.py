import streamlit as st
from io import BytesIO
import pandas as pd
from azure.storage.blob import BlobServiceClient
import src.utils.globals as g


@st.cache_data(ttl=3600, show_spinner="Loading operational price data...")
def getOperationalData():

    blob_service_client = BlobServiceClient(
        account_url=g.storage_account_url,
        credential=g.credential,
    )

    blob_client = blob_service_client.get_blob_client(
        container=g.container_name,
        blob="NED/BMU/latest_bmu_data.parquet",
    )

    parquet_bytes = blob_client.download_blob().readall()

    df = pd.read_parquet(BytesIO(parquet_bytes))
    if not df.empty and "GMT_DATETIME" in df.columns:
        df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])

    return df


@st.cache_data(ttl=3600, show_spinner="Loading time frames data...")
def getTimeFrames():

    blob_service_client = BlobServiceClient(
        account_url=g.storage_account_url,
        credential=g.credential,
    )

    container_client = blob_service_client.get_container_client(g.container_name)

    parquetFiles = []

    for blob in container_client.list_blobs(name_starts_with="NED/BMU/"):

        if blob.name.endswith(".parquet"):
            parquetFiles.append(blob.name.split("/")[-1])

    return parquetFiles


@st.cache_data(ttl=3600, show_spinner="Loading stakeholder data...")
def getStakeholders():

    blob_service_client = BlobServiceClient(
        account_url=g.storage_account_url,
        credential=g.credential,
    )

    blob_client = blob_service_client.get_blob_client(
        container=g.container_name,
        blob="NED/bm_stakeholders.parquet",
    )

    parquet_bytes = blob_client.download_blob().readall()

    df = pd.read_parquet(BytesIO(parquet_bytes))

    fuelTypes = sorted(df["sheetName"].dropna().unique().tolist())

    leadParties = sorted(df["Lead Party"].dropna().astype(str).unique().tolist())

    return df, fuelTypes, leadParties


@st.cache_data(ttl=3600, show_spinner="Loading Bid/Offer data...")
def getBidOfferData():

    blob_service_client = BlobServiceClient(
        account_url=g.storage_account_url,
        credential=g.credential,
    )

    blob_client = blob_service_client.get_blob_client(
        container=g.container_name,
        blob="NED/BID_OFFERS/latest_bid_offer_data.parquet",
    )

    parquet_bytes = blob_client.download_blob().readall()

    df = pd.read_parquet(BytesIO(parquet_bytes))
    if not df.empty and "GMT_DATETIME" in df.columns:
        df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])

    return df


@st.cache_data(ttl=3600, show_spinner="Loading BOA Instructions...")
def getBOAInstructionsData():

    blob_service_client = BlobServiceClient(
        account_url=g.storage_account_url,
        credential=g.credential,
    )

    blob_client = blob_service_client.get_blob_client(
        container=g.container_name,
        blob="NED/BOA_INSTRUCTIONS/latest_boa_instructions_data.parquet",
    )

    parquet_bytes = blob_client.download_blob().readall()

    df = pd.read_parquet(BytesIO(parquet_bytes))
    if not df.empty and "GMT_DATETIME" in df.columns:
        df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])

    return df
