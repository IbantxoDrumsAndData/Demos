import streamlit as st
import requests
import pandas as pd
from src.utils.keyvault import get_secret


@st.cache_data(ttl=3600, show_spinner="Loading wholesale price data...")
def getWholesalePrices(startDate, endDate):

    try:
        enappsys_pass = get_secret("ENAPP")
        enappsys_user = get_secret("ENAPPUSR")
    except Exception as e:
        st.error(f"[ERROR] CREDENTIAL RETRIEVAL FAILED: {e}")
        return None

    # =============================
    #   ENAPPSYS API GET REQUEST
    # =============================
    BASE_URL = "https://app.enappsys.com/datadownload"

    params = {
        "code": "gb/elec/pricing/intraday/forecast",
        "currency": "GBP",
        "delimiter": "comma",
        "minavmax": "false",
        "pass": enappsys_pass,
        "res": "hh",
        "tag": "json",
        "timezone": "WET",
        "user": enappsys_user,
        "start": startDate,
        "end": endDate,
    }

    try:
        response = requests.get(BASE_URL, params=params, timeout=30)
        response.raise_for_status()

        data = response.json()

    except requests.exceptions.RequestException as e:
        st.error(f"[ERROR] REQUEST FAILED: {e}")
        return None

    except ValueError as e:
        st.error(f"[ERROR] DATA ISSUE: {e}")
        return None

    if not isinstance(data, dict) or "data" not in data:
        st.error("[ERROR] DATA ISSUE: EnAppSys response missing 'data' field.")
        return None

    # =============================
    #     DATA PREPROCESSING
    # =============================
    df = pd.DataFrame(data["data"])  # Convert JSON to dataframe
    if df.empty:
        return pd.DataFrame(
            columns=[
                "dateTime",
                "DA_Nordpool £/MWh",
                "ID_Forecast £/MWh",
                "Upper_Forecast £/MWh",
                "Lower_Forecast £/MWh",
            ]
        )

    # Keep only required datatypes and drop the rest
    to_keep = [
        "GB_NORDPOOL_HR_DA.PRICE_GBP",  # DA Nordpool
        "GB_MIDP_PRICE_FORECAST.DM01",  # #Forecast Intraday
        "GB_SYSTEM_PRICE_FORECAST.SBP.DM01",  # Forecasted Upper Limit
        "GB_SYSTEM_PRICE_FORECAST.SSP.DM01",  # Forecasted Lower Limit
    ]

    df = df[df["dataTypeEntity"].isin(to_keep)]
    if df.empty:
        return pd.DataFrame(
            columns=[
                "dateTime",
                "DA_Nordpool £/MWh",
                "ID_Forecast £/MWh",
                "Upper_Forecast £/MWh",
                "Lower_Forecast £/MWh",
            ]
        )

    # Pivot so all types are on one line against timestamp
    df = df.pivot_table(
        index="dateTime", columns="dataTypeEntity", values="value"
    ).reset_index()

    df["dateTime"] = pd.to_datetime(df["dateTime"])  # Convert to Pandas datatime object

    df = df.sort_values("dateTime")  # Ensure data is sorted by dateTime

    # Convert price columns to numeric in case API returns strings
    for col in to_keep:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Rename columns for readability
    df = df.rename(
        columns={
            "GB_NORDPOOL_HR_DA.PRICE_GBP": "DA_Nordpool £/MWh",
            "GB_MIDP_PRICE_FORECAST.DM01": "ID_Forecast £/MWh",
            "GB_SYSTEM_PRICE_FORECAST.SBP.DM01": "Upper_Forecast £/MWh",
            "GB_SYSTEM_PRICE_FORECAST.SSP.DM01": "Lower_Forecast £/MWh",
        }
    )

    return df
