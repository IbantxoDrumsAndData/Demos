"""Local laptop Azure credential, .env loader, and Blob Storage configuration."""

import os
from pathlib import Path
from typing import Optional
from azure.identity import DefaultAzureCredential

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def load_dotenv_file(dotenv_path: Optional[Path] = None) -> dict[str, str]:
    """Load key-value pairs from a local .env file into os.environ using standard library."""
    candidates = (
        [Path(dotenv_path)]
        if dotenv_path is not None
        else [PROJECT_ROOT / ".env", Path.cwd() / ".env"]
    )

    loaded: dict[str, str] = {}
    for candidate in candidates:
        if not candidate.is_file():
            continue
        for raw_line in candidate.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export ") :].strip()
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
                value = value[1:-1]
            if key:
                loaded[key] = value
                os.environ.setdefault(key, value)
        break

    return loaded


load_dotenv_file()

client_id = os.environ.get("DEFAULT_IDENTITY_CLIENT_ID")

credential = (
    DefaultAzureCredential(managed_identity_client_id=client_id)
    if client_id
    else DefaultAzureCredential()
)

vault_url = os.environ.get("AZURE_KEYVAULT_URL", "placeholder")

storage_account_url = os.environ.get("AZURE_STORAGE_ACCOUNT_URL", "placeholder")

container_name = os.environ.get("AZURE_STORAGE_CONTAINER_NAME", "placeholder")
