"""Secret retrieval helper reading from local .env / environment variables (with Key Vault fallback)."""

import os
from pathlib import Path
from typing import Optional
from azure.keyvault.secrets import SecretClient

import src.utils.globals as g

_secret_client: Optional[SecretClient] = None

SECRET_ENV_ALIASES: dict[str, tuple[str, ...]] = {
    "ENAPP": ("ENAPP", "ENAPPSYS_PASS", "ENAPPSYS_PASSWORD"),
    "ENAPPUSR": ("ENAPPUSR", "ENAPPSYS_USER", "ENAPPSYS_USERNAME"),
}


def get_secret(secret_name: str, dotenv_path: Optional[Path] = None) -> str:
    """Retrieve a secret from .env / environment variables first, falling back to Key Vault if configured."""
    file_values = g.load_dotenv_file(dotenv_path=dotenv_path)
    candidate_keys = SECRET_ENV_ALIASES.get(secret_name, (secret_name,))

    for key in candidate_keys:
        if key in file_values and file_values[key]:
            return file_values[key]
        env_val = os.environ.get(key)
        if env_val:
            return env_val

    if not g.vault_url or g.vault_url == "placeholder":
        expected = " or ".join(candidate_keys)
        raise RuntimeError(
            f"Secret '{secret_name}' was not found in '.env' or environment variables ({expected}). "
            "Add it to your local '.env' file in the project root."
        )

    global _secret_client
    if _secret_client is None:
        _secret_client = SecretClient(
            vault_url=g.vault_url,
            credential=g.credential,
        )
    return _secret_client.get_secret(secret_name).value
