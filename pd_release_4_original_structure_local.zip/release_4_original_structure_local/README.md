# Market Monitoring Dashboard — Release 4 (Original Code Structure: Local Laptop / Windows 11 + VS Code + Conda + `.env`)

This release preserves the **exact original file and folder structure** (`streamlit_app.py`, `dashboards/demo_dashboard.py`, `dashboards/demo_dashboard_2.py`, `src/apis/*`, `src/utils/*`) with all performance and correctness fixes applied, configured for **local execution on a Windows 11 laptop** using **VS Code**, **Conda** (`python=3.11`), `DefaultAzureCredential()` (`az login`), and a local **`.env`** file for EnAppSys credentials.

---

## 1. Quick Start on Windows 11 (VS Code + Conda)

### Step 1: Open in VS Code
Open the `release_4_original_structure_local` folder in Visual Studio Code (`File > Open Folder...`).

### Step 2: Create & Activate the Conda Environment
In the VS Code terminal (**Command Prompt** or **Anaconda Prompt**):

```bat
conda env create -f environment.yml
conda activate price-dashboard-local
```
*(Or run `setup_conda_env.bat`.)*

Select the **`price-dashboard-local`** Conda interpreter in VS Code (`Ctrl+Shift+P` -> `Python: Select Interpreter` -> `price-dashboard-local`).

### Step 3: Create `.env` & Authenticate with Azure
1. Copy `.env.example` to `.env` in the project root:
   ```bat
   copy .env.example .env
   ```
2. Fill in your EnAppSys credentials and Azure Blob Storage settings in `.env`:
   ```dotenv
   ENAPPUSR=your_enappsys_username
   ENAPP=your_enappsys_password

   AZURE_STORAGE_ACCOUNT_URL=https://<your-storage-account>.blob.core.windows.net
   AZURE_STORAGE_CONTAINER_NAME=<your-container-name>
   ```
3. Run `az login` in your terminal so `DefaultAzureCredential()` can read from Azure Blob Storage:
   ```bat
   az login
   ```

### Step 4: Run the Dashboard
```bat
python -m streamlit run streamlit_app.py --server.port 8000
```
*(Or press **`F5`** in VS Code and choose **`Streamlit: Run Market Monitoring Dashboard`**, or run **`run_dashboard.bat`**.)*

---

## 2. File Structure

```text
release_4_original_structure_local/
├── .env.example                   # Template for local .env (EnAppSys + Blob Storage settings)
├── .streamlit/
│   └── config.toml
├── .vscode/                       # VS Code launch, tasks, settings & extensions for Windows 11
├── assets/
│   └── logo.png
├── environment.yml                # Conda environment specification (Python 3.11)
├── requirements.txt
├── setup_conda_env.bat
├── run_dashboard.bat
├── streamlit_app.py
├── dashboards/
│   ├── demo_dashboard.py          # Optimized main dashboard (conditional loading + caching)
│   └── demo_dashboard_2.py        # Data Diagnostics & execution timings view
└── src/
    ├── apis/
    │   ├── NEDBlob.py             # Cached Blob Parquet loaders with in-cache datetime parsing
    │   ├── elexon.py              # Cached Elexon BMU mapping & guarded REMIT loader
    │   ├── enappsys.py            # Cached EnAppSys wholesale loader (reads credentials via .env)
    │   ├── lowcarboncontracts.py
    │   └── neso.py
    └── utils/
        ├── dates.py
        ├── figTrace.py
        ├── globals.py             # Standard-library .env loader + DefaultAzureCredential()
        └── keyvault.py            # Reads ENAPP/ENAPPUSR from .env first (with Key Vault fallback)
```
