@echo off
REM Activate the Conda environment and launch the Streamlit dashboard on Windows 11
cd /d "%~dp0"
set PYTHONPATH=%~dp0
call conda activate price-dashboard-local
python -m streamlit run streamlit_app.py --server.port 8000
