# Market Monitoring - Price Dashboard (Refactored Modular Release: Local Laptop / Windows 11 + VS Code + Conda + `.env`)

This release provides the domain-modular refactored implementation of the UAT-approved **Market Monitoring - Price Dashboard** (`prizedashboard_ux_local_PASS`), configured for **local execution on a Windows 11 laptop** using **VS Code**, **Conda** (`python=3.11`), `DefaultAzureCredential()` (`az login`), and a local **`.env`** file for EnAppSys credentials.

---

## 1. Quick Start on Windows 11 (VS Code + Conda)

### Step 1: Open in VS Code
Open the `prizedashboard_refactored_local` folder in Visual Studio Code (`File > Open Folder...`).

### Step 2: Create & Activate the Conda Environment
In the VS Code terminal (**Command Prompt** or **Anaconda Prompt**):

```bat
conda env create -f environment.yml
conda activate price-dashboard-local
```
*(Or run `setup_conda_env.bat`.)*

Select the **`price-dashboard-local`** Conda interpreter in VS Code (`Ctrl+Shift+P` -> `Python: Select Interpreter` -> `price-dashboard-local`).

### Step 3: Verify `.env` & Authenticate with Azure
1. If `.env` is not already present, copy `.env.example` to `.env` in the project root:
   ```bat
   copy .env.example .env
   ```
2. Verify your EnAppSys credentials and Azure Blob Storage settings in `.env`:
   ```dotenv
   ENAPPUSR=your_enappsys_username
   ENAPP=your_enappsys_password

   AZURE_STORAGE_ACCOUNT_URL=https://<your-storage-account>.blob.core.windows.net
   AZURE_STORAGE_CONTAINER_NAME=<your-container-name>
   ```
3. Run `az login` in your terminal so `DefaultAzureCredential()` can read from Azure Blob Storage:
   ```bat
   az login
   ```

### Step 4: Run the Dashboard
```bat
python -m streamlit run streamlit_app.py --server.port 8000
```
*(Or press **`F5`** in VS Code and choose **`Streamlit: Run Market Monitoring Dashboard`**, or run **`run_dashboard.bat`**.)*

---

## 2. Modular File Structure

```text
prizedashboard_refactored_local/
├── .env.example                     # Template for local .env (EnAppSys + Blob Storage settings)
├── .streamlit/
│   └── config.toml
├── .vscode/                         # VS Code launch, tasks, settings & extensions for Windows 11
├── assets/
│   └── logo.png
├── environment.yml                  # Conda environment specification (Python 3.11)
├── requirements.txt
├── setup_conda_env.bat
├── run_dashboard.bat
├── streamlit_app.py                 # Application entry point
├── dashboards/
│   └── demo_dashboard.py            # Thin controller coordinating sidebar, data loading & tabs
└── src/
    ├── apis/                        # Cached data loaders (NEDBlob.py, elexon.py, enappsys.py, etc.)
    ├── models/
    │   └── investigation.py         # Immutable InvestigationRequest & LoadedInvestigation models
    ├── services/                    # Pure Python/Pandas business logic
    │   ├── date_service.py          # Year + Day / ISO Week / Month / Custom date resolution
    │   ├── diagnostics_service.py   # Step timings & source diagnostics recorder
    │   ├── filter_service.py        # Fuel -> Portfolio -> BMU scoping, pair presets & summary fields
    │   ├── operational_service.py   # Operational mapping prep, Dynamic Params & REMIT capacity bar prep
    │   └── price_service.py         # Wholesale filtering, Bid/Offer pivot table & BOA filtering
    ├── components/                  # Reusable UI & Plotly figure builders
    │   ├── operational_chart.py     # 750px Operational (with REMIT bars) & Dynamic Parameters charts
    │   ├── price_chart.py           # 750px Wholesale & Bid/Offer chart
    │   ├── sidebar.py               # Sidebar investigation controls & compact NESO footer
    │   ├── styles.py                # CSS styling (white cards, plum sidebar, React Aria calendar fix)
    │   └── summary_cards.py         # 5 responsive summary cards & pending-change notice
    ├── views/                       # One self-contained module per analytical tab
    │   ├── ancillary_services_view.py
    │   ├── boa_instructions_view.py
    │   ├── data_tables_view.py
    │   ├── dynamic_parameters_view.py
    │   ├── roc_view.py
    │   ├── strike_prices_view.py
    │   └── unit_prices_view.py
    └── utils/
        ├── dates.py
        ├── figTrace.py
        ├── globals.py               # Standard-library .env loader + DefaultAzureCredential()
        └── keyvault.py              # Reads ENAPP/ENAPPUSR from .env first (with Key Vault fallback)
```
