"""Plotly figure builder for Wholesale prices and BMU Bid/Offer overlays."""

from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go

from src.models.investigation import (
    CHART_HEIGHT,
    PLOTLY_BG_COLOR,
    PLOTLY_THEME,
)
from src.utils.figTrace import figTrace


def build_wholesale_figure(
    bmu: str,
    filtered_wholesale_df: pd.DataFrame,
    show_bid_offer: bool,
    selected_bod_df: pd.DataFrame,
    pair_ids: list[int],
) -> go.Figure:
    """Build the wholesale price and Bid/Offer overlay Plotly figure for a single BMU."""
    wholesale_fig = go.Figure()

    if filtered_wholesale_df is not None and not filtered_wholesale_df.empty:
        figTrace(
            wholesale_fig,
            filtered_wholesale_df["dateTime"],
            filtered_wholesale_df["ID_Forecast £/MWh"],
            "lines",
            "ID Forecast",
            line=dict(width=3),
        )
        figTrace(
            wholesale_fig,
            filtered_wholesale_df["dateTime"],
            filtered_wholesale_df["DA_Nordpool £/MWh"],
            "lines",
            "DA Forecast",
            line=dict(width=3),
        )

    if show_bid_offer and selected_bod_df is not None and not selected_bod_df.empty:
        bmu_bod_df = selected_bod_df[selected_bod_df["BMU_ID"] == bmu]
        for pair_id in pair_ids:
            pair_df = bmu_bod_df[bmu_bod_df["BOPAIR_ID"] == pair_id].sort_values(
                "GMT_DATETIME"
            )
            if pair_df.empty:
                continue

            figTrace(
                wholesale_fig,
                pair_df["GMT_DATETIME"],
                pair_df["BID_PRICE_GBP_MWH"],
                "lines",
                f"Pair {pair_id} BID",
                line=dict(width=3, dash="dot"),
            )
            figTrace(
                wholesale_fig,
                pair_df["GMT_DATETIME"],
                pair_df["OFFER_PRICE_GBP_MWH"],
                "lines",
                f"Pair {pair_id} OFFER",
                line=dict(width=3, dash="dot"),
            )

    wholesale_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        title=f"{bmu} Wholesale Data",
        xaxis_title="Date/Time",
        yaxis_title="£/MWh",
        height=CHART_HEIGHT,
        margin=dict(
            l=55,
            r=20,
            t=100,
            b=55,
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    return wholesale_fig

