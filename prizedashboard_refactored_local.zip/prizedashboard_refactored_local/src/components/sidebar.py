"""Sidebar investigation controls and compact NESO footer component."""

from __future__ import annotations

from datetime import date, datetime
import html
from pathlib import Path
from typing import Any
import pandas as pd
import streamlit as st

from src.models.investigation import (
    DEFAULT_KNOWN_PAIR_IDS,
    MONTH_NAMES,
    PAIR_PRESET_OPTIONS,
    InvestigationRequest,
)
from src.services.date_service import (
    get_iso_week_count,
    resolve_investigation_dates,
    to_datetime_bounds,
)
from src.services.filter_service import (
    get_bmu_options,
    get_portfolios_for_fuel_types,
    resolve_pair_selection,
)


def render_sidebar(
    stakeholders: pd.DataFrame,
    fuel_types: list[str],
    logo_path: Path | None = None,
) -> dict[str, Any]:
    """Render sidebar controls, handle 'Load investigation' submission, and return draft state."""
    now_dt: datetime = st.session_state.get("reference_now_dt") or datetime.now()
    current_year = now_dt.year

    with st.sidebar:
        st.markdown(
            '<div class="ux-sidebar-title">Select units, period and overlays</div>',
            unsafe_allow_html=True,
        )

        draft_fuel_type = st.multiselect(
            "Fuel types (optional)",
            options=fuel_types,
            key="sidebar_fuel_types",
        )

        portfolios_in_selected_fuel = get_portfolios_for_fuel_types(
            stakeholders,
            draft_fuel_type,
        )

        draft_portfolio = st.multiselect(
            "Portfolio (optional)",
            options=portfolios_in_selected_fuel,
            key="sidebar_portfolios",
        )

        bmu_options = get_bmu_options(
            stakeholders_df=stakeholders,
            fuel_types=draft_fuel_type,
            portfolios=draft_portfolio,
            existing_selected_bmus=st.session_state.get("sidebar_bmus", []),
        )

        draft_bmus = st.multiselect(
            "BMUs (up to 4)",
            options=bmu_options,
            max_selections=4,
            key="sidebar_bmus",
        )

        st.markdown(
            '<p class="ux-sidebar-help">Leave fuel unselected to compare technologies.</p>',
            unsafe_allow_html=True,
        )

        # Date selection
        selected_year = int(
            st.number_input(
                "Year",
                min_value=2000,
                max_value=2100,
                value=current_year,
                step=1,
                key="sidebar_year",
            )
        )

        date_mode = st.selectbox(
            "Drill down",
            options=["Single Day", "Week", "Month", "Custom Date Range"],
            index=1,
            key="date_mode_selector",
        )

        selected_day = None
        selected_week = 1
        selected_month = now_dt.month if selected_year == current_year else 1
        custom_start_date = date(selected_year, 1, 1)
        custom_end_date = (
            now_dt.date()
            if selected_year == current_year
            else date(selected_year, 12, 31)
        )

        if date_mode == "Single Day":
            default_anchor = (
                now_dt.date()
                if selected_year == current_year
                else date(selected_year, 1, 1)
            )
            selected_day = st.date_input(
                "Select day",
                value=default_anchor,
                min_value=date(selected_year, 1, 1),
                max_value=date(selected_year, 12, 31),
                format="DD/MM/YYYY",
                key="sidebar_single_day",
            )
        elif date_mode == "Week":
            max_weeks = get_iso_week_count(selected_year)
            default_week = (
                min(max_weeks, now_dt.isocalendar()[1])
                if selected_year == current_year
                else 1
            )
            selected_week = st.selectbox(
                "Week number (ISO, Monday-Sunday)",
                options=list(range(1, max_weeks + 1)),
                index=max(0, default_week - 1),
                format_func=lambda w: f"Week {w}",
                key="sidebar_week_number",
            )
        elif date_mode == "Month":
            selected_month = st.selectbox(
                "Month",
                options=list(range(1, 13)),
                index=max(0, selected_month - 1),
                format_func=lambda m: MONTH_NAMES[m],
                key="sidebar_month",
            )

        if date_mode == "Custom Date Range":
            col_from, col_to = st.columns(2)
            with col_from:
                custom_start_date = st.date_input(
                    "Start date",
                    value=custom_start_date,
                    min_value=date(2000, 1, 1),
                    max_value=date(2100, 12, 31),
                    format="DD/MM/YYYY",
                    key="sidebar_custom_start_date",
                )
            with col_to:
                custom_end_date = st.date_input(
                    "End date",
                    value=custom_end_date,
                    min_value=date(2000, 1, 1),
                    max_value=date(2100, 12, 31),
                    format="DD/MM/YYYY",
                    key="sidebar_custom_end_date",
                )
            resolved_start_date, resolved_end_date = resolve_investigation_dates(
                year=selected_year,
                mode=date_mode,
                custom_start=custom_start_date,
                custom_end=custom_end_date,
            )
            date_help_text = (
                "Custom range supports cross-year historical periods. "
                "Dates are inclusive."
            )
        else:
            resolved_start_date, resolved_end_date = resolve_investigation_dates(
                year=selected_year,
                mode=date_mode,
                selected_day=selected_day,
                selected_week=selected_week,
                selected_month=selected_month,
            )
            col_from, col_to = st.columns(2)
            with col_from:
                st.date_input(
                    "Start date",
                    value=resolved_start_date,
                    disabled=True,
                    format="DD/MM/YYYY",
                    key=f"readonly_start_{date_mode}_{resolved_start_date.isoformat()}",
                )
            with col_to:
                st.date_input(
                    "End date",
                    value=resolved_end_date,
                    disabled=True,
                    format="DD/MM/YYYY",
                    key=f"readonly_end_{date_mode}_{resolved_end_date.isoformat()}",
                )
            date_help_text = (
                "ISO week, Monday-Sunday. Boundary weeks may cross calendar years."
                if date_mode == "Week"
                else "Dates are inclusive. Year defaults to the current year when opened."
            )

        st.markdown(
            f'<p class="ux-sidebar-help">{html.escape(date_help_text)}</p>',
            unsafe_allow_html=True,
        )

        # Information overlays
        st.markdown(
            '<div class="ux-sidebar-section-label">Information overlays</div>',
            unsafe_allow_html=True,
        )

        draft_show_remit = st.checkbox(
            "REMIT on operational charts",
            value=False,
            key="sidebar_remit_checkbox",
        )
        draft_show_bid_offer = st.checkbox(
            "Bid/offer lines on price charts",
            value=False,
            key="sidebar_bo_checkbox",
        )

        draft_pair_preset = st.selectbox(
            "Bid/offer pairs",
            options=PAIR_PRESET_OPTIONS,
            index=0,
            key="pair_preset_selector",
        )

        known_pair_ids = st.session_state.get(
            "available_pair_ids", DEFAULT_KNOWN_PAIR_IDS
        )
        if not known_pair_ids:
            known_pair_ids = list(DEFAULT_KNOWN_PAIR_IDS)

        draft_custom_pairs: list[int] = []
        if draft_pair_preset == "Custom selection":
            default_custom = [-1] if -1 in known_pair_ids else known_pair_ids[:1]
            draft_custom_pairs = st.multiselect(
                "Select pairs",
                options=known_pair_ids,
                default=default_custom,
                key="sidebar_custom_pairs",
            )

        resolved_pair_ids, pair_summary_label = resolve_pair_selection(
            draft_pair_preset, draft_custom_pairs
        )

        load_clicked = st.button(
            "Load investigation",
            type="primary",
            width="stretch",
            key="sidebar_load_button",
        )

        start_dt, end_dt = to_datetime_bounds(
            resolved_start_date, resolved_end_date
        )

        sidebar_error = None
        if load_clicked:
            if not draft_bmus or len(draft_bmus) > 4:
                sidebar_error = "Select between 1 and 4 BMUs."
            elif resolved_start_date > resolved_end_date:
                sidebar_error = (
                    "Enter valid dates with Start date no later than End date."
                )
            elif (
                draft_show_bid_offer
                and draft_pair_preset == "Custom selection"
                and not resolved_pair_ids
            ):
                sidebar_error = "Select at least one custom Bid/Offer pair."
            else:
                req = InvestigationRequest(
                    show_remit_overlay=bool(draft_show_remit),
                    show_bid_offer_overlay=bool(draft_show_bid_offer),
                    datetime_range=(start_dt, end_dt),
                    start_date_str=resolved_start_date.isoformat(),
                    end_date_str=resolved_end_date.isoformat(),
                    select_fuel_type=tuple(draft_fuel_type),
                    select_portfolio=tuple(draft_portfolio),
                    select_bmus=tuple(draft_bmus),
                    pair_preset=draft_pair_preset,
                    pair_id_choices=tuple(resolved_pair_ids),
                    pair_summary_label=pair_summary_label,
                )
                st.session_state["submitted_request"] = req.to_session_dict()

        if sidebar_error:
            st.error(sidebar_error)

        # Compact footer branding
        st.markdown('<div class="ux-sidebar-foot"></div>', unsafe_allow_html=True)
        st.selectbox(
            "Dashboards",
            options=["Market Monitoring"],
            index=0,
            key="sidebar_dashboard_selector",
        )
        effective_logo = (
            logo_path
            if logo_path is not None
            else Path(__file__).resolve().parents[2] / "assets" / "logo.png"
        )
        if effective_logo.is_file():
            st.image(str(effective_logo), width=110)
        else:
            st.markdown("**NESO**")
        st.markdown(
            '<small class="ux-sidebar-foot-note">National Energy System Operator</small>',
            unsafe_allow_html=True,
        )

    return {
        "selectBMUs": tuple(draft_bmus),
        "selectFuelType": tuple(draft_fuel_type),
        "selectPortfolio": tuple(draft_portfolio),
        "datetimeRange": (start_dt, end_dt),
        "showREMITOverlay": bool(draft_show_remit),
        "showBidOfferOverlay": bool(draft_show_bid_offer),
        "pairPreset": draft_pair_preset,
        "pairIDChoices": tuple(resolved_pair_ids),
    }
