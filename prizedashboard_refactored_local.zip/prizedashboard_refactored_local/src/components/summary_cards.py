"""Top-of-page investigation summary cards and uncommitted-change notice banner."""

from __future__ import annotations

import html
import streamlit as st


def render_pending_changes_banner() -> None:
    """Render the subtle notice alerting analysts that sidebar controls changed since last load."""
    st.markdown(
        '<div class="ux-pending">'
        "Selections changed. Load investigation to update the displayed evidence."
        "</div>",
        unsafe_allow_html=True,
    )


def render_summary_cards(fields: list[tuple[str, str]]) -> None:
    """Render individual responsive summary cards across the top of the dashboard."""
    cards_html = "".join(
        f'<div class="ux-summary-card">'
        f"<span>{html.escape(str(label))}</span>"
        f"<strong>{html.escape(str(val))}</strong>"
        f"</div>"
        for label, val in fields
    )
    st.markdown(
        f'<section class="ux-summary-grid" aria-label="Loaded investigation">'
        f"{cards_html}"
        f"</section>",
        unsafe_allow_html=True,
    )

