"""Plotly figure builders for Operational Data (with REMIT capacity bars) and Dynamic Parameters."""

from __future__ import annotations

from datetime import datetime
from typing import Any
import pandas as pd
import plotly.graph_objects as go

from src.models.investigation import (
    CHART_HEIGHT,
    PLOTLY_BG_COLOR,
    PLOTLY_THEME,
)
from src.services.operational_service import prepare_remit_capacity_events
from src.utils.figTrace import figTrace

CORE_OPERATIONAL_SERIES: list[dict[str, Any]] = [
    {
        "column": "FINAL_PHYSICAL_NOTIFICATION_MW",
        "name": "FPN",
        "color": "#702082",
        "width": 3.5,
        "dash": "solid",
    },
    {
        "column": "OPERATIONAL_METERED_OUTPUT_MW",
        "name": "Metered Output",
        "color": "#E74B20",
        "width": 3.5,
        "dash": "solid",
    },
    {
        "column": "MAXIMUM_EXPORT_LIMIT",
        "name": "MEL",
        "color": "#25256A",
        "width": 2.5,
        "dash": "dash",
    },
    {
        "column": "STABLEEXPORTLIMIT",
        "name": "SEL",
        "color": "#CAA51A",
        "width": 2.5,
        "dash": "dash",
    },
    {
        "column": "MAXIMUM_IMPORT_LIMIT",
        "name": "MIL",
        "color": "#2EA44F",
        "width": 2.5,
        "dash": "solid",
    },
]

PN_HORIZON_SERIES: list[dict[str, str]] = [
    {
        "column": "PN4HRSAHEADOFEFFECTIVE_MW",
        "name": "4H PN",
        "color": "#62B5D8",
    },
    {
        "column": "PN6HRSAHEADOFEFFECTIVE_MW",
        "name": "6H PN",
        "color": "#58B8AE",
    },
    {
        "column": "PN8HRSAHEADOFEFFECTIVE_MW",
        "name": "8H PN",
        "color": "#D66AA5",
    },
    {
        "column": "PN12HRSAHEADOFEFFECTIVE_MW",
        "name": "12H PN",
        "color": "#D83F91",
    },
    {
        "column": "PN18HRSAHEADOFEFFECTIVE_MW",
        "name": "18H PN",
        "color": "#6F9423",
    },
]


def build_operational_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    show_remit: bool,
    remit_df: pd.DataFrame | None,
) -> go.Figure:
    """Build the operational Plotly figure for a single BMU matching UAT-passed specification."""
    operational_fig = go.Figure()

    # Core operational series
    for series in CORE_OPERATIONAL_SERIES:
        operational_fig.add_trace(
            go.Scatter(
                x=bmu_df["GMT_DATETIME"],
                y=bmu_df[series["column"]],
                mode="lines",
                name=series["name"],
                line=dict(
                    color=series["color"],
                    width=series["width"],
                    dash=series["dash"],
                ),
                hovertemplate=(
                    f"<b>{series['name']}</b><br>"
                    "%{x|%d %b %Y %H:%M}<br>"
                    "%{y:,.1f} MW"
                    "<extra></extra>"
                ),
            )
        )

    # Optional PN horizons (legendonly by default)
    for horizon in PN_HORIZON_SERIES:
        operational_fig.add_trace(
            go.Scatter(
                x=bmu_df["GMT_DATETIME"],
                y=bmu_df[horizon["column"]],
                mode="lines",
                name=horizon["name"],
                line=dict(
                    color=horizon["color"],
                    width=2,
                    dash="dot",
                ),
                hovertemplate=(
                    f"<b>{horizon['name']}</b><br>"
                    "%{x|%d %b %Y %H:%M}<br>"
                    "%{y:,.1f} MW"
                    "<extra></extra>"
                ),
                visible="legendonly",
            )
        )

    # REMIT capacity bars
    if show_remit:
        remit_events = prepare_remit_capacity_events(remit_df, start_dt, end_dt)
        remit_traces: list[go.Bar] = []
        available_legend_added = False
        unavailable_legend_added = False

        for ev in remit_events:
            remit_traces.append(
                go.Bar(
                    x=[ev["midpoint"]],
                    y=[ev["available_capacity"]],
                    width=[ev["width_ms"]],
                    base=[0],
                    name="REMIT available capacity",
                    marker=dict(
                        color="rgba(34, 197, 94, 0.095)",
                        line=dict(
                            color="rgba(22, 163, 74, 0.55)",
                            width=1,
                        ),
                    ),
                    hovertemplate=ev["hover_text"],
                    showlegend=not available_legend_added,
                )
            )
            available_legend_added = True

            remit_traces.append(
                go.Bar(
                    x=[ev["midpoint"]],
                    y=[ev["unavailable_capacity"]],
                    width=[ev["width_ms"]],
                    base=[ev["available_capacity"]],
                    name="REMIT unavailable capacity",
                    marker=dict(
                        color="rgba(239, 68, 68, 0.095)",
                        line=dict(
                            color="rgba(220, 38, 38, 0.55)",
                            width=1,
                        ),
                    ),
                    hovertemplate=ev["hover_text"],
                    showlegend=not unavailable_legend_added,
                )
            )
            unavailable_legend_added = True

        if remit_traces:
            operational_fig.add_traces(remit_traces)

    operational_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        title=dict(
            text=f"{bmu} Operational Data",
            x=0,
            xanchor="left",
            y=0.98,
            yanchor="top",
        ),
        xaxis_title="Date/Time",
        yaxis_title="MW",
        height=CHART_HEIGHT,
        margin=dict(
            l=55,
            r=20,
            t=150,
            b=55,
        ),
        hovermode="x unified",
        barmode="overlay",
        legend=dict(
            orientation="h",
            x=0,
            xanchor="left",
            y=1.08,
            yanchor="bottom",
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )

    return operational_fig


def build_dynamic_params_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
) -> go.Figure:
    """Build the Dynamic Parameters Plotly figure for a single BMU."""
    dynamic_fig = go.Figure()

    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGENOTICETODEVIATEFROMZERO_MINS"],
        "lines",
        "Average NDZ",
        line=dict(width=3),
    )
    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGEMINIMUMZEROTIME_MINS"],
        "lines",
        "Average MZT",
        line=dict(width=3),
    )
    figTrace(
        dynamic_fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["AVERAGEMINIMUMNONZEROTIME_MINS"],
        "lines",
        "Average MNZT",
        line=dict(width=3),
    )

    dynamic_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        title=f"{bmu} Dynamic Parameters",
        xaxis_title="Date/Time",
        yaxis_title="Time (Minutes)",
        height=CHART_HEIGHT,
        margin=dict(
            l=55,
            r=20,
            t=100,
            b=55,
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    dynamic_fig.update_xaxes(range=[start_dt, end_dt])
    return dynamic_fig

