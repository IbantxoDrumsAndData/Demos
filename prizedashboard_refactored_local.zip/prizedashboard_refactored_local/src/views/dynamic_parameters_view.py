"""Tab 2: Dynamic Parameters analytical view."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from src.components.operational_chart import build_dynamic_params_figure
from src.models.investigation import DYNAMIC_PARAM_COLUMNS, LoadedInvestigation
from src.services.diagnostics_service import timed_step


def render_dynamic_parameters_tab(
    investigation: LoadedInvestigation,
    timings: dict[str, float],
) -> pd.DataFrame:
    """Render 2-column grid of Dynamic Parameters charts and return concatenated DataFrame."""
    req = investigation.request
    select_bmus = list(req.select_bmus)
    datetime_range = req.datetime_range
    filtered_op_df = investigation.filtered_operational_df

    if investigation.operational_load_error is not None:
        st.error("Operational data could not be loaded.")
        st.exception(investigation.operational_load_error)
        return pd.DataFrame()

    if filtered_op_df.empty:
        st.info(
            "No dynamic parameters data was found for the submitted BMUs and date range."
        )
        return pd.DataFrame()

    dynamic_param_df = pd.DataFrame()
    with timed_step("dynamic_params_chart_render", timings):
        graphs_per_row = 2
        dynamic_frames: list[pd.DataFrame] = []

        for row_start in range(0, len(select_bmus), graphs_per_row):
            current_bmus = select_bmus[row_start : row_start + graphs_per_row]
            cols = (
                [st.container()]
                if len(current_bmus) == 1
                else st.columns(graphs_per_row)
            )

            for col, bmu in zip(cols, current_bmus):
                with col:
                    bmu_df = filtered_op_df[
                        filtered_op_df["BMU_ID"] == bmu
                    ].sort_values("GMT_DATETIME")

                    with st.container(border=True):
                        if bmu_df.empty:
                            st.info(
                                f"No dynamic parameters data found for BMU '{bmu}' in the selected date range."
                            )
                            continue

                        dynamic_frames.append(bmu_df[DYNAMIC_PARAM_COLUMNS])
                        dyn_fig = build_dynamic_params_figure(
                            bmu=bmu,
                            bmu_df=bmu_df,
                            start_dt=datetime_range[0],
                            end_dt=datetime_range[1],
                        )
                        st.plotly_chart(
                            dyn_fig,
                            width="stretch",
                            key=f"dyn_chart_{bmu}",
                        )

        if dynamic_frames:
            dynamic_param_df = pd.concat(
                dynamic_frames,
                ignore_index=True,
            )

    investigation.dynamic_param_df = dynamic_param_df
    return dynamic_param_df

