"""Tab 4: BOA Instructions view."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from src.models.investigation import LoadedInvestigation
from src.services.diagnostics_service import record_source_diagnostic, timed_step
from src.services.price_service import filter_boa_instructions_for_bmu


def render_boa_instructions_tab(
    investigation: LoadedInvestigation,
    timings: dict[str, float],
) -> None:
    """Render 2-column grid of per-BMU BOA instruction tables filtered by BMU and date range."""
    req = investigation.request
    select_bmus = list(req.select_bmus)
    datetime_range = req.datetime_range
    boa_data = investigation.boa_instructions_df

    if investigation.boa_load_error is not None:
        st.error("BOA instructions data could not be loaded.")
        st.exception(investigation.boa_load_error)
        return

    if boa_data is None:
        return

    with timed_step("boa_table_render", timings):
        graphs_per_row = 2
        boa_matched_frames: list[pd.DataFrame] = []

        for row_start in range(0, len(select_bmus), graphs_per_row):
            current_bmus = select_bmus[row_start : row_start + graphs_per_row]
            cols = (
                [st.container()]
                if len(current_bmus) == 1
                else st.columns(graphs_per_row)
            )

            for col, bmu in zip(cols, current_bmus):
                with col:
                    filtered_boa_df = filter_boa_instructions_for_bmu(
                        boa_df=boa_data,
                        bmu=bmu,
                        start_dt=datetime_range[0],
                        end_dt=datetime_range[1],
                    )
                    boa_matched_frames.append(filtered_boa_df)

                    with st.container(border=True):
                        st.subheader(f"{bmu} BOA Instructions")
                        if filtered_boa_df.empty:
                            st.info(
                                f"No BOA instructions found for BMU '{bmu}' in the submitted date range."
                            )
                        else:
                            st.dataframe(
                                filtered_boa_df,
                                width="stretch",
                            )

        all_filtered_boa = (
            pd.concat(boa_matched_frames, ignore_index=True)
            if boa_matched_frames
            else pd.DataFrame()
        )
        record_source_diagnostic(
            "NED BOA Instructions",
            loaded=True,
            df=boa_data,
            filtered_df=all_filtered_boa,
            timestamp_col="GMT_DATETIME",
            load_s=timings.get("boa_data_load", 0.0),
            render_s=timings.get("boa_table_render", 0.0),
        )

