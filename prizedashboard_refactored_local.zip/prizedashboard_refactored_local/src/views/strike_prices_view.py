"""Tab 5: Strike Prices view."""

from __future__ import annotations

import streamlit as st

from src.components.styles import render_notice


def render_strike_prices_tab() -> None:
    """Render the Strike Prices placeholder view."""
    st.subheader("Strike Prices")
    render_notice("Strike Prices: Not yet implemented.")

