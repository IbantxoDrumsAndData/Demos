"""Tab 7: Data Tables view."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from src.models.investigation import LoadedInvestigation
from src.services.price_service import build_wholesale_comparison_table


def render_data_tables_tab(investigation: LoadedInvestigation) -> None:
    """Render dataset selector and detailed Operational, Wholesale/Bid-Offer, Dynamic Params, and REMIT tables."""
    req = investigation.request
    select_bmus = list(req.select_bmus)
    show_remit = req.show_remit_overlay
    show_bid_offer = req.show_bid_offer_overlay
    filtered_op_df = investigation.filtered_operational_df
    filtered_wholesale_df = investigation.filtered_wholesale_df
    selected_bod_df = investigation.selected_bod_bmus_df
    dynamic_param_df = investigation.dynamic_param_df
    remit_by_bmu = investigation.remit_by_bmu

    dataset_choice = st.selectbox(
        "Dataset",
        options=[
            "Operational",
            "Wholesale / bid-offer",
            "Dynamic Parameters",
            "REMIT",
        ],
        index=0,
        key="dataset_table_selector",
    )

    if dataset_choice == "Operational":
        st.subheader("BMU(s) Operational Data")
        if filtered_op_df.empty:
            st.info(
                "No operational data was found for the submitted BMUs and date range."
            )
        else:
            selected_bmus_df = filtered_op_df[
                filtered_op_df["BMU_ID"].isin(select_bmus)
            ].sort_values("GMT_DATETIME")
            st.dataframe(selected_bmus_df, width="stretch")

    elif dataset_choice == "Wholesale / bid-offer":
        if show_bid_offer:
            st.subheader("Wholesale + Bid/Offer Data")
            comparison_df = build_wholesale_comparison_table(
                filtered_wholesale_df,
                selected_bod_df,
            )
            if comparison_df.empty:
                st.info(
                    "No wholesale or bid/offer data was found for the submitted date range."
                )
            else:
                st.dataframe(comparison_df, width="stretch")
        else:
            st.subheader("Wholesale Data")
            if filtered_wholesale_df.empty:
                st.info(
                    "No wholesale price data was found for the submitted date range."
                )
            else:
                st.dataframe(filtered_wholesale_df.copy(), width="stretch")

    elif dataset_choice == "Dynamic Parameters":
        st.subheader("Dynamic Parameters Data")
        if dynamic_param_df.empty:
            st.info(
                "No dynamic parameters data was found for the submitted BMUs and date range."
            )
        else:
            st.dataframe(dynamic_param_df, width="stretch")

    elif dataset_choice == "REMIT":
        st.subheader("REMIT Event Data")
        if not show_remit:
            st.info(
                "Enable 'REMIT on operational charts' in the sidebar and click 'Load investigation' to load REMIT event records."
            )
        elif not remit_by_bmu:
            st.info(
                "No REMIT events were found for the submitted BMUs and date range."
            )
        else:
            combined_remit_df = pd.concat(
                list(remit_by_bmu.values()),
                ignore_index=True,
            )
            st.dataframe(combined_remit_df, width="stretch")

