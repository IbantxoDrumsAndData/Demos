"""Tab 3: Ancillary Services view."""

from __future__ import annotations

import streamlit as st

from src.components.styles import render_notice


def render_ancillary_services_tab() -> None:
    """Render the Ancillary Services placeholder view."""
    st.subheader("Ancillary Services")
    render_notice(
        "Ancillary Services: Not yet implemented. Graph planned; no fabricated service participation is shown."
    )

