"""Tab 6: Wind ROC Mappings view."""

from __future__ import annotations

import streamlit as st

from src.components.styles import render_notice


def render_roc_tab() -> None:
    """Render the Wind ROC Mappings placeholder view."""
    st.subheader("Wind ROC Mappings")
    render_notice(
        "Dedicated ROC view. Existing ROC mapping content will appear here when implemented. No subsidy values or eligibility are assumed."
    )

