"""Tab 1: Unit & Prices analytical view pairing Operational and Wholesale/Bid-Offer charts per BMU."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from src.components.operational_chart import build_operational_figure
from src.components.price_chart import build_wholesale_figure
from src.models.investigation import LoadedInvestigation
from src.services.diagnostics_service import timed_step


def render_unit_prices_tab(
    investigation: LoadedInvestigation,
    timings: dict[str, float],
) -> None:
    """Render stacked per-BMU side-by-side Operational and Wholesale/Bid-Offer charts."""
    req = investigation.request
    select_bmus = list(req.select_bmus)
    datetime_range = req.datetime_range
    show_remit = req.show_remit_overlay
    show_bid_offer = req.show_bid_offer_overlay
    filtered_op_df = investigation.filtered_operational_df
    filtered_wholesale_df = investigation.filtered_wholesale_df
    selected_bod_df = investigation.selected_bod_bmus_df

    if investigation.operational_load_error is not None:
        st.error("Operational data could not be loaded.")
        st.exception(investigation.operational_load_error)
    if investigation.bid_offer_load_error is not None:
        st.error("Bid/Offer data could not be loaded.")
        st.exception(investigation.bid_offer_load_error)

    with timed_step("unit_prices_chart_render", timings):
        for bmu in select_bmus:
            st.subheader(bmu)
            col_op, col_price = st.columns(2)

            with col_op:
                with st.container(border=True):
                    bmu_op_df = (
                        filtered_op_df[
                            filtered_op_df["BMU_ID"] == bmu
                        ].sort_values("GMT_DATETIME")
                        if not filtered_op_df.empty
                        else pd.DataFrame()
                    )

                    if bmu_op_df.empty:
                        st.info(
                            f"No operational data was found for BMU '{bmu}' in the selected date range."
                        )
                    else:
                        if bmu in investigation.missing_remit_mapping_bmus:
                            st.warning(
                                f"{bmu}: No Elexon BMU mapping available; skipping REMIT lookup."
                            )
                        op_fig = build_operational_figure(
                            bmu=bmu,
                            bmu_df=bmu_op_df,
                            start_dt=datetime_range[0],
                            end_dt=datetime_range[1],
                            show_remit=show_remit,
                            remit_df=investigation.remit_by_bmu.get(bmu),
                        )
                        st.plotly_chart(
                            op_fig,
                            width="stretch",
                            key=f"op_chart_{bmu}",
                        )

            with col_price:
                with st.container(border=True):
                    has_wholesale = not filtered_wholesale_df.empty
                    has_bmu_bod = (
                        show_bid_offer
                        and not selected_bod_df.empty
                        and not selected_bod_df[
                            selected_bod_df["BMU_ID"] == bmu
                        ].empty
                    )
                    if not has_wholesale and not has_bmu_bod:
                        st.info(
                            "No wholesale price data was found for the submitted date range."
                        )
                    else:
                        price_fig = build_wholesale_figure(
                            bmu=bmu,
                            filtered_wholesale_df=filtered_wholesale_df,
                            show_bid_offer=show_bid_offer,
                            selected_bod_df=selected_bod_df,
                            pair_ids=investigation.pair_id_choices,
                        )
                        st.plotly_chart(
                            price_fig,
                            width="stretch",
                            key=f"price_chart_{bmu}",
                        )

