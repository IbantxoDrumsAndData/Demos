"""Immutable request, loaded-data bundle, and constant definitions for investigations."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
import pandas as pd

PLOTLY_THEME = "plotly_white"
PLOTLY_BG_COLOR = "#FFFFFF"
CHART_HEIGHT = 750

MONTH_NAMES: dict[int, str] = {
    1: "01 - January",
    2: "02 - February",
    3: "03 - March",
    4: "04 - April",
    5: "05 - May",
    6: "06 - June",
    7: "07 - July",
    8: "08 - August",
    9: "09 - September",
    10: "10 - October",
    11: "11 - November",
    12: "12 - December",
}

PAIR_PRESET_OPTIONS: list[str] = [
    "Pair -1",
    "Pair +1",
    "Pairs -1 and +1",
    "All pairs",
    "Custom selection",
]

DEFAULT_KNOWN_PAIR_IDS: list[int] = [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]

INVESTIGATION_TABS: list[str] = [
    "Unit & Prices",
    "Dynamic Parameters",
    "Ancillary Services",
    "BOA Instructions",
    "Strike Prices",
    "ROC",
    "Data Tables",
]

BOA_DISPLAY_COLUMNS: list[str] = [
    "GMT_DATETIME",
    "BMU_ID",
    "BOPAIR_ID",
    "BID_PRICE",
    "OFFER_PRICE",
    "CST_GROUP",
    "DIRECT_ACTION_COST",
]

DYNAMIC_PARAM_COLUMNS: list[str] = [
    "GMT_DATETIME",
    "BMU_ID",
    "AVERAGENOTICETODEVIATEFROMZERO_MINS",
    "AVERAGEMINIMUMZEROTIME_MINS",
    "AVERAGEMINIMUMNONZEROTIME_MINS",
]


@dataclass(frozen=True)
class InvestigationRequest:
    """Immutable snapshot of a submitted sidebar investigation request."""

    show_remit_overlay: bool
    show_bid_offer_overlay: bool
    datetime_range: tuple[datetime, datetime]
    start_date_str: str
    end_date_str: str
    select_fuel_type: tuple[str, ...]
    select_portfolio: tuple[str, ...]
    select_bmus: tuple[str, ...]
    pair_preset: str
    pair_id_choices: tuple[int, ...]
    pair_summary_label: str

    def to_session_dict(self) -> dict[str, Any]:
        """Serialize to the session_state['submitted_request'] dictionary contract."""
        return {
            "showREMITOverlay": self.show_remit_overlay,
            "showBidOfferOverlay": self.show_bid_offer_overlay,
            "datetimeRange": self.datetime_range,
            "startDateStr": self.start_date_str,
            "endDateStr": self.end_date_str,
            "selectFuelType": self.select_fuel_type,
            "selectPortfolio": self.select_portfolio,
            "selectBMUs": self.select_bmus,
            "pairPreset": self.pair_preset,
            "pairIDChoices": self.pair_id_choices,
            "pairSummaryLabel": self.pair_summary_label,
        }

    @classmethod
    def from_session_dict(cls, data: dict[str, Any]) -> InvestigationRequest:
        """Construct an InvestigationRequest from session_state['submitted_request']."""
        dt_range = tuple(data["datetimeRange"])
        return cls(
            show_remit_overlay=bool(data["showREMITOverlay"]),
            show_bid_offer_overlay=bool(data["showBidOfferOverlay"]),
            datetime_range=(dt_range[0], dt_range[1]),
            start_date_str=str(
                data.get("startDateStr", dt_range[0].strftime("%Y-%m-%d"))
            ),
            end_date_str=str(
                data.get("endDateStr", dt_range[1].strftime("%Y-%m-%d"))
            ),
            select_fuel_type=tuple(data.get("selectFuelType", ())),
            select_portfolio=tuple(data.get("selectPortfolio", ())),
            select_bmus=tuple(data.get("selectBMUs", ())),
            pair_preset=str(data.get("pairPreset", "Pair -1")),
            pair_id_choices=tuple(int(p) for p in data.get("pairIDChoices", ())),
            pair_summary_label=str(data.get("pairSummaryLabel", "Pair -1")),
        )


@dataclass
class LoadedInvestigation:
    """Container holding all prepared DataFrames and error states for an investigation."""

    request: InvestigationRequest
    filtered_operational_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    operational_load_error: Exception | None = None
    remit_by_bmu: dict[str, pd.DataFrame] = field(default_factory=dict)
    missing_remit_mapping_bmus: list[str] = field(default_factory=list)
    filtered_wholesale_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    selected_bod_bmus_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    pair_id_choices: list[int] = field(default_factory=list)
    bid_offer_load_error: Exception | None = None
    boa_instructions_df: pd.DataFrame | None = None
    boa_load_error: Exception | None = None
    dynamic_param_df: pd.DataFrame = field(default_factory=pd.DataFrame)

