"""Pure filtering, BMU scoping, Bid/Offer pair resolution, and summary card helpers."""

from __future__ import annotations

from typing import Any
import pandas as pd

from src.models.investigation import InvestigationRequest


def get_portfolios_for_fuel_types(
    stakeholders_df: pd.DataFrame,
    fuel_types: list[str] | tuple[str, ...],
) -> list[str]:
    """Return sorted Lead Party portfolio names scoped by optional fuel types."""
    if stakeholders_df is None or stakeholders_df.empty:
        return []

    filtered = stakeholders_df
    if fuel_types and "sheetName" in filtered.columns:
        filtered = filtered[filtered["sheetName"].isin(fuel_types)]

    if "Lead Party" not in filtered.columns:
        return []

    return sorted(filtered["Lead Party"].dropna().astype(str).unique().tolist())


def get_bmu_options(
    stakeholders_df: pd.DataFrame,
    fuel_types: list[str] | tuple[str, ...],
    portfolios: list[str] | tuple[str, ...],
    existing_selected_bmus: list[str] | tuple[str, ...] = (),
) -> list[str]:
    """Return sorted BMU IDs scoped by fuel and portfolio while preserving active selections."""
    if stakeholders_df is None or stakeholders_df.empty:
        return sorted(set(str(b) for b in existing_selected_bmus))

    filtered = stakeholders_df
    if fuel_types and "sheetName" in filtered.columns:
        filtered = filtered[filtered["sheetName"].isin(fuel_types)]

    if portfolios and "Lead Party" in filtered.columns:
        filtered = filtered[filtered["Lead Party"].isin(portfolios)]

    filtered_bmus = (
        sorted(filtered["BMU ID"].dropna().astype(str).unique().tolist())
        if "BMU ID" in filtered.columns
        else []
    )

    valid_all_bmus = (
        set(stakeholders_df["BMU ID"].dropna().astype(str))
        if "BMU ID" in stakeholders_df.columns
        else set()
    )
    preserved = [
        str(b)
        for b in existing_selected_bmus
        if not valid_all_bmus or str(b) in valid_all_bmus
    ]
    return sorted(set(filtered_bmus) | set(preserved))


def resolve_pair_selection(
    preset: str,
    custom_pairs: list[int] | tuple[int, ...],
) -> tuple[list[int], str]:
    """Resolve Bid/Offer pair preset or custom list into pair ID filter and summary text."""
    if preset == "Pair -1":
        return [-1], "Pair -1"
    if preset == "Pair +1":
        return [1], "Pair +1"
    if preset == "Pairs -1 and +1":
        return [-1, 1], "Pairs -1 and +1"
    if preset == "All pairs":
        return [], "All pairs"

    cleaned = [int(p) for p in custom_pairs]
    label = ", ".join(str(p) for p in cleaned) if cleaned else "None"
    return cleaned, label


def resolve_bmu_fuel_summary(
    bmus: list[str] | tuple[str, ...],
    stakeholders_df: pd.DataFrame,
    selected_fuels: list[str] | tuple[str, ...],
) -> str:
    """Resolve fuel types associated with the selected BMUs from stakeholder metadata."""
    if (
        stakeholders_df is not None
        and not stakeholders_df.empty
        and {"BMU ID", "sheetName"}.issubset(stakeholders_df.columns)
    ):
        matched = stakeholders_df[
            stakeholders_df["BMU ID"].astype(str).isin([str(b) for b in bmus])
        ]
        fuels = [
            str(f)
            for f in matched["sheetName"].dropna().unique().tolist()
            if str(f).strip()
        ]
        if fuels:
            return ", ".join(fuels)

    if selected_fuels:
        return ", ".join(str(f) for f in selected_fuels)
    return "All fuel types"


def build_summary_fields(
    request: InvestigationRequest,
    stakeholders_df: pd.DataFrame,
) -> list[tuple[str, str]]:
    """Build the 5 top-of-page investigation summary card key-value pairs."""
    return [
        ("BMUs", ", ".join(request.select_bmus)),
        (
            "Fuel types",
            resolve_bmu_fuel_summary(
                request.select_bmus,
                stakeholders_df,
                request.select_fuel_type,
            ),
        ),
        (
            "Portfolio",
            (
                ", ".join(request.select_portfolio)
                if request.select_portfolio
                else "All portfolios"
            ),
        ),
        ("Loaded period", f"{request.start_date_str} to {request.end_date_str}"),
        (
            "Bid/offer",
            (
                request.pair_summary_label
                if request.show_bid_offer_overlay
                else "Off"
            ),
        ),
    ]


def has_uncommitted_changes(
    draft_state: dict[str, Any],
    submitted: dict[str, Any],
) -> bool:
    """Return True if current sidebar selections differ from the loaded investigation."""
    return (
        tuple(draft_state["selectBMUs"]) != tuple(submitted["selectBMUs"])
        or tuple(draft_state["selectFuelType"]) != tuple(submitted["selectFuelType"])
        or tuple(draft_state["selectPortfolio"]) != tuple(submitted["selectPortfolio"])
        or tuple(draft_state["datetimeRange"]) != tuple(submitted["datetimeRange"])
        or bool(draft_state["showREMITOverlay"]) != bool(submitted["showREMITOverlay"])
        or bool(draft_state["showBidOfferOverlay"])
        != bool(submitted["showBidOfferOverlay"])
        or (
            bool(draft_state["showBidOfferOverlay"])
            and (
                draft_state["pairPreset"] != submitted.get("pairPreset")
                or tuple(draft_state["pairIDChoices"])
                != tuple(submitted["pairIDChoices"])
            )
        )
    )

