"""Pure date and timestamp boundary resolution helpers for analyst investigations."""

from __future__ import annotations

import calendar
from datetime import date, datetime, time


def get_iso_week_count(year: int) -> int:
    """Return total number of ISO weeks (52 or 53) for the given calendar year."""
    return date(int(year), 12, 28).isocalendar()[1]


def resolve_investigation_dates(
    year: int,
    mode: str,
    selected_day: date | None = None,
    selected_week: int = 1,
    selected_month: int = 1,
    custom_start: date | None = None,
    custom_end: date | None = None,
) -> tuple[date, date]:
    """Resolve inclusive start and end calendar dates for the chosen drill-down mode."""
    yr = int(year)
    if mode == "Single Day":
        day_val = selected_day if selected_day is not None else date(yr, 1, 1)
        return day_val, day_val

    if mode == "Week":
        max_weeks = get_iso_week_count(yr)
        wk = max(1, min(int(selected_week), max_weeks))
        return date.fromisocalendar(yr, wk, 1), date.fromisocalendar(yr, wk, 7)

    if mode == "Month":
        mo = max(1, min(int(selected_month), 12))
        last_day = calendar.monthrange(yr, mo)[1]
        return date(yr, mo, 1), date(yr, mo, last_day)

    start_val = custom_start if custom_start is not None else date(yr, 1, 1)
    end_val = custom_end if custom_end is not None else date(yr, 12, 31)
    return start_val, end_val


def to_datetime_bounds(start_d: date, end_d: date) -> tuple[datetime, datetime]:
    """Convert inclusive start and end dates into full-day datetime boundaries."""
    return (
        datetime.combine(start_d, time(0, 0, 0)),
        datetime.combine(end_d, time(23, 59, 59)),
    )

