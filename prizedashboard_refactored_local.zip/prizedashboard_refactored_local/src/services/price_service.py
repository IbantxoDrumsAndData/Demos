"""Wholesale price filtering, Bid/Offer pivot table, and BOA instruction filtering helpers."""

from __future__ import annotations

from datetime import datetime
import pandas as pd
import streamlit as st

from src.models.investigation import BOA_DISPLAY_COLUMNS


def filter_wholesale_prices(
    wholesale_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
) -> pd.DataFrame:
    """Filter wholesale price DataFrame to the submitted datetime range."""
    if wholesale_df is None or wholesale_df.empty:
        return pd.DataFrame()

    return wholesale_df[
        (wholesale_df["dateTime"] >= start_dt) & (wholesale_df["dateTime"] <= end_dt)
    ]


def prepare_bid_offer_selection(
    bid_offer_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
    select_bmus: list[str] | tuple[str, ...],
    requested_pair_ids: list[int] | tuple[int, ...],
) -> tuple[pd.DataFrame, list[int], list[int]]:
    """Filter Bid/Offer data by date and BMU, returning (selected_bod_df, available_pairs, pair_id_choices)."""
    if bid_offer_df is None or bid_offer_df.empty:
        return pd.DataFrame(), [], []

    filtered_bod = bid_offer_df[
        (bid_offer_df["GMT_DATETIME"] >= start_dt)
        & (bid_offer_df["GMT_DATETIME"] <= end_dt)
    ]
    selected_bod = filtered_bod[filtered_bod["BMU_ID"].isin(select_bmus)]

    available_pairs = sorted(selected_bod["BOPAIR_ID"].dropna().unique().tolist())
    pair_id_choices = (
        [p for p in available_pairs if p in requested_pair_ids]
        if requested_pair_ids
        else available_pairs
    )
    return selected_bod, available_pairs, pair_id_choices


@st.cache_data(ttl=3600, show_spinner=False)
def build_wholesale_comparison_table(
    filtered_wholesale_df: pd.DataFrame,
    filtered_bid_offer_df: pd.DataFrame,
) -> pd.DataFrame:
    """Pivot selected Bid/Offer pairs and left-join against wholesale price series."""
    if filtered_bid_offer_df is None or filtered_bid_offer_df.empty:
        return (
            filtered_wholesale_df.copy()
            if filtered_wholesale_df is not None
            else pd.DataFrame()
        )

    bid_offer_pivot_df = filtered_bid_offer_df.pivot_table(
        index="GMT_DATETIME",
        columns=["BMU_ID", "BOPAIR_ID"],
        values=["BID_PRICE_GBP_MWH", "OFFER_PRICE_GBP_MWH"],
        aggfunc="first",
    )

    bid_offer_pivot_df.columns = [
        (
            f"{bmu} | Pair {pair_id} | "
            f"{'Bid' if metric == 'BID_PRICE_GBP_MWH' else 'Offer'}"
        )
        for metric, bmu, pair_id in bid_offer_pivot_df.columns
    ]

    bid_offer_pivot_df = bid_offer_pivot_df.reset_index()

    if filtered_wholesale_df is None or filtered_wholesale_df.empty:
        return bid_offer_pivot_df

    return (
        filtered_wholesale_df.copy()
        .merge(
            bid_offer_pivot_df,
            left_on="dateTime",
            right_on="GMT_DATETIME",
            how="left",
        )
        .drop(columns=["GMT_DATETIME"], errors="ignore")
    )


def filter_boa_instructions_for_bmu(
    boa_df: pd.DataFrame | None,
    bmu: str,
    start_dt: datetime,
    end_dt: datetime,
) -> pd.DataFrame:
    """Filter BOA instructions by BMU and datetime range, sorted descending with standard 7 columns."""
    if boa_df is None or boa_df.empty:
        return pd.DataFrame(columns=BOA_DISPLAY_COLUMNS)

    filtered = boa_df[
        (boa_df["BMU_ID"] == bmu)
        & (boa_df["GMT_DATETIME"] >= start_dt)
        & (boa_df["GMT_DATETIME"] <= end_dt)
    ].sort_values(
        "GMT_DATETIME",
        ascending=False,
    )
    return filtered[BOA_DISPLAY_COLUMNS]

