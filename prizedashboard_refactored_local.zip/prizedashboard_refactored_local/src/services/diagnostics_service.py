"""Timing context manager and session-state source diagnostics recorder."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from time import perf_counter
import pandas as pd
import streamlit as st


@contextmanager
def timed_step(name: str, timings: dict[str, float]):
    """Measure elapsed wall-clock seconds for a named execution step."""
    started = perf_counter()
    try:
        yield
    finally:
        timings[name] = perf_counter() - started


def record_source_diagnostic(
    source_name: str,
    loaded: bool,
    df: pd.DataFrame | None = None,
    filtered_df: pd.DataFrame | None = None,
    timestamp_col: str | None = None,
    load_s: float = 0.0,
    prep_s: float = 0.0,
    render_s: float = 0.0,
    message: str = "OK",
) -> None:
    """Record internal source status and row counts into st.session_state['source_diagnostics']."""
    if "source_diagnostics" not in st.session_state:
        st.session_state["source_diagnostics"] = {}

    if not loaded or df is None:
        st.session_state["source_diagnostics"][source_name] = {
            "Source Name": source_name,
            "Status": "Not Loaded",
            "Load Duration (s)": round(load_s, 4),
            "Prep Duration (s)": round(prep_s, 4),
            "Chart Render Duration (s)": round(render_s, 4),
            "Total Rows": 0,
            "Selected-BMU Rows": 0,
            "Min Timestamp": None,
            "Max Timestamp": None,
            "Last Loaded (UTC)": None,
            "Details": message,
        }
        return

    target_df = filtered_df if filtered_df is not None else df
    min_ts = None
    max_ts = None
    if (
        timestamp_col
        and timestamp_col in target_df.columns
        and not target_df.empty
        and target_df[timestamp_col].notna().any()
    ):
        ts_series = pd.to_datetime(target_df[timestamp_col], errors="coerce").dropna()
        if not ts_series.empty:
            min_ts = str(ts_series.min())
            max_ts = str(ts_series.max())

    st.session_state["source_diagnostics"][source_name] = {
        "Source Name": source_name,
        "Status": "Loaded",
        "Load Duration (s)": round(load_s, 4),
        "Prep Duration (s)": round(prep_s, 4),
        "Chart Render Duration (s)": round(render_s, 4),
        "Total Rows": len(df),
        "Selected-BMU Rows": len(target_df),
        "Min Timestamp": min_ts,
        "Max Timestamp": max_ts,
        "Last Loaded (UTC)": datetime.now(timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S UTC"
        ),
        "Details": (
            "No rows matched submitted BMUs and date range."
            if len(target_df) == 0
            else message
        ),
    }

