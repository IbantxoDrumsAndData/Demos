"""Operational data preparation, filtering, Dynamic Parameters, and REMIT capacity bar logic."""

from __future__ import annotations

from datetime import datetime
from typing import Any
import pandas as pd
import streamlit as st

from src.models.investigation import DYNAMIC_PARAM_COLUMNS


@st.cache_data(ttl=3600, show_spinner=False)
def prepare_operational_with_mapping(
    operational_df: pd.DataFrame,
    bmu_mapping_df: pd.DataFrame,
) -> pd.DataFrame:
    """Parse operational timestamps and left-join Elexon BMU IDs."""
    df = operational_df.copy()
    df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])
    if (
        bmu_mapping_df is not None
        and not bmu_mapping_df.empty
        and {"BMU_ID", "ELEXON_BMU_ID"}.issubset(bmu_mapping_df.columns)
    ):
        df = df.merge(bmu_mapping_df, on="BMU_ID", how="left")
    elif "ELEXON_BMU_ID" not in df.columns:
        df["ELEXON_BMU_ID"] = pd.NA
    return df


@st.cache_data(ttl=3600, show_spinner=False)
def filter_operational_data(
    prepared_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    bmus_tuple: tuple[str, ...],
) -> pd.DataFrame:
    """Filter prepared operational data by datetime range and selected BMUs."""
    mask = (prepared_df["GMT_DATETIME"] >= start_dt) & (
        prepared_df["GMT_DATETIME"] <= end_dt
    )
    if bmus_tuple:
        mask = mask & prepared_df["BMU_ID"].isin(bmus_tuple)
    return prepared_df.loc[mask].sort_values("GMT_DATETIME")


def extract_dynamic_parameters_df(
    filtered_operational_df: pd.DataFrame,
    select_bmus: list[str] | tuple[str, ...],
) -> pd.DataFrame:
    """Extract concatenated Dynamic Parameters DataFrame in selected-BMU order."""
    if filtered_operational_df is None or filtered_operational_df.empty:
        return pd.DataFrame()

    dynamic_frames: list[pd.DataFrame] = []
    for bmu in select_bmus:
        bmu_df = filtered_operational_df[
            filtered_operational_df["BMU_ID"] == bmu
        ].sort_values("GMT_DATETIME")
        if bmu_df.empty:
            continue
        dynamic_frames.append(bmu_df[DYNAMIC_PARAM_COLUMNS])

    if not dynamic_frames:
        return pd.DataFrame()

    return pd.concat(dynamic_frames, ignore_index=True)


def prepare_remit_capacity_events(
    remit_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
) -> list[dict[str, Any]]:
    """Deduplicate REMIT revisions, exclude dismissed rows, and compute capacity bar specs."""
    if remit_df is None or remit_df.empty:
        return []

    required_columns = {
        "eventStartTime",
        "eventEndTime",
        "normalCapacity",
        "availableCapacity",
        "unavailableCapacity",
    }
    if not required_columns.issubset(remit_df.columns):
        return []

    r_df = remit_df.copy()

    # Keep only the latest revision of each REMIT message.
    if {"mrid", "revisionNumber"}.issubset(r_df.columns):
        r_df["revisionNumber"] = pd.to_numeric(
            r_df["revisionNumber"],
            errors="coerce",
        )
        r_df = (
            r_df.sort_values("revisionNumber")
            .drop_duplicates(subset="mrid", keep="last")
            .copy()
        )

    # Dismissed REMIT messages should not contribute to the current capacity representation.
    if "eventStatus" in r_df.columns:
        r_df = r_df[
            r_df["eventStatus"].astype(str).str.lower() != "dismissed"
        ].copy()

    r_df["eventStartTime"] = pd.to_datetime(
        r_df["eventStartTime"],
        errors="coerce",
        utc=True,
    ).dt.tz_localize(None)

    r_df["eventEndTime"] = pd.to_datetime(
        r_df["eventEndTime"],
        errors="coerce",
        utc=True,
    ).dt.tz_localize(None)

    events: list[dict[str, Any]] = []
    for _, remit in r_df.iterrows():
        event_start = remit["eventStartTime"]
        event_end = remit["eventEndTime"]

        if pd.isna(event_start) or pd.isna(event_end):
            continue

        if event_end < start_dt or event_start > end_dt:
            continue

        normal_capacity = pd.to_numeric(
            remit.get("normalCapacity"),
            errors="coerce",
        )
        available_capacity = pd.to_numeric(
            remit.get("availableCapacity"),
            errors="coerce",
        )
        unavailable_capacity = pd.to_numeric(
            remit.get("unavailableCapacity"),
            errors="coerce",
        )

        if (
            pd.isna(normal_capacity)
            or pd.isna(available_capacity)
            or pd.isna(unavailable_capacity)
            or normal_capacity <= 0
            or available_capacity < 0
            or unavailable_capacity < 0
        ):
            continue

        overlay_start = max(event_start, start_dt)
        overlay_end = min(event_end, end_dt)

        if overlay_end <= overlay_start:
            continue

        midpoint = overlay_start + (overlay_end - overlay_start) / 2
        width_ms = (overlay_end - overlay_start).total_seconds() * 1_000

        message_heading = remit.get("messageHeading")
        event_status = remit.get("eventStatus")
        cause = remit.get("cause")

        message_heading = (
            message_heading if pd.notna(message_heading) else "Capacity event"
        )
        event_status = event_status if pd.notna(event_status) else "N/A"
        cause = cause if pd.notna(cause) else "N/A"

        hover_text = (
            "<b>REMIT capacity event</b><br>"
            f"{message_heading}<br>"
            f"Start: {event_start:%d %b %Y %H:%M}<br>"
            f"End: {event_end:%d %b %Y %H:%M}<br>"
            f"Normal capacity: {normal_capacity:,.1f} MW<br>"
            f"Available capacity: {available_capacity:,.1f} MW<br>"
            f"Unavailable capacity: "
            f"{unavailable_capacity:,.1f} MW<br>"
            f"Status: {event_status}<br>"
            f"Cause: {cause}"
            "<extra></extra>"
        )

        events.append(
            {
                "midpoint": midpoint,
                "width_ms": width_ms,
                "normal_capacity": float(normal_capacity),
                "available_capacity": float(available_capacity),
                "unavailable_capacity": float(unavailable_capacity),
                "hover_text": hover_text,
            }
        )

    return events

