import streamlit as st

# =============================
#   TITLE AND COLUMN CONFIG
# =============================
st.set_page_config(
    page_title="Market Monitoring - Price Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)

demo_dashboard = st.Page(
    "dashboards/demo_dashboard.py",
    title="Market Monitoring - Price Dashboard",
)

pg = st.navigation([demo_dashboard], position="hidden")

pg.run()
