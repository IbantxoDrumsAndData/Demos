"""Main entry point for the refactored Market Monitoring Streamlit application."""

import streamlit as st

st.set_page_config(
    page_title="Market Monitoring Dashboard POC",
    layout="wide",
    initial_sidebar_state="expanded",
)

with st.sidebar:
    st.image("assets/logo.png", width="stretch")

operational_page = st.Page(
    "pages/operational_monitoring.py",
    title="Operational Monitoring",
)
market_prices_page = st.Page(
    "pages/market_prices.py",
    title="Market Prices",
)
balancing_actions_page = st.Page(
    "pages/balancing_actions.py",
    title="Balancing Actions",
)
diagnostics_page = st.Page(
    "pages/data_diagnostics.py",
    title="Data Diagnostics",
)

pg = st.navigation(
    {
        "Dashboards": [
            operational_page,
            market_prices_page,
            balancing_actions_page,
            diagnostics_page,
        ]
    }
)

pg.run()
