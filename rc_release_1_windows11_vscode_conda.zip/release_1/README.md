# Market Monitoring Dashboard — Release 1 (Windows 11 + VS Code + Conda)

Performance-optimised, multi-page Streamlit application for Market Monitoring, packaged for **Windows 11**, **Visual Studio Code**, and **Conda** (`python=3.11`).

---

## 1. Quick Start on Windows 11 (VS Code + Conda)

### Prerequisites
- **Windows 11**
- **Miniconda** or **Anaconda** installed
- **Visual Studio Code** with the **Python** extension (`ms-python.python`)
- **Azure CLI** (`az login`) if connecting to live Azure Blob Storage and Azure Key Vault locally

### Step 1: Open in VS Code
Open the `release_1` folder directly in VS Code (`File > Open Folder...`).
VS Code will automatically detect `.vscode/settings.json`, `.vscode/launch.json`, `.vscode/tasks.json`, and recommended extensions.

### Step 2: Create & Activate the Conda Environment
Open a terminal in VS Code (**Command Prompt** or **Anaconda Prompt**) and run:

```bat
conda env create -f environment.yml
conda activate price-dashboard
```
*(Alternatively, run `setup_conda_env.bat` or trigger the VS Code Task: `Terminal > Run Task... > Conda: Create/Update price-dashboard Environment`.)*

Then select the **`price-dashboard`** Conda interpreter in VS Code (`Ctrl+Shift+P` -> `Python: Select Interpreter` -> `price-dashboard`).

### Step 3: Configure Azure Endpoints
Update `src/utils/globals.py` or set the following environment variables in your terminal / `.vscode/launch.json`:
- `AZURE_KEYVAULT_URL`: Your Azure Key Vault URL (used to fetch `ENAPP` and `ENAPPUSR` secrets on demand).
- `AZURE_STORAGE_ACCOUNT_URL`: Your Azure Blob Storage account URL.
- `AZURE_STORAGE_CONTAINER_NAME`: Your Blob container name containing the `NED/` Parquet files.
- `DEFAULT_IDENTITY_CLIENT_ID` *(optional)*: Managed identity client ID (for App Service deployment).

### Step 4: Run the Dashboard
From the activated `price-dashboard` Conda terminal in VS Code:

```bat
python -m streamlit run streamlit_app.py --server.port 8000
```
*(Or press **`F5`** in VS Code and choose **`Streamlit: Run Market Monitoring Dashboard`**, or double-click **`run_dashboard.bat`**.)*

---

## 2. Running Tests, Benchmarks, and Formatting on Windows 11

With `conda activate price-dashboard`:

```bat
REM 1. Run all 11 parity validation scenarios
pytest -v tests

REM 2. Run the before-and-after performance benchmark comparison
python tests\benchmark_comparison.py

REM 3. Check code formatting with Black
black --check .
```
All three commands are also pre-configured as **VS Code Debug Configurations (`F5`)** and **VS Code Tasks (`Ctrl+Shift+B` / `Run Task`)**.

---

## 3. Application Structure

```text
release_1/
├── .streamlit/
│   └── config.toml                # NESO branding & light theme configuration
├── .vscode/
│   ├── extensions.json            # Recommended VS Code Python extensions
│   ├── launch.json                # F5 debug configs (Streamlit, Pytest, Benchmark)
│   ├── settings.json              # Windows 11 Conda, Black, and Pytest settings
│   └── tasks.json                 # One-click VS Code tasks
├── assets/
│   └── logo.png
├── environment.yml                # Conda environment specification (Python 3.11)
├── pyproject.toml                 # Project metadata, Black & Pytest config
├── requirements.txt               # Pip requirements (for Azure App Service CI/CD)
├── requirements-NED.txt           # AML NED refresh job requirements
├── setup_conda_env.bat            # Windows batch helper to create/update Conda env
├── run_dashboard.bat              # Windows batch helper to launch Streamlit
├── streamlit_app.py               # Multi-page navigation entry point
├── pages/
│   ├── operational_monitoring.py  # Operational traces, Dynamic Params, REMIT overlay
│   ├── market_prices.py           # EnAppSys wholesale prices & BMU Bid/Offer overlay
│   ├── balancing_actions.py       # BMU + date-filtered BOA instructions table
│   └── data_diagnostics.py        # Execution timings, row counts, and freshness
├── src/
│   ├── models/
│   │   └── dashboard_filters.py   # Immutable DashboardFilters & SourceDiagnostic
│   ├── repositories/
│   │   ├── stakeholder_repository.py
│   │   ├── operational_repository.py
│   │   ├── remit_repository.py
│   │   ├── wholesale_repository.py
│   │   ├── bid_offer_repository.py
│   │   └── boa_repository.py
│   ├── services/
│   │   ├── filter_service.py
│   │   ├── operational_service.py
│   │   └── price_comparison_service.py
│   ├── components/
│   │   ├── filter_panel.py
│   │   ├── operational_chart.py
│   │   ├── price_chart.py
│   │   ├── boa_table.py
│   │   └── source_status.py
│   ├── apis/                      # Legacy API modules preserved for compatibility
│   └── utils/
│       ├── dates.py
│       ├── figTrace.py
│       ├── globals.py
│       ├── keyvault.py
│       └── timing.py
├── jobs/
│   └── ned_query.py               # Scheduled NED Parquet refresh job
└── tests/
    ├── conftest.py
    ├── test_parity_scenarios.py   # 10 required parity validation scenarios
    └── benchmark_comparison.py    # Before-and-after performance benchmark script
```

---

## 4. Page Responsibilities

- **`pages/operational_monitoring.py` (Operational Monitoring)**:
  - Renders selected operational series (`MEL`, `MIL`, `SEL`, `FPN`, `Metered Output`, and `4H`, `6H`, `8H`, `12H`, `18H` PN lookback series).
  - Renders Dynamic Parameters (`Average NDZ`, `Average MZT`, `Average MNZT`) when selected.
  - Conditionally overlays Elexon REMIT outage shapes and traces when `REMIT Information` is enabled.
  - Renders optional Operational Data and Dynamic Parameters tables when `Data Tables` is enabled.
  - Displays `Not yet implemented` status messages for unfinished views (`Ancillary Services`, `Strike Prices`, `Wind ROC Mappings`).
- **`pages/market_prices.py` (Market Prices and Bid/Offer)**:
  - Renders market-wide EnAppSys wholesale prices (`ID Forecast`, `DA Forecast`).
  - Conditionally overlays BMU-specific Bid and Offer pair prices (`Pair {id} BID`, `Pair {id} OFFER`) when `Bid / Offer Data` is enabled.
  - Renders the Wholesale or Wholesale + Bid/Offer comparison pivot table when `Data Tables` is enabled.
- **`pages/balancing_actions.py` (Balancing Actions)**:
  - Renders per-BMU BOA instruction tables filtered by both selected BMUs and the submitted date range, sorted descending by `GMT_DATETIME`.
- **`pages/data_diagnostics.py` (Data Diagnostics)**:
  - Displays the last submitted `DashboardFilters` payload, per-source status (`Loaded` / `Not Loaded`), load/preparation/render durations, total and selected-BMU row counts, min/max timestamps, freshness timestamps, and `perf_counter` step timings without triggering any additional data loads.

---

## 5. Filter Submission Workflow

1. **Stage 1 — Define BMU Scope (`Update BMU list`)**:
   - Loads only lightweight stakeholder metadata (`NED/bm_stakeholders.parquet`).
   - Selecting `Fuel Type` and `Portfolio` and clicking **`Update BMU list`** updates the scoped BMU list without loading operational, wholesale, bid/offer, BOA, or REMIT data.
2. **Stage 2 — Configure & Run (`Load dashboard`)**:
   - Users configure `BMUs`, `Date Range`, `Views`, `Operational Series`, `PN Lookback Periods`, `Information Overlays`, `BO Pair IDs`, and `Data Tables`.
   - Draft widget changes do not replace the active dashboard or trigger data fetches until **`Load dashboard`** is clicked.

---

## 6. Data-Source Loading Rules & Caching Boundaries

- **Conditional Loading**: Each page loads only the repositories required by the active page and submitted views/overlays. `get_remit_data()` is never called when `REMIT Information` is disabled, when `bmu_df` is empty, or when `ELEXON_BMU_ID` is missing.
- **Caching (`@st.cache_data(ttl=3600)`)**: Applied at both raw repository fetch functions (`src/repositories/`) and downstream DataFrame preparation, timestamp parsing, Elexon BMU mapping joins, filtering, and Bid/Offer pivot functions (`src/services/`) using immutable `tuple` cache keys.

