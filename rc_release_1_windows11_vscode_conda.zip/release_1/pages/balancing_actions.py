"""Balancing Actions page: BMU and date-filtered BOA instructions table."""

import streamlit as st

from src.components.boa_table import render_boa_table
from src.components.filter_panel import render_filter_panel
from src.components.source_status import (
    get_timings_state,
    record_diagnostic,
    render_load_error,
)
from src.repositories.boa_repository import get_boa_instructions
from src.repositories.operational_repository import RepositoryError
from src.services.filter_service import derive_required_sources
from src.services.price_comparison_service import (
    BOA_DISPLAY_COLUMNS,
    prepare_boa_instructions,
)
from src.utils.timing import build_source_diagnostic, timed_step

st.title("Balancing Actions (BOA Instructions)")

submitted_filters = render_filter_panel(default_views=("BOA Instructions",))

if submitted_filters is None:
    st.info(
        "Configure your filters in the sidebar and click 'Load dashboard' "
        "to load BOA instructions."
    )
    st.stop()

timings = get_timings_state()
required_sources = derive_required_sources(
    submitted_filters,
    active_page="balancing_actions",
)

with timed_step("complete_submitted_request_duration", timings):
    if "boa_instructions" not in required_sources:
        record_diagnostic(
            build_source_diagnostic(
                source_name="NED BOA Instructions",
                loaded=False,
                message="Skipped ('BOA Instructions' view not selected).",
            )
        )
        st.info("'BOA Instructions' is not selected in the submitted views.")
        st.stop()

    try:
        with timed_step("boa_data_load", timings):
            raw_boa_df = get_boa_instructions()
    except RepositoryError as exc:
        record_diagnostic(
            build_source_diagnostic(
                source_name="NED BOA Instructions",
                loaded=False,
                load_duration_s=timings.get("boa_data_load", 0.0),
                message=str(exc),
            )
        )
        render_load_error("BOA instructions data", exc, stop_execution=True)

    with timed_step("boa_data_preparation", timings):
        prepared_boa_df = prepare_boa_instructions(raw_boa_df)
        filtered_all_bmus = prepared_boa_df[
            (prepared_boa_df["BMU_ID"].isin(submitted_filters.bmus))
            & (prepared_boa_df["GMT_DATETIME"] >= submitted_filters.start_datetime)
            & (prepared_boa_df["GMT_DATETIME"] <= submitted_filters.end_datetime)
        ]

    with timed_step("boa_table_render", timings):
        render_boa_table(
            boa_df=prepared_boa_df,
            bmus=submitted_filters.bmus,
            start_datetime=submitted_filters.start_datetime,
            end_datetime=submitted_filters.end_datetime,
        )

    record_diagnostic(
        build_source_diagnostic(
            source_name="NED BOA Instructions",
            loaded=True,
            df=raw_boa_df,
            filtered_df=filtered_all_bmus,
            timestamp_col="GMT_DATETIME",
            load_duration_s=timings.get("boa_data_load", 0.0),
            prep_duration_s=timings.get("boa_data_preparation", 0.0),
            render_duration_s=timings.get("boa_table_render", 0.0),
            required_columns=tuple(BOA_DISPLAY_COLUMNS),
        )
    )
