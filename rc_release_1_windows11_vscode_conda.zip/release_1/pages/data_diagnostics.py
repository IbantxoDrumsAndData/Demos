"""Data Diagnostics page: reports source load status, timings, row counts, and freshness."""

import pandas as pd
import streamlit as st

from src.components.filter_panel import get_submitted_filters, render_filter_panel
from src.components.source_status import get_diagnostics_state, get_timings_state

st.title("Data Diagnostics")
st.caption(
    "Reports source load status, durations, row counts, and timestamp bounds "
    "from the last submitted execution without triggering additional data loads."
)

render_filter_panel()

submitted_filters = get_submitted_filters()
diagnostics = get_diagnostics_state()
timings = get_timings_state()

if submitted_filters is not None:
    st.subheader("Last Submitted Filter Request")
    st.json(
        {
            "start_datetime": str(submitted_filters.start_datetime),
            "end_datetime": str(submitted_filters.end_datetime),
            "fuel_types": list(submitted_filters.fuel_types),
            "portfolios": list(submitted_filters.portfolios),
            "bmus": list(submitted_filters.bmus),
            "views": list(submitted_filters.views),
            "overlays": list(submitted_filters.overlays),
            "pair_ids": list(submitted_filters.pair_ids),
            "pn_lookbacks": list(submitted_filters.pn_lookbacks),
            "operational_series": list(submitted_filters.operational_series),
            "show_tables": submitted_filters.show_tables,
        }
    )
else:
    st.info("No dashboard request has been submitted yet in this session.")

st.subheader("Source Status & Diagnostics")
all_expected_sources = [
    "Stakeholder Metadata",
    "NED Operational Data",
    "Elexon BMU Mapping",
    "Elexon REMIT",
    "EnAppSys Wholesale Prices",
    "NED Bid/Offer Data",
    "NED BOA Instructions",
]

rows: list[dict] = []
for source_name in all_expected_sources:
    diag = diagnostics.get(source_name)
    if diag is None:
        rows.append(
            {
                "Source Name": source_name,
                "Status": "Not Loaded",
                "Load Duration (s)": 0.0,
                "Prep Duration (s)": 0.0,
                "Chart Render Duration (s)": 0.0,
                "Total Rows": 0,
                "Selected-BMU Rows": 0,
                "Min Timestamp": None,
                "Max Timestamp": None,
                "Last Loaded (Freshness)": None,
                "Details / Messages": "Not requested in this session.",
            }
        )
    else:
        rows.append(
            {
                "Source Name": diag.source_name,
                "Status": "Loaded" if diag.loaded else "Not Loaded",
                "Load Duration (s)": round(diag.load_duration_s, 4),
                "Prep Duration (s)": round(diag.prep_duration_s, 4),
                "Chart Render Duration (s)": round(diag.render_duration_s, 4),
                "Total Rows": diag.row_count,
                "Selected-BMU Rows": diag.selected_bmu_row_count,
                "Min Timestamp": diag.min_timestamp,
                "Max Timestamp": diag.max_timestamp,
                "Last Loaded (Freshness)": diag.freshness_timestamp,
                "Details / Messages": diag.message,
            }
        )

diagnostics_df = pd.DataFrame(rows)
st.dataframe(diagnostics_df, width="stretch")

st.subheader("Execution Step Timings (perf_counter)")
if timings:
    timings_df = pd.DataFrame(
        [
            {"Step": step_name, "Duration (s)": round(duration_s, 5)}
            for step_name, duration_s in timings.items()
        ]
    )
    st.dataframe(timings_df, width="stretch")
else:
    st.info("No execution timings recorded yet.")
