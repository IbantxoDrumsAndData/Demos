"""Market Prices page: EnAppSys wholesale prices and BMU-specific Bid/Offer overlays."""

import streamlit as st

from src.components.filter_panel import render_filter_panel
from src.components.price_chart import render_price_chart
from src.components.source_status import (
    get_timings_state,
    record_diagnostic,
    render_load_error,
)
from src.repositories.bid_offer_repository import get_bid_offer_data
from src.repositories.operational_repository import RepositoryError
from src.repositories.wholesale_repository import get_wholesale_prices
from src.services.filter_service import derive_required_sources
from src.services.price_comparison_service import (
    filter_bid_offer_data,
    filter_wholesale_prices,
)
from src.utils.timing import build_source_diagnostic, timed_step

st.title("Market Prices and Bid/Offer")
st.caption(
    "Wholesale prices (ID Forecast, DA Nordpool) are market-wide; "
    "Bid and Offer pair prices are BMU-specific."
)

submitted_filters = render_filter_panel(default_views=("Wholesale Prices",))

if submitted_filters is None:
    st.info(
        "Configure your filters in the sidebar and click 'Load dashboard' "
        "to load market prices and BMU bid/offer data."
    )
    st.stop()

timings = get_timings_state()
required_sources = derive_required_sources(
    submitted_filters,
    active_page="market_prices",
)

with timed_step("complete_submitted_request_duration", timings):
    if "wholesale_prices" not in required_sources:
        record_diagnostic(
            build_source_diagnostic(
                source_name="EnAppSys Wholesale Prices",
                loaded=False,
                message="Skipped ('Wholesale Prices' view not selected).",
            )
        )
        st.info("'Wholesale Prices' is not selected in the submitted views.")
        st.stop()

    start_str = submitted_filters.start_datetime.strftime("%Y%m%d%H%M")
    end_str = submitted_filters.end_datetime.strftime("%Y%m%d%H%M")

    try:
        with timed_step("wholesale_api_load", timings):
            raw_wholesale_df = get_wholesale_prices(start_str, end_str)
    except RepositoryError as exc:
        record_diagnostic(
            build_source_diagnostic(
                source_name="EnAppSys Wholesale Prices",
                loaded=False,
                load_duration_s=timings.get("wholesale_api_load", 0.0),
                message=str(exc),
            )
        )
        render_load_error("Wholesale price data", exc, stop_execution=True)

    with timed_step("wholesale_data_preparation", timings):
        filtered_wholesale_df = filter_wholesale_prices(
            wholesale_df=raw_wholesale_df,
            start_datetime=submitted_filters.start_datetime,
            end_datetime=submitted_filters.end_datetime,
        )

    show_bid_offer_overlay = "Bid / Offer Data" in submitted_filters.overlays
    filtered_bid_offer_df = None

    if "bid_offer_data" in required_sources:
        try:
            with timed_step("bid_offer_data_load", timings):
                raw_bid_offer_df = get_bid_offer_data()
        except RepositoryError as exc:
            record_diagnostic(
                build_source_diagnostic(
                    source_name="NED Bid/Offer Data",
                    loaded=False,
                    load_duration_s=timings.get("bid_offer_data_load", 0.0),
                    message=str(exc),
                )
            )
            render_load_error("Bid/Offer data", exc, stop_execution=True)

        with timed_step("bid_offer_preparation", timings):
            filtered_bid_offer_df = filter_bid_offer_data(
                bid_offer_df=raw_bid_offer_df,
                start_datetime=submitted_filters.start_datetime,
                end_datetime=submitted_filters.end_datetime,
                bmus=submitted_filters.bmus,
            )

        record_diagnostic(
            build_source_diagnostic(
                source_name="NED Bid/Offer Data",
                loaded=True,
                df=raw_bid_offer_df,
                filtered_df=filtered_bid_offer_df,
                timestamp_col="GMT_DATETIME",
                load_duration_s=timings.get("bid_offer_data_load", 0.0),
                prep_duration_s=timings.get("bid_offer_preparation", 0.0),
                required_columns=(
                    "GMT_DATETIME",
                    "BMU_ID",
                    "BOPAIR_ID",
                    "BID_PRICE_GBP_MWH",
                    "OFFER_PRICE_GBP_MWH",
                ),
            )
        )
    else:
        record_diagnostic(
            build_source_diagnostic(
                source_name="NED Bid/Offer Data",
                loaded=False,
                message="Skipped (Bid/Offer overlay disabled).",
            )
        )

    with timed_step("price_chart_render", timings):
        render_price_chart(
            filtered_wholesale_df=filtered_wholesale_df,
            filtered_bid_offer_df=filtered_bid_offer_df,
            bmus=submitted_filters.bmus,
            requested_pair_ids=submitted_filters.pair_ids,
            show_bid_offer_overlay=show_bid_offer_overlay,
            show_tables=submitted_filters.show_tables,
        )

    record_diagnostic(
        build_source_diagnostic(
            source_name="EnAppSys Wholesale Prices",
            loaded=True,
            df=raw_wholesale_df,
            filtered_df=filtered_wholesale_df,
            timestamp_col="dateTime",
            load_duration_s=timings.get("wholesale_api_load", 0.0),
            prep_duration_s=timings.get("wholesale_data_preparation", 0.0),
            render_duration_s=timings.get("price_chart_render", 0.0),
            required_columns=(
                "dateTime",
                "ID_Forecast £/MWh",
                "DA_Nordpool £/MWh",
            ),
        )
    )
