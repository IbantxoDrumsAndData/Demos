"""Operational Monitoring page: Operational series, Dynamic Parameters, and REMIT overlay."""

import streamlit as st

from src.components.filter_panel import render_filter_panel
from src.components.operational_chart import (
    render_dynamic_parameters_chart,
    render_operational_chart,
)
from src.components.source_status import (
    get_timings_state,
    record_diagnostic,
    render_load_error,
    render_source_status,
)
from src.models.dashboard_filters import UNFINISHED_VIEWS
from src.repositories.operational_repository import (
    RepositoryError,
    get_bmu_mapping,
    get_operational_data,
)
from src.services.filter_service import derive_required_sources
from src.services.operational_service import (
    filter_operational_data,
    prepare_operational_data,
)
from src.utils.timing import build_source_diagnostic, timed_step

st.title("Operational Monitoring")

submitted_filters = render_filter_panel(
    default_views=("Operational Data", "Dynamic Parameters")
)

if submitted_filters is None:
    st.info(
        "Configure your filters in the sidebar and click 'Load dashboard' "
        "to load operational monitoring data."
    )
    st.stop()

timings = get_timings_state()
required_sources = derive_required_sources(
    submitted_filters,
    active_page="operational_monitoring",
)

with timed_step("complete_submitted_request_duration", timings):
    if "operational_data" in required_sources:
        try:
            with timed_step("operational_data_load", timings):
                raw_operational_df = get_operational_data()
        except RepositoryError as exc:
            record_diagnostic(
                build_source_diagnostic(
                    source_name="NED Operational Data",
                    loaded=False,
                    load_duration_s=timings.get("operational_data_load", 0.0),
                    message=str(exc),
                )
            )
            render_load_error("Operational data", exc, stop_execution=True)

        bmu_mapping_df = None
        try:
            with timed_step("bmu_mapping_load", timings):
                bmu_mapping_df = get_bmu_mapping()
            record_diagnostic(
                build_source_diagnostic(
                    source_name="Elexon BMU Mapping",
                    loaded=True,
                    df=bmu_mapping_df,
                    load_duration_s=timings.get("bmu_mapping_load", 0.0),
                    required_columns=("BMU_ID", "ELEXON_BMU_ID"),
                )
            )
        except RepositoryError as exc:
            record_diagnostic(
                build_source_diagnostic(
                    source_name="Elexon BMU Mapping",
                    loaded=False,
                    load_duration_s=timings.get("bmu_mapping_load", 0.0),
                    message=str(exc),
                )
            )
            st.warning(
                f"Elexon BMU mapping could not be loaded ({exc}). "
                "Operational charts will render without REMIT mapping."
            )

        with timed_step("operational_data_preparation", timings):
            prepared_operational_df = prepare_operational_data(
                raw_operational_df,
                bmu_mapping_df,
            )
            if (
                not prepared_operational_df.empty
                and "GMT_DATETIME" in prepared_operational_df.columns
            ):
                st.session_state["data_min_datetime"] = (
                    prepared_operational_df["GMT_DATETIME"].min().to_pydatetime()
                )
                st.session_state["data_max_datetime"] = (
                    prepared_operational_df["GMT_DATETIME"].max().to_pydatetime()
                )

            filtered_operational_df = filter_operational_data(
                prepared_operational_df=prepared_operational_df,
                start_datetime=submitted_filters.start_datetime,
                end_datetime=submitted_filters.end_datetime,
                bmus=submitted_filters.bmus,
            )

        show_remit_overlay = "REMIT Information" in submitted_filters.overlays
        remit_rows_count = 0

        if "Operational Data" in submitted_filters.views:
            with timed_step("operational_chart_render", timings):
                remit_rows_count = render_operational_chart(
                    filtered_operational_df=filtered_operational_df,
                    bmus=submitted_filters.bmus,
                    start_datetime=submitted_filters.start_datetime,
                    end_datetime=submitted_filters.end_datetime,
                    show_remit_overlay=show_remit_overlay,
                    show_tables=submitted_filters.show_tables,
                    selected_series=submitted_filters.operational_series,
                    pn_lookbacks=submitted_filters.pn_lookbacks,
                    remit_timings=timings,
                )

        if "Dynamic Parameters" in submitted_filters.views:
            with timed_step("dynamic_params_chart_render", timings):
                render_dynamic_parameters_chart(
                    filtered_operational_df=filtered_operational_df,
                    bmus=submitted_filters.bmus,
                    start_datetime=submitted_filters.start_datetime,
                    end_datetime=submitted_filters.end_datetime,
                    show_tables=submitted_filters.show_tables,
                )

        total_render_time = timings.get("operational_chart_render", 0.0) + timings.get(
            "dynamic_params_chart_render", 0.0
        )
        record_diagnostic(
            build_source_diagnostic(
                source_name="NED Operational Data",
                loaded=True,
                df=raw_operational_df,
                filtered_df=filtered_operational_df,
                timestamp_col="GMT_DATETIME",
                load_duration_s=timings.get("operational_data_load", 0.0),
                prep_duration_s=timings.get("operational_data_preparation", 0.0),
                render_duration_s=total_render_time,
                required_columns=(
                    "GMT_DATETIME",
                    "BMU_ID",
                    "MAXIMUM_EXPORT_LIMIT",
                    "MAXIMUM_IMPORT_LIMIT",
                    "STABLEEXPORTLIMIT",
                    "FINAL_PHYSICAL_NOTIFICATION_MW",
                    "OPERATIONAL_METERED_OUTPUT_MW",
                ),
            )
        )

        if show_remit_overlay and "Operational Data" in submitted_filters.views:
            remit_total_s = sum(
                v for k, v in timings.items() if k.startswith("remit_load_")
            )
            record_diagnostic(
                build_source_diagnostic(
                    source_name="Elexon REMIT",
                    loaded=True,
                    load_duration_s=remit_total_s,
                    message=f"Loaded {remit_rows_count} REMIT rows across selected BMUs.",
                )
            )
        else:
            record_diagnostic(
                build_source_diagnostic(
                    source_name="Elexon REMIT",
                    loaded=False,
                    message="Skipped (REMIT overlay disabled or Operational Data view not selected).",
                )
            )
    else:
        record_diagnostic(
            build_source_diagnostic(
                source_name="NED Operational Data",
                loaded=False,
                message="Skipped (neither Operational Data nor Dynamic Parameters selected).",
            )
        )
        st.info(
            "Neither 'Operational Data' nor 'Dynamic Parameters' is selected in the submitted views."
        )

    for unfinished_view in UNFINISHED_VIEWS:
        if unfinished_view in submitted_filters.views:
            render_source_status(unfinished_view, "Not yet implemented")
