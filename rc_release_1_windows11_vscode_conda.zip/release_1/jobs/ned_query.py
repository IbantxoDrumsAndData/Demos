from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from io import BytesIO

import pandas as pd
from azure.storage.blob import BlobServiceClient
from db_connection import NEDConn

import src.utils.globals as g


def execute_ned_query(query):

    conn = NEDConn(g.credential, g.vault_url, backend="sqlalchemy")

    with conn as connection:
        df = pd.read_sql(query, connection)

    df.columns = df.columns.str.upper()

    return df


def upload_parquet_to_blob(df, blob_path):

    blob_service_client = BlobServiceClient(
        account_url=g.storage_account_url,
        credential=g.credential,
    )

    container_client = blob_service_client.get_container_client(g.container_name)

    parquet_buffer = BytesIO()

    df.to_parquet(parquet_buffer, index=False, engine="pyarrow")

    parquet_buffer.seek(0)

    container_client.upload_blob(name=blob_path, data=parquet_buffer, overwrite=True)

    print(f"Uploaded {len(df):,} rows to {blob_path}")


def getBMUData():

    query = """
    
    plahceholder
    
    """

    return execute_ned_query(query)


def getBidOfferData():

    query = """
    
    placeholder
    
    """

    return execute_ned_query(query)


def getBOAInstructions():

    query = """
    
    placeholder
    
    """

    return execute_ned_query(query)


def main():

    print("Starting BMU refresh...")

    bmu_df = getBMUData()

    print(f"Retrieved {len(bmu_df):,} BMU rows")

    upload_parquet_to_blob(bmu_df, "NED/BMU/latest_bmu_data.parquet")

    print("Operational Refresh complete")
    print("Starting Bid/Offer Refresh . . . ")

    bo_df = getBidOfferData()

    upload_parquet_to_blob(bo_df, "NED/BID_OFFERS/latest_bid_offer_data.parquet")

    print("Bid/Offer Refresh complete")

    print("Starting BOA Instructions Refresh . . .")
    boaInstructionsDF = getBOAInstructions()

    upload_parquet_to_blob(
        boaInstructionsDF, "NED/BOA_INSTRUCTIONS/latest_boa_instructions_data.parquet"
    )

    print("BOA Instructions Refresh complete")


if __name__ == "__main__":
    main()
