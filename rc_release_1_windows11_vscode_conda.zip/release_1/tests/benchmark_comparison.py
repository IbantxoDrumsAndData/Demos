"""Controlled before-and-after performance benchmark across all 10 required assessment scenarios."""

from datetime import datetime
from pathlib import Path
import sys
from time import perf_counter
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.components.operational_chart import (
    build_dynamic_parameters_figure,
    build_operational_figure,
)
from src.components.price_chart import build_price_figure
from src.models.dashboard_filters import DashboardFilters
from src.services.filter_service import (
    derive_required_sources,
    get_bmus_for_stage1,
    get_portfolios_for_fuel_types,
)
from src.services.operational_service import (
    filter_operational_by_bmu,
    filter_operational_data,
    load_remit_for_bmu,
    prepare_operational_data,
)
from src.services.price_comparison_service import (
    build_wholesale_comparison_table,
    filter_bid_offer_data,
    filter_wholesale_prices,
    get_available_pair_ids,
)
from tests.conftest import legacy_build_operational_figure, make_synthetic_datasets


def _simulate_legacy_rerun(
    raw_datasets: dict[str, pd.DataFrame],
    select_fuel_type: list[str],
    select_portfolio: list[str],
    select_bmus: list[str],
    start_dt: datetime,
    end_dt: datetime,
    selected_graphs: list[str],
    show_remit_overlay: bool,
    show_bid_offer_overlay: bool,
    show_data_tables: bool,
    io_latency_s: dict[str, float],
) -> float:
    """Measure one full execution of the legacy demo_dashboard.py script flow."""
    from time import sleep

    t0 = perf_counter()

    # Legacy top-of-script eager loading and uncached transformations
    sleep(io_latency_s["time_frames"])
    sleep(io_latency_s["bmu_mapping"])
    bmu_mapping_df = raw_datasets["bmu_mapping"].copy()

    sleep(io_latency_s["operational"])
    operational_data = raw_datasets["operational"].copy()
    operational_data["GMT_DATETIME"] = pd.to_datetime(operational_data["GMT_DATETIME"])
    operational_data = operational_data.merge(bmu_mapping_df, on="BMU_ID", how="left")

    sleep(io_latency_s["wholesale"])
    wholesale_prices = raw_datasets["wholesale"].copy()
    wholesale_prices["dateTime"] = pd.to_datetime(wholesale_prices["dateTime"])

    sleep(io_latency_s["bid_offer"])
    bid_offer_data = raw_datasets["bid_offer"].copy()
    bid_offer_data["GMT_DATETIME"] = pd.to_datetime(bid_offer_data["GMT_DATETIME"])

    sleep(io_latency_s["stakeholders"])
    stakeholders = raw_datasets["stakeholders"].copy()

    sleep(io_latency_s["boa"])
    boa_data = raw_datasets["boa"].copy()
    boa_data["GMT_DATETIME"] = pd.to_datetime(boa_data["GMT_DATETIME"])

    # Sidebar redundant datetime conversion and filtering
    operational_data["GMT_DATETIME"] = pd.to_datetime(operational_data["GMT_DATETIME"])
    _ = operational_data["GMT_DATETIME"].min().to_pydatetime()
    _ = operational_data["GMT_DATETIME"].max().to_pydatetime()
    filtered_op = operational_data[
        (operational_data["GMT_DATETIME"] >= start_dt)
        & (operational_data["GMT_DATETIME"] <= end_dt)
    ]

    bmus_in_fuel = stakeholders.copy()
    if select_fuel_type:
        bmus_in_fuel = bmus_in_fuel[bmus_in_fuel["sheetName"].isin(select_fuel_type)]
    _ = sorted(bmus_in_fuel["Lead Party"].dropna().astype(str).unique().tolist())
    bmus_in_port = bmus_in_fuel.copy()
    if select_portfolio:
        bmus_in_port = bmus_in_port[bmus_in_port["Lead Party"].isin(select_portfolio)]
    if select_portfolio and select_fuel_type:
        _ = sorted(bmus_in_port["BMU ID"].dropna().astype(str).unique().tolist())
    else:
        _ = sorted(operational_data["BMU_ID"].dropna().astype(str).unique().tolist())

    if "Operational Data" in selected_graphs and select_bmus:
        for bmu in select_bmus:
            # Legacy bug: always calls getRemit even when show_remit_overlay is False
            sleep(io_latency_s["remit_per_bmu"])
            legacy_build_operational_figure(
                raw_datasets["operational"],
                bmu_mapping_df,
                bmu,
                start_dt,
                end_dt,
                show_remit=show_remit_overlay,
                remit_df=raw_datasets["remit"],
            )

    if "Wholesale Prices" in selected_graphs:
        filtered_ws = wholesale_prices[
            (wholesale_prices["dateTime"] >= start_dt)
            & (wholesale_prices["dateTime"] <= end_dt)
        ]
        filtered_bod = None
        pair_choices = []
        if show_bid_offer_overlay:
            filtered_bod = bid_offer_data[
                (bid_offer_data["GMT_DATETIME"] >= start_dt)
                & (bid_offer_data["GMT_DATETIME"] <= end_dt)
                & (bid_offer_data["BMU_ID"].isin(select_bmus))
            ]
            pair_choices = sorted(filtered_bod["BOPAIR_ID"].dropna().unique().tolist())
        for bmu in select_bmus:
            bmu_bod = (
                filtered_bod[filtered_bod["BMU_ID"] == bmu]
                if filtered_bod is not None
                else None
            )
            build_price_figure(
                bmu=bmu,
                filtered_wholesale_df=filtered_ws,
                bmu_bid_offer_df=bmu_bod,
                pair_ids=pair_choices,
                show_bid_offer_overlay=show_bid_offer_overlay,
            )
        if show_data_tables and select_bmus:
            build_wholesale_comparison_table(
                filtered_ws, filtered_bod, show_bid_offer_overlay
            )

    if "Dynamic Parameters" in selected_graphs and select_bmus:
        for bmu in select_bmus:
            bmu_df = filtered_op[filtered_op["BMU_ID"] == bmu].sort_values(
                "GMT_DATETIME"
            )
            build_dynamic_parameters_figure(bmu, bmu_df, start_dt, end_dt)

    return perf_counter() - t0


def _simulate_refactored_execution(
    raw_datasets: dict[str, pd.DataFrame],
    stage: str,
    filters: DashboardFilters,
    active_page: str,
    io_latency_s: dict[str, float],
    cache_warm: bool,
) -> float:
    """Measure one execution of the refactored two-stage conditional & cached pipeline."""
    from time import sleep

    t0 = perf_counter()

    # Lightweight stakeholder metadata is always needed for the sidebar
    if not cache_warm:
        sleep(io_latency_s["stakeholders"])
    stakeholders = raw_datasets["stakeholders"]
    _ = get_portfolios_for_fuel_types(stakeholders, filters.fuel_types)
    _ = get_bmus_for_stage1(stakeholders, filters.fuel_types, filters.portfolios)

    if stage in ("initial_shell", "stage1_interaction"):
        return perf_counter() - t0

    required = derive_required_sources(filters, active_page=active_page)

    if "operational_data" in required:
        if not cache_warm:
            sleep(io_latency_s["operational"])
            sleep(io_latency_s["bmu_mapping"])
        prepared_op = prepare_operational_data(
            raw_datasets["operational"], raw_datasets["bmu_mapping"]
        )
        filtered_op = filter_operational_data(
            prepared_op, filters.start_datetime, filters.end_datetime, filters.bmus
        )
        show_remit = "REMIT Information" in filters.overlays
        if "Operational Data" in filters.views:
            for bmu in filters.bmus:
                bmu_df = filter_operational_by_bmu(filtered_op, bmu)

                def remit_fetcher(*_args, **_kwargs):
                    if not cache_warm:
                        sleep(io_latency_s["remit_per_bmu"])
                    return raw_datasets["remit"]

                _, overlays, _ = load_remit_for_bmu(
                    bmu_df=bmu_df,
                    start_datetime=filters.start_datetime,
                    end_datetime=filters.end_datetime,
                    show_remit_overlay=show_remit,
                    remit_fetcher=remit_fetcher,
                )
                build_operational_figure(
                    bmu=bmu,
                    bmu_df=bmu_df,
                    selected_series=filters.operational_series,
                    pn_lookbacks=filters.pn_lookbacks,
                    remit_overlays=overlays if show_remit else None,
                )

    if "wholesale_prices" in required:
        if not cache_warm:
            sleep(io_latency_s["wholesale"])
        filtered_ws = filter_wholesale_prices(
            raw_datasets["wholesale"],
            filters.start_datetime,
            filters.end_datetime,
        )
        show_bod = "Bid / Offer Data" in filters.overlays
        filtered_bod = None
        pair_ids = []
        if "bid_offer_data" in required:
            if not cache_warm:
                sleep(io_latency_s["bid_offer"])
            filtered_bod = filter_bid_offer_data(
                raw_datasets["bid_offer"],
                filters.start_datetime,
                filters.end_datetime,
                filters.bmus,
            )
            pair_ids = get_available_pair_ids(filtered_bod)
        for bmu in filters.bmus:
            bmu_bod = (
                filtered_bod[filtered_bod["BMU_ID"] == bmu]
                if filtered_bod is not None
                else None
            )
            build_price_figure(
                bmu=bmu,
                filtered_wholesale_df=filtered_ws,
                bmu_bid_offer_df=bmu_bod,
                pair_ids=pair_ids,
                show_bid_offer_overlay=show_bod,
            )
        if filters.show_tables and filters.bmus:
            build_wholesale_comparison_table(filtered_ws, filtered_bod, show_bod)

    return perf_counter() - t0


def run_benchmark_suite() -> pd.DataFrame:
    """Run before-and-after benchmark across all 10 required scenarios and return results table."""
    datasets = make_synthetic_datasets(num_bmus=30, num_periods=480)

    # Representative scaled I/O latencies (proportional to the 20s initial load baseline)
    # Plus pure in-memory DataFrame prep/merge/pivot/Plotly overhead measured live
    scaled_io = {
        "time_frames": 0.02,
        "stakeholders": 0.02,
        "bmu_mapping": 0.04,
        "operational": 0.12,
        "wholesale": 0.08,
        "bid_offer": 0.10,
        "boa": 0.05,
        "remit_per_bmu": 0.06,
    }
    no_io = {k: 0.0 for k in scaled_io}

    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 30, 0, 0)
    alt_end_dt = datetime(2026, 10, 31, 0, 0)

    base_filters = DashboardFilters(
        start_datetime=start_dt,
        end_datetime=end_dt,
        fuel_types=("GAS",),
        portfolios=("PORTFOLIO_ALPHA",),
        bmus=("T_BMU_01", "T_BMU_02"),
        views=("Operational Data",),
        overlays=(),
        show_tables=True,
    )

    scenarios = [
        (
            "1. Initial shell load (cold)",
            lambda: _simulate_legacy_rerun(
                datasets,
                [],
                [],
                [],
                start_dt,
                end_dt,
                [],
                False,
                False,
                False,
                scaled_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "initial_shell",
                base_filters,
                "operational_monitoring",
                scaled_io,
                False,
            ),
        ),
        (
            "2. Stage 1 metadata/filter interaction (warm)",
            lambda: _simulate_legacy_rerun(
                datasets,
                ["GAS"],
                ["PORTFOLIO_ALPHA"],
                [],
                start_dt,
                end_dt,
                [],
                False,
                False,
                False,
                no_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage1_interaction",
                base_filters,
                "operational_monitoring",
                no_io,
                True,
            ),
        ),
        (
            "3. Stage 2 submitted request (cold)",
            lambda: _simulate_legacy_rerun(
                datasets,
                ["GAS"],
                ["PORTFOLIO_ALPHA"],
                ["T_BMU_01", "T_BMU_02"],
                start_dt,
                end_dt,
                ["Operational Data"],
                False,
                False,
                True,
                scaled_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                base_filters,
                "operational_monitoring",
                scaled_io,
                False,
            ),
        ),
        (
            "4. Repeated identical request (cached)",
            lambda: _simulate_legacy_rerun(
                datasets,
                ["GAS"],
                ["PORTFOLIO_ALPHA"],
                ["T_BMU_01", "T_BMU_02"],
                start_dt,
                end_dt,
                ["Operational Data"],
                False,
                False,
                True,
                no_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                base_filters,
                "operational_monitoring",
                no_io,
                True,
            ),
        ),
        (
            "5. BMU change (warm source cache)",
            lambda: _simulate_legacy_rerun(
                datasets,
                ["GAS"],
                ["PORTFOLIO_ALPHA"],
                ["T_BMU_03", "T_BMU_04"],
                start_dt,
                end_dt,
                ["Operational Data"],
                False,
                False,
                True,
                no_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                DashboardFilters(
                    start_datetime=start_dt,
                    end_datetime=end_dt,
                    fuel_types=("GAS",),
                    portfolios=("PORTFOLIO_ALPHA",),
                    bmus=("T_BMU_03", "T_BMU_04"),
                    views=("Operational Data",),
                    overlays=(),
                    show_tables=True,
                ),
                "operational_monitoring",
                no_io,
                True,
            ),
        ),
        (
            "6. Date-range change (warm source cache)",
            lambda: _simulate_legacy_rerun(
                datasets,
                ["GAS"],
                ["PORTFOLIO_ALPHA"],
                ["T_BMU_01", "T_BMU_02"],
                start_dt,
                alt_end_dt,
                ["Operational Data"],
                False,
                False,
                True,
                no_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                DashboardFilters(
                    start_datetime=start_dt,
                    end_datetime=alt_end_dt,
                    fuel_types=("GAS",),
                    portfolios=("PORTFOLIO_ALPHA",),
                    bmus=("T_BMU_01", "T_BMU_02"),
                    views=("Operational Data",),
                    overlays=(),
                    show_tables=True,
                ),
                "operational_monitoring",
                no_io,
                True,
            ),
        ),
        (
            "7. Operational-only request (REMIT off)",
            lambda: _simulate_legacy_rerun(
                datasets,
                [],
                [],
                ["T_BMU_01", "T_BMU_02"],
                start_dt,
                end_dt,
                ["Operational Data"],
                False,
                False,
                False,
                scaled_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                DashboardFilters(
                    start_datetime=start_dt,
                    end_datetime=end_dt,
                    bmus=("T_BMU_01", "T_BMU_02"),
                    views=("Operational Data",),
                    overlays=(),
                ),
                "operational_monitoring",
                scaled_io,
                False,
            ),
        ),
        (
            "8. Market-price-only request (Bid/Offer off)",
            lambda: _simulate_legacy_rerun(
                datasets,
                [],
                [],
                ["T_BMU_01", "T_BMU_02"],
                start_dt,
                end_dt,
                ["Wholesale Prices"],
                False,
                False,
                False,
                scaled_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                DashboardFilters(
                    start_datetime=start_dt,
                    end_datetime=end_dt,
                    bmus=("T_BMU_01", "T_BMU_02"),
                    views=("Wholesale Prices",),
                    overlays=(),
                ),
                "market_prices",
                scaled_io,
                False,
            ),
        ),
        (
            "9. Operational + REMIT enabled",
            lambda: _simulate_legacy_rerun(
                datasets,
                [],
                [],
                ["T_BMU_01", "T_BMU_02"],
                start_dt,
                end_dt,
                ["Operational Data"],
                True,
                False,
                False,
                scaled_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                DashboardFilters(
                    start_datetime=start_dt,
                    end_datetime=end_dt,
                    bmus=("T_BMU_01", "T_BMU_02"),
                    views=("Operational Data",),
                    overlays=("REMIT Information",),
                ),
                "operational_monitoring",
                scaled_io,
                False,
            ),
        ),
        (
            "10. Market price + Bid/Offer enabled",
            lambda: _simulate_legacy_rerun(
                datasets,
                [],
                [],
                ["T_BMU_01", "T_BMU_02"],
                start_dt,
                end_dt,
                ["Wholesale Prices"],
                False,
                True,
                True,
                scaled_io,
            ),
            lambda: _simulate_refactored_execution(
                datasets,
                "stage2_submit",
                DashboardFilters(
                    start_datetime=start_dt,
                    end_datetime=end_dt,
                    bmus=("T_BMU_01", "T_BMU_02"),
                    views=("Wholesale Prices",),
                    overlays=("Bid / Offer Data",),
                    show_tables=True,
                ),
                "market_prices",
                scaled_io,
                False,
            ),
        ),
    ]

    rows = []
    for label, legacy_fn, refactored_fn in scenarios:
        before_s = legacy_fn()
        after_s = refactored_fn()
        reduction_pct = (
            ((before_s - after_s) / before_s * 100.0) if before_s > 0 else 0.0
        )
        speedup = (before_s / after_s) if after_s > 0 else float("inf")
        rows.append(
            {
                "Scenario": label,
                "Before (s)": round(before_s, 4),
                "After (s)": round(after_s, 4),
                "Reduction (%)": round(reduction_pct, 1),
                "Speedup (x)": round(speedup, 1),
            }
        )

    return pd.DataFrame(rows)


def format_markdown_table(df: pd.DataFrame) -> str:
    """Format a DataFrame as a GitHub-Flavored Markdown table without external dependencies."""
    headers = list(df.columns)
    header_line = "| " + " | ".join(headers) + " |"
    sep_line = "| " + " | ".join(["---"] * len(headers)) + " |"
    body_lines = []
    for _, row in df.iterrows():
        body_lines.append("| " + " | ".join(str(row[col]) for col in headers) + " |")
    return "\n".join([header_line, sep_line, *body_lines])


if __name__ == "__main__":
    results_df = run_benchmark_suite()
    print(format_markdown_table(results_df))
