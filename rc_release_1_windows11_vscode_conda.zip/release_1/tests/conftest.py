"""Shared synthetic fixtures and legacy reference helpers for parity and benchmark tests."""

from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import pytest

from src.utils.figTrace import figTrace


def make_synthetic_datasets(
    num_bmus: int = 20,
    num_periods: int = 480,
) -> dict[str, pd.DataFrame]:
    """Generate deterministic datasets matching production NED, Elexon, and EnAppSys schemas."""
    rng = np.random.default_rng(42)
    base_dt = datetime(2026, 10, 25, 0, 0, 0)
    timestamps = [base_dt + timedelta(minutes=30 * i) for i in range(num_periods)]
    ts_strings = [dt.strftime("%Y-%m-%d %H:%M:%S") for dt in timestamps]

    bmu_ids = [f"T_BMU_{i:02d}" for i in range(1, num_bmus + 1)]
    fuel_types = ["GAS", "WIND", "BATTERY", "BIOMASS"]
    portfolios = ["PORTFOLIO_ALPHA", "PORTFOLIO_BETA", "PORTFOLIO_GAMMA"]

    stakeholder_rows = []
    for idx, bmu_id in enumerate(bmu_ids):
        stakeholder_rows.append(
            {
                "sheetName": fuel_types[idx % len(fuel_types)],
                "Lead Party": portfolios[idx % len(portfolios)],
                "BMU ID": bmu_id,
            }
        )
    stakeholders_df = pd.DataFrame(stakeholder_rows)

    mapping_rows = []
    for idx, bmu_id in enumerate(bmu_ids):
        # Leave last BMU without Elexon mapping to test Scenario 9
        if idx == len(bmu_ids) - 1:
            continue
        mapping_rows.append(
            {
                "BMU_ID": bmu_id,
                "ELEXON_BMU_ID": f"ELEX_{bmu_id}",
            }
        )
    bmu_mapping_df = pd.DataFrame(mapping_rows)

    op_records = []
    for bmu_id in bmu_ids:
        n = len(ts_strings)
        op_records.append(
            pd.DataFrame(
                {
                    "GMT_DATETIME": ts_strings,
                    "BMU_ID": [bmu_id] * n,
                    "MAXIMUM_EXPORT_LIMIT": rng.uniform(300, 500, n).round(2),
                    "MAXIMUM_IMPORT_LIMIT": rng.uniform(-100, 0, n).round(2),
                    "STABLEEXPORTLIMIT": rng.uniform(150, 290, n).round(2),
                    "FINAL_PHYSICAL_NOTIFICATION_MW": rng.uniform(100, 450, n).round(2),
                    "OPERATIONAL_METERED_OUTPUT_MW": rng.uniform(95, 455, n).round(2),
                    "PN4HRSAHEADOFEFFECTIVE_MW": rng.uniform(100, 440, n).round(2),
                    "PN6HRSAHEADOFEFFECTIVE_MW": rng.uniform(100, 440, n).round(2),
                    "PN8HRSAHEADOFEFFECTIVE_MW": rng.uniform(100, 440, n).round(2),
                    "PN12HRSAHEADOFEFFECTIVE_MW": rng.uniform(100, 440, n).round(2),
                    "PN18HRSAHEADOFEFFECTIVE_MW": rng.uniform(100, 440, n).round(2),
                    "AVERAGENOTICETODEVIATEFROMZERO_MINS": rng.integers(5, 30, n),
                    "AVERAGEMINIMUMZEROTIME_MINS": rng.integers(15, 60, n),
                    "AVERAGEMINIMUMNONZEROTIME_MINS": rng.integers(30, 120, n),
                }
            )
        )
    operational_df = pd.concat(op_records, ignore_index=True)

    wholesale_df = pd.DataFrame(
        {
            "dateTime": pd.to_datetime(ts_strings),
            "DA_Nordpool £/MWh": rng.uniform(45.0, 120.0, len(ts_strings)).round(2),
            "ID_Forecast £/MWh": rng.uniform(40.0, 130.0, len(ts_strings)).round(2),
            "Upper_Forecast £/MWh": rng.uniform(100.0, 180.0, len(ts_strings)).round(2),
            "Lower_Forecast £/MWh": rng.uniform(10.0, 60.0, len(ts_strings)).round(2),
        }
    )

    bod_records = []
    for bmu_id in bmu_ids[:8]:
        for pair_id in (-1, 1, 2):
            n = len(ts_strings)
            bod_records.append(
                pd.DataFrame(
                    {
                        "GMT_DATETIME": ts_strings,
                        "BMU_ID": [bmu_id] * n,
                        "BOPAIR_ID": [pair_id] * n,
                        "BID_PRICE_GBP_MWH": rng.uniform(20.0, 65.0, n).round(2),
                        "OFFER_PRICE_GBP_MWH": rng.uniform(75.0, 160.0, n).round(2),
                    }
                )
            )
    bid_offer_df = pd.concat(bod_records, ignore_index=True)

    boa_records = []
    for bmu_id in bmu_ids[:8]:
        sample_ts = ts_strings[::6]
        m = len(sample_ts)
        boa_records.append(
            pd.DataFrame(
                {
                    "GMT_DATETIME": sample_ts,
                    "BMU_ID": [bmu_id] * m,
                    "BOPAIR_ID": rng.choice([-1, 1, 2], m),
                    "BID_PRICE": rng.uniform(25.0, 60.0, m).round(2),
                    "OFFER_PRICE": rng.uniform(80.0, 150.0, m).round(2),
                    "CST_GROUP": ["SYSTEM"] * m,
                    "DIRECT_ACTION_COST": rng.uniform(1000.0, 25000.0, m).round(2),
                    "EXTRA_UNSHOWN_COL": ["IGNORED"] * m,
                }
            )
        )
    boa_df = pd.concat(boa_records, ignore_index=True)

    remit_df = pd.DataFrame(
        [
            {
                "eventStartTime": "2026-10-26T06:00:00Z",
                "eventEndTime": "2026-10-27T18:00:00Z",
                "normalCapacity": 500.0,
                "unavailableCapacity": 150.0,
            },
            {
                "eventStartTime": "2026-10-29T00:00:00Z",
                "eventEndTime": "2026-10-29T12:00:00Z",
                "normalCapacity": 500.0,
                "unavailableCapacity": 200.0,
            },
        ]
    )

    return {
        "stakeholders": stakeholders_df,
        "bmu_mapping": bmu_mapping_df,
        "operational": operational_df,
        "wholesale": wholesale_df,
        "bid_offer": bid_offer_df,
        "boa": boa_df,
        "remit": remit_df,
    }


def legacy_build_operational_figure(
    operational_df: pd.DataFrame,
    bmu_mapping_df: pd.DataFrame,
    bmu: str,
    start_dt: datetime,
    end_dt: datetime,
    show_remit: bool,
    remit_df: pd.DataFrame,
) -> tuple[go.Figure, pd.DataFrame]:
    """Reproduce exact operational figure and table construction from dashboards/demo_dashboard.py."""
    op = operational_df.copy()
    op["GMT_DATETIME"] = pd.to_datetime(op["GMT_DATETIME"])
    op = op.merge(bmu_mapping_df, on="BMU_ID", how="left")

    filtered_op = op[(op["GMT_DATETIME"] >= start_dt) & (op["GMT_DATETIME"] <= end_dt)]
    bmu_df = filtered_op[filtered_op["BMU_ID"] == bmu].sort_values("GMT_DATETIME")

    fig = go.Figure()
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["MAXIMUM_EXPORT_LIMIT"],
        "lines",
        "MEL",
        line=dict(width=3, dash="dot"),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["MAXIMUM_IMPORT_LIMIT"],
        "lines",
        "MIL",
        line=dict(width=3),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["STABLEEXPORTLIMIT"],
        "lines",
        "SEL",
        line=dict(width=3, dash="dot"),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["FINAL_PHYSICAL_NOTIFICATION_MW"],
        "lines",
        "FPN",
        line=dict(width=3),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["OPERATIONAL_METERED_OUTPUT_MW"],
        "lines",
        "Metered Output",
        line=dict(width=3, dash="dot"),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN4HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "4H PN",
        line=dict(width=3),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN6HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "6H PN",
        line=dict(width=3),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN8HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "8H PN",
        line=dict(width=3),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN12HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "12H PN",
        line=dict(width=3),
    )
    figTrace(
        fig,
        bmu_df["GMT_DATETIME"],
        bmu_df["PN18HRSAHEADOFEFFECTIVE_MW"],
        "lines",
        "18H PN",
        line=dict(width=3),
    )

    if show_remit and remit_df is not None and not remit_df.empty:
        r_df = remit_df.copy()
        r_df["eventStartTime"] = pd.to_datetime(r_df["eventStartTime"]).dt.tz_localize(
            None
        )
        r_df["eventEndTime"] = pd.to_datetime(r_df["eventEndTime"]).dt.tz_localize(None)
        for _, remit in r_df.iterrows():
            if remit["eventEndTime"] < start_dt or remit["eventStartTime"] > end_dt:
                continue
            overlay_start = max(remit["eventStartTime"], start_dt)
            overlay_end = min(remit["eventEndTime"], end_dt)
            normal_cap = remit["normalCapacity"]
            unavail_cap = remit["unavailableCapacity"]
            avail_cap = normal_cap - unavail_cap
            fig.add_shape(
                type="rect",
                x0=overlay_start,
                x1=overlay_end,
                y0=avail_cap,
                y1=normal_cap,
                fillcolor="red",
                opacity=0.3,
                line_width=0,
            )
            fig.add_trace(
                go.Scatter(
                    x=[overlay_start, overlay_end],
                    y=[avail_cap, avail_cap],
                    mode="lines",
                    name=(
                        f"REMIT | "
                        f"{unavail_cap} MW | "
                        f"{remit['eventStartTime'].strftime('%d %b')} → "
                        f"{remit['eventEndTime'].strftime('%d %b')}"
                    ),
                    line=dict(color="red", width=2),
                )
            )

    fig.update_layout(
        template="plotly_white",
        title=f"{bmu} Operational Data",
        xaxis_title="Date/Time",
        yaxis_title="MW",
        height=500,
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    return fig, bmu_df


@pytest.fixture(scope="module")
def synthetic_data() -> dict[str, pd.DataFrame]:
    """Provide deterministic synthetic datasets across tests."""
    return make_synthetic_datasets(num_bmus=12, num_periods=240)
