@echo off
REM Create or update the Conda environment for the Market Monitoring Dashboard on Windows 11
echo Creating/updating Conda environment 'price-dashboard' from environment.yml...
call conda env update --file "%~dp0environment.yml" --prune
if %ERRORLEVEL% NEQ 0 (
    echo Failed to create/update Conda environment. Ensure Anaconda/Miniconda is installed and on PATH.
    exit /b %ERRORLEVEL%
)
echo.
echo Environment 'price-dashboard' is ready.
echo Activate it with: conda activate price-dashboard

