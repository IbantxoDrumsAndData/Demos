"""Market wholesale price and BMU Bid/Offer overlay chart and table components."""

from typing import Optional
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.components.source_status import render_empty_result
from src.services.price_comparison_service import (
    build_wholesale_comparison_table,
    get_available_pair_ids,
)
from src.utils.figTrace import figTrace

PLOTLY_THEME = "plotly_white"


def build_price_figure(
    bmu: str,
    filtered_wholesale_df: pd.DataFrame,
    bmu_bid_offer_df: Optional[pd.DataFrame] = None,
    pair_ids: Optional[list] = None,
    show_bid_offer_overlay: bool = False,
) -> go.Figure:
    """Build the Plotly figure for wholesale prices and optional BMU Bid/Offer pairs."""
    fig = go.Figure()

    if filtered_wholesale_df is not None and not filtered_wholesale_df.empty:
        if "ID_Forecast £/MWh" in filtered_wholesale_df.columns:
            figTrace(
                fig,
                filtered_wholesale_df["dateTime"],
                filtered_wholesale_df["ID_Forecast £/MWh"],
                "lines",
                "ID Forecast",
                line=dict(width=3),
            )
        if "DA_Nordpool £/MWh" in filtered_wholesale_df.columns:
            figTrace(
                fig,
                filtered_wholesale_df["dateTime"],
                filtered_wholesale_df["DA_Nordpool £/MWh"],
                "lines",
                "DA Forecast",
                line=dict(width=3),
            )

    if (
        show_bid_offer_overlay
        and bmu_bid_offer_df is not None
        and not bmu_bid_offer_df.empty
        and pair_ids
    ):
        for pair_id in pair_ids:
            pair_df = bmu_bid_offer_df[
                bmu_bid_offer_df["BOPAIR_ID"] == pair_id
            ].sort_values("GMT_DATETIME")

            if pair_df.empty:
                continue

            figTrace(
                fig,
                pair_df["GMT_DATETIME"],
                pair_df["BID_PRICE_GBP_MWH"],
                "lines",
                f"Pair {pair_id} BID",
                line=dict(width=3, dash="dot"),
            )

            figTrace(
                fig,
                pair_df["GMT_DATETIME"],
                pair_df["OFFER_PRICE_GBP_MWH"],
                "lines",
                f"Pair {pair_id} OFFER",
                line=dict(width=3, dash="dot"),
            )

    fig.update_layout(
        template=PLOTLY_THEME,
        title=f"{bmu} Wholesale Data",
        xaxis_title="Date/Time",
        yaxis_title="£/MWh",
        height=500,
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    return fig


def render_price_chart(
    filtered_wholesale_df: pd.DataFrame,
    filtered_bid_offer_df: Optional[pd.DataFrame],
    bmus: tuple[str, ...],
    requested_pair_ids: tuple[int, ...],
    show_bid_offer_overlay: bool,
    show_tables: bool,
    graphs_per_row: int = 2,
) -> None:
    """Render wholesale price charts, BMU Bid/Offer overlays, and optional comparison table."""
    if filtered_wholesale_df is None or filtered_wholesale_df.empty:
        render_empty_result("wholesale price data")
        return

    effective_pair_ids: list = []
    if show_bid_offer_overlay and filtered_bid_offer_df is not None:
        available_pairs = get_available_pair_ids(filtered_bid_offer_df)
        st.session_state["available_pair_ids"] = available_pairs
        if requested_pair_ids:
            effective_pair_ids = [p for p in available_pairs if p in requested_pair_ids]
        else:
            effective_pair_ids = available_pairs

    for row_start in range(0, len(bmus), graphs_per_row):
        current_bmus = bmus[row_start : row_start + graphs_per_row]
        cols = (
            [st.container()] if len(current_bmus) == 1 else st.columns(graphs_per_row)
        )

        for col, bmu in zip(cols, current_bmus):
            with col:
                bmu_bod_df: Optional[pd.DataFrame] = None
                if show_bid_offer_overlay and filtered_bid_offer_df is not None:
                    bmu_bod_df = filtered_bid_offer_df[
                        filtered_bid_offer_df["BMU_ID"] == bmu
                    ]

                fig = build_price_figure(
                    bmu=bmu,
                    filtered_wholesale_df=filtered_wholesale_df,
                    bmu_bid_offer_df=bmu_bod_df,
                    pair_ids=effective_pair_ids,
                    show_bid_offer_overlay=show_bid_offer_overlay,
                )
                st.divider()
                st.plotly_chart(fig, width="stretch")

    if show_tables and bmus:
        if show_bid_offer_overlay:
            st.subheader("Wholesale + Bid/Offer Data")
            comparison_df = build_wholesale_comparison_table(
                filtered_wholesale_df=filtered_wholesale_df,
                filtered_bid_offer_df=filtered_bid_offer_df,
                show_bid_offer_overlay=True,
            )
            st.dataframe(comparison_df, width="stretch")
        else:
            st.subheader("Wholesale Data")
            st.dataframe(filtered_wholesale_df.copy(), width="stretch")
