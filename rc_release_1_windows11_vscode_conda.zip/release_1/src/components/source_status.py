"""Status, error, empty-result, and diagnostics session-state helpers."""

from typing import Optional
import streamlit as st

from src.models.dashboard_filters import SourceDiagnostic

DIAGNOSTICS_STATE_KEY = "source_diagnostics"
TIMINGS_STATE_KEY = "execution_timings"


def get_diagnostics_state() -> dict[str, SourceDiagnostic]:
    """Return the dictionary of per-source diagnostics stored in session state."""
    if DIAGNOSTICS_STATE_KEY not in st.session_state:
        st.session_state[DIAGNOSTICS_STATE_KEY] = {}
    return st.session_state[DIAGNOSTICS_STATE_KEY]


def get_timings_state() -> dict[str, float]:
    """Return the dictionary of step timings stored in session state."""
    if TIMINGS_STATE_KEY not in st.session_state:
        st.session_state[TIMINGS_STATE_KEY] = {}
    return st.session_state[TIMINGS_STATE_KEY]


def record_diagnostic(diagnostic: SourceDiagnostic) -> None:
    """Store or update a SourceDiagnostic entry in session state."""
    diagnostics = get_diagnostics_state()
    diagnostics[diagnostic.source_name] = diagnostic


def render_source_status(
    feature_name: str,
    status_message: str = "Not yet implemented",
) -> None:
    """Display a clear implementation status message for unfinished features."""
    st.divider()
    st.subheader(feature_name)
    st.info(f"{feature_name}: {status_message}")


def render_load_error(
    source_label: str,
    error: Exception,
    stop_execution: bool = True,
) -> None:
    """Render an explicit error banner and exception trace when a source fails to load."""
    st.error(f"{source_label} could not be loaded.")
    st.exception(error)
    if stop_execution:
        st.stop()


def render_empty_result(
    source_label: str,
    custom_message: Optional[str] = None,
) -> None:
    """Render an informative message instead of an unexplained empty chart or table."""
    msg = custom_message or (
        f"No {source_label} was found for the submitted BMUs and date range."
    )
    st.info(msg)
