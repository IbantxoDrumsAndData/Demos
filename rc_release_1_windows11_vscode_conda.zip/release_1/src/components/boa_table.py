"""BOA instructions table rendering component."""

from datetime import datetime
import pandas as pd
import streamlit as st

from src.components.source_status import render_empty_result
from src.services.price_comparison_service import filter_boa_instructions_for_bmu


def render_boa_table(
    boa_df: pd.DataFrame,
    bmus: tuple[str, ...],
    start_datetime: datetime,
    end_datetime: datetime,
    graphs_per_row: int = 2,
) -> int:
    """Render per-BMU BOA instruction tables filtered by BMU and submitted date range."""
    if boa_df is None or boa_df.empty:
        render_empty_result("BOA instructions data")
        return 0

    total_rows_rendered = 0

    for row_start in range(0, len(bmus), graphs_per_row):
        current_bmus = bmus[row_start : row_start + graphs_per_row]
        cols = (
            [st.container()] if len(current_bmus) == 1 else st.columns(graphs_per_row)
        )

        for col, bmu in zip(cols, current_bmus):
            with col:
                filtered_boa = filter_boa_instructions_for_bmu(
                    boa_df=boa_df,
                    bmu=bmu,
                    start_datetime=start_datetime,
                    end_datetime=end_datetime,
                )
                total_rows_rendered += len(filtered_boa)

                st.divider()
                st.subheader(f"{bmu} BOA Instructions")
                if filtered_boa.empty:
                    render_empty_result(
                        "BOA instructions",
                        f"No BOA instructions found for BMU '{bmu}' in the submitted date range.",
                    )
                else:
                    st.dataframe(filtered_boa, width="stretch")

    return total_rows_rendered
