"""Operational and Dynamic Parameters chart and table rendering components."""

from datetime import datetime
from typing import Optional
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.components.source_status import render_empty_result
from src.models.dashboard_filters import (
    DEFAULT_OPERATIONAL_SERIES,
    DEFAULT_PN_LOOKBACKS,
)
from src.services.operational_service import (
    build_dynamic_parameters_table,
    filter_operational_by_bmu,
    load_remit_for_bmu,
)
from src.utils.figTrace import figTrace

PLOTLY_THEME = "plotly_white"
PLOTLY_BG_COLOR = "#FFFFFF"

OPERATIONAL_TRACE_SPECS: list[tuple[str, str, dict, Optional[int]]] = [
    ("MEL", "MAXIMUM_EXPORT_LIMIT", {"width": 3, "dash": "dot"}, None),
    ("MIL", "MAXIMUM_IMPORT_LIMIT", {"width": 3}, None),
    ("SEL", "STABLEEXPORTLIMIT", {"width": 3, "dash": "dot"}, None),
    ("FPN", "FINAL_PHYSICAL_NOTIFICATION_MW", {"width": 3}, None),
    (
        "Metered Output",
        "OPERATIONAL_METERED_OUTPUT_MW",
        {"width": 3, "dash": "dot"},
        None,
    ),
    ("4H PN", "PN4HRSAHEADOFEFFECTIVE_MW", {"width": 3}, 4),
    ("6H PN", "PN6HRSAHEADOFEFFECTIVE_MW", {"width": 3}, 6),
    ("8H PN", "PN8HRSAHEADOFEFFECTIVE_MW", {"width": 3}, 8),
    ("12H PN", "PN12HRSAHEADOFEFFECTIVE_MW", {"width": 3}, 12),
    ("18H PN", "PN18HRSAHEADOFEFFECTIVE_MW", {"width": 3}, 18),
]


def build_operational_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    selected_series: tuple[str, ...] = DEFAULT_OPERATIONAL_SERIES,
    pn_lookbacks: tuple[int, ...] = DEFAULT_PN_LOOKBACKS,
    remit_overlays: Optional[list[dict]] = None,
) -> go.Figure:
    """Construct the Plotly figure for a single BMU's operational series and REMIT overlays."""
    fig = go.Figure()

    for trace_name, col_name, line_style, lookback_hr in OPERATIONAL_TRACE_SPECS:
        if trace_name not in selected_series:
            continue
        if lookback_hr is not None and lookback_hr not in pn_lookbacks:
            continue
        if col_name not in bmu_df.columns:
            continue

        figTrace(
            fig,
            bmu_df["GMT_DATETIME"],
            bmu_df[col_name],
            "lines",
            trace_name,
            line=dict(line_style),
        )

    if remit_overlays:
        for overlay in remit_overlays:
            fig.add_shape(
                type="rect",
                x0=overlay["overlay_start"],
                x1=overlay["overlay_end"],
                y0=overlay["available_capacity"],
                y1=overlay["normal_capacity"],
                fillcolor="red",
                opacity=0.3,
                line_width=0,
            )
            fig.add_trace(
                go.Scatter(
                    x=[overlay["overlay_start"], overlay["overlay_end"]],
                    y=[
                        overlay["available_capacity"],
                        overlay["available_capacity"],
                    ],
                    mode="lines",
                    name=overlay["trace_name"],
                    line=dict(color="red", width=2),
                )
            )

    fig.update_layout(
        template=PLOTLY_THEME,
        title=f"{bmu} Operational Data",
        xaxis_title="Date/Time",
        yaxis_title="MW",
        height=500,
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    return fig


def build_dynamic_parameters_figure(
    bmu: str,
    bmu_df: pd.DataFrame,
    start_datetime: datetime,
    end_datetime: datetime,
) -> go.Figure:
    """Construct the Plotly figure for a single BMU's Dynamic Parameters."""
    fig = go.Figure()

    dynamic_traces = [
        ("Average NDZ", "AVERAGENOTICETODEVIATEFROMZERO_MINS"),
        ("Average MZT", "AVERAGEMINIMUMZEROTIME_MINS"),
        ("Average MNZT", "AVERAGEMINIMUMNONZEROTIME_MINS"),
    ]

    for trace_name, col_name in dynamic_traces:
        if col_name in bmu_df.columns:
            figTrace(
                fig,
                bmu_df["GMT_DATETIME"],
                bmu_df[col_name],
                "lines",
                trace_name,
                line=dict(width=3),
            )

    fig.update_layout(
        template=PLOTLY_THEME,
        title=f"{bmu} Dynamic Parameters",
        xaxis_title="Date/Time",
        yaxis_title="Time (Minutes)",
        height=500,
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )

    fig.update_xaxes(range=[start_datetime, end_datetime])
    return fig


def render_operational_chart(
    filtered_operational_df: pd.DataFrame,
    bmus: tuple[str, ...],
    start_datetime: datetime,
    end_datetime: datetime,
    show_remit_overlay: bool,
    show_tables: bool,
    selected_series: tuple[str, ...] = DEFAULT_OPERATIONAL_SERIES,
    pn_lookbacks: tuple[int, ...] = DEFAULT_PN_LOOKBACKS,
    graphs_per_row: int = 2,
    remit_timings: Optional[dict[str, float]] = None,
) -> int:
    """Render operational charts, conditional REMIT overlays, and optional data table."""
    if filtered_operational_df is None or filtered_operational_df.empty:
        render_empty_result("operational data")
        return 0

    total_remit_rows = 0

    for row_start in range(0, len(bmus), graphs_per_row):
        current_bmus = bmus[row_start : row_start + graphs_per_row]
        cols = (
            [st.container()] if len(current_bmus) == 1 else st.columns(graphs_per_row)
        )

        for col, bmu in zip(cols, current_bmus):
            with col:
                bmu_df = filter_operational_by_bmu(filtered_operational_df, bmu)
                if bmu_df.empty:
                    st.divider()
                    render_empty_result(
                        "operational data",
                        f"No operational data was found for BMU '{bmu}' in the selected date range.",
                    )
                    continue

                from time import perf_counter

                remit_started = perf_counter()
                remit_df, remit_overlays, remit_warning = load_remit_for_bmu(
                    bmu_df=bmu_df,
                    start_datetime=start_datetime,
                    end_datetime=end_datetime,
                    show_remit_overlay=show_remit_overlay,
                )
                if remit_timings is not None and show_remit_overlay:
                    remit_timings[f"remit_load_{bmu}"] = perf_counter() - remit_started

                total_remit_rows += len(remit_df)

                fig = build_operational_figure(
                    bmu=bmu,
                    bmu_df=bmu_df,
                    selected_series=selected_series,
                    pn_lookbacks=pn_lookbacks,
                    remit_overlays=remit_overlays if show_remit_overlay else None,
                )

                st.divider()
                st.plotly_chart(fig, width="stretch")

                if remit_warning:
                    st.warning(f"{bmu}: {remit_warning}")

                if show_remit_overlay and remit_df is not None and not remit_df.empty:
                    st.dataframe(remit_df, width="stretch")

    if show_tables:
        selected_bmus_df = filtered_operational_df[
            filtered_operational_df["BMU_ID"].isin(bmus)
        ].sort_values("GMT_DATETIME")
        st.subheader("BMU(s) Operational Data")
        st.dataframe(selected_bmus_df, width="stretch")

    return total_remit_rows


def render_dynamic_parameters_chart(
    filtered_operational_df: pd.DataFrame,
    bmus: tuple[str, ...],
    start_datetime: datetime,
    end_datetime: datetime,
    show_tables: bool,
    graphs_per_row: int = 2,
) -> None:
    """Render Dynamic Parameters charts and optional table for selected BMUs."""
    if filtered_operational_df is None or filtered_operational_df.empty:
        render_empty_result("dynamic parameters data")
        return

    for row_start in range(0, len(bmus), graphs_per_row):
        current_bmus = bmus[row_start : row_start + graphs_per_row]
        cols = (
            [st.container()] if len(current_bmus) == 1 else st.columns(graphs_per_row)
        )

        for col, bmu in zip(cols, current_bmus):
            with col:
                bmu_df = filter_operational_by_bmu(filtered_operational_df, bmu)
                if bmu_df.empty:
                    st.divider()
                    render_empty_result(
                        "dynamic parameters data",
                        f"No dynamic parameter data was found for BMU '{bmu}' in the selected date range.",
                    )
                    continue

                fig = build_dynamic_parameters_figure(
                    bmu=bmu,
                    bmu_df=bmu_df,
                    start_datetime=start_datetime,
                    end_datetime=end_datetime,
                )
                st.divider()
                st.plotly_chart(fig, width="stretch")

    if show_tables:
        dynamic_df = build_dynamic_parameters_table(filtered_operational_df, bmus)
        if not dynamic_df.empty:
            st.subheader("Dynamic Parameters Data")
            st.dataframe(dynamic_df, width="stretch")
