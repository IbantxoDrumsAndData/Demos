"""Streamlit UI components for filters, charts, tables, and status messages."""

from src.components.boa_table import render_boa_table
from src.components.filter_panel import get_submitted_filters, render_filter_panel
from src.components.operational_chart import (
    build_dynamic_parameters_figure,
    build_operational_figure,
    render_dynamic_parameters_chart,
    render_operational_chart,
)
from src.components.price_chart import build_price_figure, render_price_chart
from src.components.source_status import (
    get_diagnostics_state,
    get_timings_state,
    record_diagnostic,
    render_empty_result,
    render_load_error,
    render_source_status,
)

__all__ = [
    "build_dynamic_parameters_figure",
    "build_operational_figure",
    "build_price_figure",
    "get_diagnostics_state",
    "get_submitted_filters",
    "get_timings_state",
    "record_diagnostic",
    "render_boa_table",
    "render_dynamic_parameters_chart",
    "render_empty_result",
    "render_filter_panel",
    "render_load_error",
    "render_operational_chart",
    "render_price_chart",
    "render_source_status",
]
