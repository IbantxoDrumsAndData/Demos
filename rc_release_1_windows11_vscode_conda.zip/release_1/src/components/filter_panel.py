"""Two-stage controlled sidebar filter panel component."""

from datetime import datetime
from typing import Optional
import pandas as pd
import streamlit as st

from src.components.source_status import (
    get_timings_state,
    record_diagnostic,
    render_load_error,
)
from src.models.dashboard_filters import (
    ALL_VIEWS,
    DEFAULT_OPERATIONAL_SERIES,
    DEFAULT_PN_LOOKBACKS,
    DashboardFilters,
)
from src.repositories.operational_repository import RepositoryError
from src.repositories.stakeholder_repository import get_stakeholder_metadata
from src.services.filter_service import (
    get_bmus_for_stage1,
    get_portfolios_for_fuel_types,
    validate_dashboard_filters,
)
from src.utils.dates import getDate
from src.utils.timing import build_source_diagnostic, timed_step

SUBMITTED_FILTERS_KEY = "submitted_filters"
STAGE1_FUEL_TYPES_KEY = "stage1_fuel_types"
STAGE1_PORTFOLIOS_KEY = "stage1_portfolios"
AVAILABLE_BMUS_KEY = "available_bmus"
AVAILABLE_PAIR_IDS_KEY = "available_pair_ids"


def get_submitted_filters() -> Optional[DashboardFilters]:
    """Return the last validated and submitted DashboardFilters from session state."""
    return st.session_state.get(SUBMITTED_FILTERS_KEY)


def _load_lightweight_metadata() -> tuple[pd.DataFrame, list[str], list[str]]:
    """Load stakeholder metadata with timing and diagnostics instrumentation."""
    timings = get_timings_state()
    try:
        with timed_step("stakeholder_metadata_load", timings):
            stakeholders_df, fuel_types, lead_parties = get_stakeholder_metadata()
        record_diagnostic(
            build_source_diagnostic(
                source_name="Stakeholder Metadata",
                loaded=True,
                df=stakeholders_df,
                load_duration_s=timings.get("stakeholder_metadata_load", 0.0),
                required_columns=("sheetName", "Lead Party", "BMU ID"),
            )
        )
        return stakeholders_df, fuel_types, lead_parties
    except RepositoryError as exc:
        record_diagnostic(
            build_source_diagnostic(
                source_name="Stakeholder Metadata",
                loaded=False,
                load_duration_s=timings.get("stakeholder_metadata_load", 0.0),
                message=str(exc),
            )
        )
        render_load_error("Stakeholder metadata", exc, stop_execution=False)
        return pd.DataFrame(columns=["sheetName", "Lead Party", "BMU ID"]), [], []


def render_filter_panel(
    default_views: Optional[tuple[str, ...]] = None,
) -> Optional[DashboardFilters]:
    """Render the two-stage filter sidebar and return the active submitted filters."""
    stakeholders_df, fuel_types, _ = _load_lightweight_metadata()

    if STAGE1_FUEL_TYPES_KEY not in st.session_state:
        st.session_state[STAGE1_FUEL_TYPES_KEY] = ()
    if STAGE1_PORTFOLIOS_KEY not in st.session_state:
        st.session_state[STAGE1_PORTFOLIOS_KEY] = ()
    if AVAILABLE_BMUS_KEY not in st.session_state:
        st.session_state[AVAILABLE_BMUS_KEY] = get_bmus_for_stage1(
            stakeholders_df,
            st.session_state[STAGE1_FUEL_TYPES_KEY],
            st.session_state[STAGE1_PORTFOLIOS_KEY],
        )

    with st.sidebar:
        st.header("Stage 1: Define BMU Scope")
        st.caption(
            "Filter BMUs using lightweight stakeholder metadata before configuring the dashboard."
        )

        with st.form("stage1_bmu_scope_form"):
            draft_fuel_types = st.multiselect(
                "Select Fuel Type",
                options=fuel_types,
                default=[
                    ft
                    for ft in st.session_state[STAGE1_FUEL_TYPES_KEY]
                    if ft in fuel_types
                ],
            )

            portfolio_options = get_portfolios_for_fuel_types(
                stakeholders_df,
                tuple(draft_fuel_types),
            )

            draft_portfolios = st.multiselect(
                "Select Portfolio",
                options=portfolio_options,
                default=[
                    p
                    for p in st.session_state[STAGE1_PORTFOLIOS_KEY]
                    if p in portfolio_options
                ],
            )

            stage1_submitted = st.form_submit_button(
                "Update BMU list",
                width="stretch",
            )

        if stage1_submitted:
            timings = get_timings_state()
            with timed_step("stage1_bmu_scope_update", timings):
                st.session_state[STAGE1_FUEL_TYPES_KEY] = tuple(draft_fuel_types)
                valid_portfolios = get_portfolios_for_fuel_types(
                    stakeholders_df,
                    tuple(draft_fuel_types),
                )
                filtered_portfolios = tuple(
                    p for p in draft_portfolios if p in valid_portfolios
                )
                st.session_state[STAGE1_PORTFOLIOS_KEY] = filtered_portfolios
                st.session_state[AVAILABLE_BMUS_KEY] = get_bmus_for_stage1(
                    stakeholders_df,
                    st.session_state[STAGE1_FUEL_TYPES_KEY],
                    st.session_state[STAGE1_PORTFOLIOS_KEY],
                )

        available_bmus: list[str] = st.session_state.get(AVAILABLE_BMUS_KEY, [])
        st.caption(f"Available BMUs in scope: {len(available_bmus)}")

        st.divider()
        st.header("Stage 2: Configure & Run")

        prev_submitted: Optional[DashboardFilters] = get_submitted_filters()
        default_min_dt: datetime = st.session_state.get(
            "data_min_datetime", getDate(days=10, string=False)
        )
        default_max_dt: datetime = st.session_state.get(
            "data_max_datetime", getDate(days=0, string=False)
        )
        if default_min_dt >= default_max_dt:
            default_min_dt = getDate(days=10, string=False)
            default_max_dt = datetime.now().replace(
                hour=23, minute=30, second=0, microsecond=0
            )

        initial_start = (
            prev_submitted.start_datetime
            if prev_submitted
            and default_min_dt <= prev_submitted.start_datetime <= default_max_dt
            else default_min_dt
        )
        initial_end = (
            prev_submitted.end_datetime
            if prev_submitted
            and default_min_dt <= prev_submitted.end_datetime <= default_max_dt
            else default_max_dt
        )

        initial_views = (
            list(prev_submitted.views)
            if prev_submitted
            else list(default_views or ("Operational Data",))
        )

        with st.form("stage2_load_dashboard_form"):
            draft_bmus = st.multiselect(
                "Select BMU",
                options=available_bmus,
                default=(
                    [b for b in prev_submitted.bmus if b in available_bmus]
                    if prev_submitted
                    else []
                ),
            )

            draft_date_range = st.slider(
                "Date Range",
                min_value=default_min_dt,
                max_value=default_max_dt,
                value=(initial_start, initial_end),
                format="DD/MM/YYYY",
            )

            st.subheader("Graphs/Tables")
            draft_views = st.pills(
                "Select dashboard views",
                options=list(ALL_VIEWS),
                default=[v for v in initial_views if v in ALL_VIEWS],
                selection_mode="multi",
                label_visibility="collapsed",
            )

            draft_operational_series = st.multiselect(
                "Operational Series",
                options=list(DEFAULT_OPERATIONAL_SERIES),
                default=(
                    list(prev_submitted.operational_series)
                    if prev_submitted
                    else list(DEFAULT_OPERATIONAL_SERIES)
                ),
            )

            draft_pn_lookbacks = st.multiselect(
                "PN Lookback Periods (Hours)",
                options=list(DEFAULT_PN_LOOKBACKS),
                default=(
                    list(prev_submitted.pn_lookbacks)
                    if prev_submitted
                    else list(DEFAULT_PN_LOOKBACKS)
                ),
            )

            st.subheader("Information Overlays")
            draft_remit = st.toggle(
                "REMIT Information",
                value=(
                    "REMIT Information" in prev_submitted.overlays
                    if prev_submitted
                    else False
                ),
            )
            draft_bid_offer = st.toggle(
                "Bid / Offer Data",
                value=(
                    "Bid / Offer Data" in prev_submitted.overlays
                    if prev_submitted
                    else False
                ),
            )

            known_pair_ids = st.session_state.get(
                AVAILABLE_PAIR_IDS_KEY, [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]
            )
            draft_pair_ids = st.multiselect(
                "BO Pair IDs (empty = all available)",
                options=known_pair_ids,
                default=(
                    [p for p in prev_submitted.pair_ids if p in known_pair_ids]
                    if prev_submitted
                    else []
                ),
            )

            draft_show_tables = st.toggle(
                "Data Tables",
                value=prev_submitted.show_tables if prev_submitted else False,
            )

            stage2_submitted = st.form_submit_button(
                "Load dashboard",
                type="primary",
                width="stretch",
            )

        if stage2_submitted:
            overlays: list[str] = []
            if draft_remit:
                overlays.append("REMIT Information")
            if draft_bid_offer:
                overlays.append("Bid / Offer Data")

            candidate = DashboardFilters(
                start_datetime=draft_date_range[0],
                end_datetime=draft_date_range[1],
                fuel_types=st.session_state[STAGE1_FUEL_TYPES_KEY],
                portfolios=st.session_state[STAGE1_PORTFOLIOS_KEY],
                bmus=tuple(draft_bmus),
                views=tuple(draft_views or ()),
                overlays=tuple(overlays),
                pair_ids=tuple(int(p) for p in draft_pair_ids),
                pn_lookbacks=tuple(int(lb) for lb in draft_pn_lookbacks),
                show_tables=bool(draft_show_tables),
                operational_series=tuple(draft_operational_series),
            )

            is_valid, validation_errors = validate_dashboard_filters(candidate)
            if not is_valid:
                for err in validation_errors:
                    st.error(err)
            else:
                st.session_state[SUBMITTED_FILTERS_KEY] = candidate

        st.divider()
        st.caption(
            "Historical Blob time-frame selector & Graph Builder: Not yet implemented."
        )

    return get_submitted_filters()
