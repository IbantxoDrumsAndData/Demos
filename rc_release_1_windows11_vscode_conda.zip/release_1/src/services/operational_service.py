"""Service functions for preparing and filtering operational, dynamic parameter, and REMIT data."""

from datetime import datetime
from typing import Callable, Optional
import pandas as pd
import streamlit as st

from src.repositories.operational_repository import RepositoryError
from src.repositories.remit_repository import get_remit_data


@st.cache_data(ttl=3600, show_spinner=False)
def prepare_operational_data(
    operational_df: pd.DataFrame,
    bmu_mapping_df: Optional[pd.DataFrame],
) -> pd.DataFrame:
    """Convert operational timestamps and left-join Elexon BMU mapping."""
    if operational_df is None or operational_df.empty:
        df = (
            operational_df.copy()
            if operational_df is not None
            else pd.DataFrame(columns=["GMT_DATETIME", "BMU_ID", "ELEXON_BMU_ID"])
        )
        if "ELEXON_BMU_ID" not in df.columns:
            df["ELEXON_BMU_ID"] = pd.NA
        return df

    df = operational_df.copy()
    df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])

    if (
        bmu_mapping_df is not None
        and not bmu_mapping_df.empty
        and {"BMU_ID", "ELEXON_BMU_ID"}.issubset(bmu_mapping_df.columns)
    ):
        df = df.merge(bmu_mapping_df, on="BMU_ID", how="left")
    elif "ELEXON_BMU_ID" not in df.columns:
        df["ELEXON_BMU_ID"] = pd.NA

    return df


@st.cache_data(ttl=3600, show_spinner=False)
def filter_operational_data(
    prepared_operational_df: pd.DataFrame,
    start_datetime: datetime,
    end_datetime: datetime,
    bmus: tuple[str, ...],
) -> pd.DataFrame:
    """Filter prepared operational data by date boundaries and selected BMUs."""
    if prepared_operational_df is None or prepared_operational_df.empty:
        return (
            prepared_operational_df.copy()
            if prepared_operational_df is not None
            else pd.DataFrame()
        )

    mask = (prepared_operational_df["GMT_DATETIME"] >= start_datetime) & (
        prepared_operational_df["GMT_DATETIME"] <= end_datetime
    )
    if bmus:
        mask = mask & prepared_operational_df["BMU_ID"].isin(bmus)

    return prepared_operational_df.loc[mask].sort_values("GMT_DATETIME")


def filter_operational_by_bmu(
    filtered_operational_df: pd.DataFrame,
    bmu: str,
) -> pd.DataFrame:
    """Return operational rows for a single BMU sorted ascending by GMT_DATETIME."""
    if filtered_operational_df is None or filtered_operational_df.empty:
        return pd.DataFrame()
    return filtered_operational_df[
        filtered_operational_df["BMU_ID"] == bmu
    ].sort_values("GMT_DATETIME")


def build_dynamic_parameters_table(
    filtered_operational_df: pd.DataFrame,
    bmus: tuple[str, ...],
) -> pd.DataFrame:
    """Build the concatenated Dynamic Parameters table across selected BMUs."""
    dynamic_cols = [
        "GMT_DATETIME",
        "BMU_ID",
        "AVERAGENOTICETODEVIATEFROMZERO_MINS",
        "AVERAGEMINIMUMZEROTIME_MINS",
        "AVERAGEMINIMUMNONZEROTIME_MINS",
    ]
    if filtered_operational_df is None or filtered_operational_df.empty or not bmus:
        return pd.DataFrame(columns=dynamic_cols)

    frames: list[pd.DataFrame] = []
    for bmu in bmus:
        bmu_df = filter_operational_by_bmu(filtered_operational_df, bmu)
        available_cols = [c for c in dynamic_cols if c in bmu_df.columns]
        frames.append(bmu_df[available_cols])

    if not frames:
        return pd.DataFrame(columns=dynamic_cols)

    return pd.concat(frames, ignore_index=True)


def prepare_remit_events(
    remit_df: Optional[pd.DataFrame],
    start_datetime: datetime,
    end_datetime: datetime,
) -> tuple[pd.DataFrame, list[dict]]:
    """Normalize REMIT timestamps to tz-naive and compute active chart overlay shapes."""
    if remit_df is None or remit_df.empty:
        return pd.DataFrame(), []

    df = remit_df.copy()
    df["eventStartTime"] = pd.to_datetime(df["eventStartTime"]).dt.tz_localize(None)
    df["eventEndTime"] = pd.to_datetime(df["eventEndTime"]).dt.tz_localize(None)

    overlays: list[dict] = []
    for _, remit in df.iterrows():
        if (
            remit["eventEndTime"] < start_datetime
            or remit["eventStartTime"] > end_datetime
        ):
            continue

        overlay_start = max(remit["eventStartTime"], start_datetime)
        overlay_end = min(remit["eventEndTime"], end_datetime)
        normal_capacity = remit["normalCapacity"]
        unavailable_capacity = remit["unavailableCapacity"]
        available_capacity = normal_capacity - unavailable_capacity

        overlays.append(
            {
                "overlay_start": overlay_start,
                "overlay_end": overlay_end,
                "normal_capacity": normal_capacity,
                "unavailable_capacity": unavailable_capacity,
                "available_capacity": available_capacity,
                "trace_name": (
                    f"REMIT | "
                    f"{unavailable_capacity} MW | "
                    f"{remit['eventStartTime'].strftime('%d %b')} → "
                    f"{remit['eventEndTime'].strftime('%d %b')}"
                ),
            }
        )

    return df, overlays


def load_remit_for_bmu(
    bmu_df: pd.DataFrame,
    start_datetime: datetime,
    end_datetime: datetime,
    show_remit_overlay: bool,
    remit_fetcher: Callable[..., pd.DataFrame] = get_remit_data,
) -> tuple[pd.DataFrame, list[dict], Optional[str]]:
    """Conditionally fetch and prepare REMIT data with guardrails for missing mappings or errors."""
    if not show_remit_overlay:
        return pd.DataFrame(), [], None

    if bmu_df is None or bmu_df.empty:
        return pd.DataFrame(), [], None

    if "ELEXON_BMU_ID" not in bmu_df.columns:
        return (
            pd.DataFrame(),
            [],
            "REMIT skipped: Elexon BMU mapping column is missing.",
        )

    elexon_bmu_id = bmu_df["ELEXON_BMU_ID"].iloc[0]
    if pd.isna(elexon_bmu_id) or not str(elexon_bmu_id).strip():
        return (
            pd.DataFrame(),
            [],
            "REMIT skipped: Selected BMU has no Elexon BMU mapping.",
        )

    try:
        raw_remit_df = remit_fetcher(str(elexon_bmu_id), start_datetime, end_datetime)
        prepared_df, overlays = prepare_remit_events(
            raw_remit_df, start_datetime, end_datetime
        )
        return prepared_df, overlays, None
    except (RepositoryError, Exception) as exc:
        return pd.DataFrame(), [], f"REMIT data could not be loaded: {exc}"
