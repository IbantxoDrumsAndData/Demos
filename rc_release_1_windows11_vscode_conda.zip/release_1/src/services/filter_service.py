"""Service functions for Stage 1 BMU scoping, filter validation, and source resolution."""

from typing import Optional
import pandas as pd

from src.models.dashboard_filters import DashboardFilters, UNFINISHED_VIEWS


def get_portfolios_for_fuel_types(
    stakeholders_df: pd.DataFrame,
    fuel_types: tuple[str, ...],
) -> list[str]:
    """Return sorted Lead Party portfolio names for the selected fuel types."""
    if stakeholders_df is None or stakeholders_df.empty:
        return []

    filtered = stakeholders_df
    if fuel_types and "sheetName" in filtered.columns:
        filtered = filtered[filtered["sheetName"].isin(fuel_types)]

    if "Lead Party" not in filtered.columns:
        return []

    return sorted(filtered["Lead Party"].dropna().astype(str).unique().tolist())


def get_bmus_for_stage1(
    stakeholders_df: pd.DataFrame,
    fuel_types: tuple[str, ...],
    portfolios: tuple[str, ...],
    fallback_bmus: Optional[tuple[str, ...]] = None,
) -> list[str]:
    """Return sorted BMU IDs scoped by Stage 1 fuel types and portfolios."""
    if stakeholders_df is None or stakeholders_df.empty:
        return sorted(set(fallback_bmus)) if fallback_bmus else []

    filtered = stakeholders_df
    if fuel_types and "sheetName" in filtered.columns:
        filtered = filtered[filtered["sheetName"].isin(fuel_types)]

    if portfolios and "Lead Party" in filtered.columns:
        filtered = filtered[filtered["Lead Party"].isin(portfolios)]

    if not fuel_types and not portfolios and fallback_bmus is not None:
        return sorted(set(fallback_bmus))

    if "BMU ID" not in filtered.columns:
        return sorted(set(fallback_bmus)) if fallback_bmus else []

    return sorted(filtered["BMU ID"].dropna().astype(str).unique().tolist())


def validate_dashboard_filters(
    filters: DashboardFilters,
) -> tuple[bool, list[str]]:
    """Validate submitted DashboardFilters before loading data sources."""
    errors: list[str] = []

    if filters.start_datetime > filters.end_datetime:
        errors.append("Start date/time must be earlier than or equal to end date/time.")

    if not filters.views:
        errors.append("Select at least one dashboard view before loading.")

    implemented_selected = [v for v in filters.views if v not in UNFINISHED_VIEWS]
    if implemented_selected and not filters.bmus:
        errors.append("Select at least one BMU for the requested view(s).")

    return len(errors) == 0, errors


def derive_required_sources(
    filters: DashboardFilters,
    active_page: Optional[str] = None,
) -> set[str]:
    """Determine which data sources must be loaded for the submitted filters and page."""
    required: set[str] = set()
    views = set(filters.views)
    overlays = set(filters.overlays)
    has_bmus = len(filters.bmus) > 0

    allow_operational = active_page in (None, "operational_monitoring")
    allow_market = active_page in (None, "market_prices")
    allow_balancing = active_page in (None, "balancing_actions")

    if (
        allow_operational
        and has_bmus
        and bool(views & {"Operational Data", "Dynamic Parameters"})
    ):
        required.add("operational_data")
        required.add("bmu_mapping")
        if "Operational Data" in views and "REMIT Information" in overlays:
            required.add("remit")

    if allow_market and has_bmus and "Wholesale Prices" in views:
        required.add("wholesale_prices")
        if "Bid / Offer Data" in overlays:
            required.add("bid_offer_data")

    if allow_balancing and has_bmus and "BOA Instructions" in views:
        required.add("boa_instructions")

    return required
