# =============================
#          IMPORTS
# =============================
from datetime import datetime
from dateutil.relativedelta import relativedelta


# =============================
#   DATETIME HELPER FUNCTION
# =============================
# Gets specified date at MIDNIGHT in the format: YEAR-MONTH-DAY-HOUR-MINUTE
def getDate(days=0, months=0, years=0, string=False):
    dt = datetime.now().replace(
        hour=0, minute=0, second=0, microsecond=0
    ) - relativedelta(days=days, months=months, years=years)

    # Format for API calls
    if string:
        return dt.strftime("%Y%m%d%H%M")

    # Stromg format for Streamlit slider
    return dt
