"""Azure Key Vault secret retrieval helper."""

from typing import Optional
from azure.keyvault.secrets import SecretClient

import src.utils.globals as g

_secret_client: Optional[SecretClient] = None


def get_secret(secret_name: str) -> str:
    """Retrieve a secret value from Azure Key Vault lazily."""
    global _secret_client
    if _secret_client is None:
        _secret_client = SecretClient(
            vault_url=g.vault_url,
            credential=g.credential,
        )
    return _secret_client.get_secret(secret_name).value
