import plotly.graph_objects as go


def figTrace(fig, x, y, mode, name, line):
    fig.add_trace(go.Scatter(x=x, y=y, mode=mode, name=name, line=line))

    return fig
