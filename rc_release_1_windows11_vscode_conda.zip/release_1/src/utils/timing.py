"""Performance timing utilities and diagnostics helpers."""

from contextlib import contextmanager
from datetime import datetime, timezone
from time import perf_counter
from typing import Iterator, Optional
import pandas as pd

from src.models.dashboard_filters import SourceDiagnostic


@contextmanager
def timed_step(name: str, timings: dict[str, float]) -> Iterator[None]:
    """Measure elapsed wall-clock seconds for a named execution step."""
    started = perf_counter()
    try:
        yield
    finally:
        timings[name] = perf_counter() - started


def build_source_diagnostic(
    source_name: str,
    loaded: bool,
    df: Optional[pd.DataFrame] = None,
    filtered_df: Optional[pd.DataFrame] = None,
    timestamp_col: Optional[str] = None,
    load_duration_s: float = 0.0,
    prep_duration_s: float = 0.0,
    render_duration_s: float = 0.0,
    required_columns: Optional[tuple[str, ...]] = None,
    message: Optional[str] = None,
) -> SourceDiagnostic:
    """Construct a SourceDiagnostic summary from raw and filtered DataFrames."""
    if not loaded:
        return SourceDiagnostic(
            source_name=source_name,
            loaded=False,
            message=message or "Skipped (not required by submitted filters).",
        )

    now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    if df is None:
        return SourceDiagnostic(
            source_name=source_name,
            loaded=False,
            load_duration_s=load_duration_s,
            prep_duration_s=prep_duration_s,
            render_duration_s=render_duration_s,
            freshness_timestamp=now_utc,
            message=message or f"{source_name} returned None / failed to load.",
        )

    missing_cols: list[str] = []
    if required_columns:
        missing_cols = [col for col in required_columns if col not in df.columns]

    row_count = len(df)
    target_df = filtered_df if filtered_df is not None else df
    selected_bmu_row_count = len(target_df)

    min_ts: Optional[str] = None
    max_ts: Optional[str] = None
    if (
        timestamp_col
        and timestamp_col in target_df.columns
        and not target_df.empty
        and target_df[timestamp_col].notna().any()
    ):
        ts_series = pd.to_datetime(target_df[timestamp_col], errors="coerce").dropna()
        if not ts_series.empty:
            min_ts = str(ts_series.min())
            max_ts = str(ts_series.max())

    status_messages: list[str] = []
    if missing_cols:
        status_messages.append(f"Missing columns: {', '.join(missing_cols)}")
    if row_count == 0:
        status_messages.append("Source dataset is empty.")
    elif selected_bmu_row_count == 0:
        status_messages.append("No rows matched submitted BMUs and date range.")
    if message:
        status_messages.append(message)
    if not status_messages:
        status_messages.append("OK")

    return SourceDiagnostic(
        source_name=source_name,
        loaded=True,
        load_duration_s=load_duration_s,
        prep_duration_s=prep_duration_s,
        render_duration_s=render_duration_s,
        row_count=row_count,
        selected_bmu_row_count=selected_bmu_row_count,
        min_timestamp=min_ts,
        max_timestamp=max_ts,
        freshness_timestamp=now_utc,
        message="; ".join(status_messages),
    )
