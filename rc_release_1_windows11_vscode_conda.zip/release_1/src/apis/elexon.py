import streamlit as st
import requests
import pandas as pd


@st.cache_data(ttl=3600, show_spinner="Loading BMU Mapping Data . . . ")
def getBMUMapping():

    BASE_URL = "https://data.elexon.co.uk/bmrs/api/v1/reference/bmunits/all"

    try:
        response = requests.get(BASE_URL, timeout=30)

        response.raise_for_status()

        data = response.json()

    except requests.exceptions.RequestException as e:
        st.error(f"[ERROR] REQUEST FAILED: {e}")
        return None

    except ValueError as e:
        st.error(f"[ERROR] DATA ISSUE: {e}")
        return None

    df = pd.DataFrame(data)

    df = df[["nationalGridBmUnit", "elexonBmUnit"]]

    df = df.rename(
        columns={"nationalGridBmUnit": "BMU_ID", "elexonBmUnit": "ELEXON_BMU_ID"}
    )

    return df


@st.cache_data(ttl=3600, show_spinner="Loading REMIT Information . . . ")
def getRemit(bmu, startDate, endDate):

    BASE_URL = "https://data.elexon.co.uk/bmrs/api/v1/remit/list/by-event/stream"

    params = {
        "from": startDate,
        "to": endDate,
        "latestRevisionOnly": "true",
        "profileOnly": "false",
        "assetId": bmu,
    }

    try:
        response = requests.get(BASE_URL, params=params, timeout=30)

        response.raise_for_status()

        data = response.json()

    except requests.exceptions.RequestException as e:
        st.error(f"[ERROR] REQUEST FAILED: {e}")
        return pd.DataFrame()

    except ValueError as e:
        st.error(f"[ERROR] DATA ISSUE: {e}")
        return pd.DataFrame()

    listDF = pd.DataFrame(data)

    if listDF.empty:
        return pd.DataFrame()

    if "id" not in listDF.columns:
        return pd.DataFrame()

    remitDetails = []

    for remitID in listDF["id"]:

        remitURL = f"https://data.elexon.co.uk/bmrs/api/v1/remit/{remitID}"

        try:

            response = requests.get(remitURL, timeout=30)

            response.raise_for_status()

            remitDetail = response.json()

            if (
                "data" in remitDetail
                and isinstance(remitDetail["data"], list)
                and len(remitDetail["data"]) > 0
            ):
                remitDetails.append(pd.DataFrame(remitDetail["data"]))

        except requests.exceptions.RequestException:
            continue

    if remitDetails:

        df = pd.concat(remitDetails, ignore_index=True)

        return df

    return pd.DataFrame()
