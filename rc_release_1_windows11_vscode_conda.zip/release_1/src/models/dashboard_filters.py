"""Immutable filter and diagnostics models for dashboard execution."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

BASE_OPERATIONAL_SERIES: tuple[str, ...] = (
    "MEL",
    "MIL",
    "SEL",
    "FPN",
    "Metered Output",
)

DEFAULT_PN_LOOKBACKS: tuple[int, ...] = (4, 6, 8, 12, 18)

DEFAULT_OPERATIONAL_SERIES: tuple[str, ...] = (
    "MEL",
    "MIL",
    "SEL",
    "FPN",
    "Metered Output",
    "4H PN",
    "6H PN",
    "8H PN",
    "12H PN",
    "18H PN",
)

IMPLEMENTED_VIEWS: tuple[str, ...] = (
    "Operational Data",
    "Wholesale Prices",
    "Dynamic Parameters",
    "BOA Instructions",
)

UNFINISHED_VIEWS: tuple[str, ...] = (
    "Ancillary Services",
    "Strike Prices",
    "Wind ROC Mappings",
)

ALL_VIEWS: tuple[str, ...] = (
    "Operational Data",
    "Wholesale Prices",
    "Ancillary Services",
    "Dynamic Parameters",
    "BOA Instructions",
    "Strike Prices",
    "Wind ROC Mappings",
)


@dataclass(frozen=True)
class DashboardFilters:
    """Immutable representation of a submitted dashboard request."""

    start_datetime: datetime
    end_datetime: datetime
    fuel_types: tuple[str, ...] = ()
    portfolios: tuple[str, ...] = ()
    bmus: tuple[str, ...] = ()
    views: tuple[str, ...] = ()
    overlays: tuple[str, ...] = ()
    pair_ids: tuple[int, ...] = ()
    pn_lookbacks: tuple[int, ...] = DEFAULT_PN_LOOKBACKS
    show_tables: bool = False
    operational_series: tuple[str, ...] = DEFAULT_OPERATIONAL_SERIES


@dataclass
class SourceDiagnostic:
    """Diagnostic metadata captured for a single data source."""

    source_name: str
    loaded: bool = False
    load_duration_s: float = 0.0
    prep_duration_s: float = 0.0
    render_duration_s: float = 0.0
    row_count: int = 0
    selected_bmu_row_count: int = 0
    min_timestamp: Optional[str] = None
    max_timestamp: Optional[str] = None
    freshness_timestamp: Optional[str] = None
    message: str = "Not loaded in last submitted execution."
    extra_metadata: dict[str, str] = field(default_factory=dict)
