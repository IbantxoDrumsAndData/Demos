"""Repository for NED Bid/Offer Parquet data."""

from io import BytesIO
import pandas as pd
import streamlit as st
from azure.storage.blob import BlobServiceClient

from src.repositories.operational_repository import RepositoryError
import src.utils.globals as g


@st.cache_data(ttl=3600, show_spinner="Loading Bid/Offer data...")
def get_bid_offer_data(
    blob_name: str = "NED/BID_OFFERS/latest_bid_offer_data.parquet",
) -> pd.DataFrame:
    """Download BMU Bid/Offer data from Azure Blob Parquet storage."""
    try:
        blob_service_client = BlobServiceClient(
            account_url=g.storage_account_url,
            credential=g.credential,
        )
        blob_client = blob_service_client.get_blob_client(
            container=g.container_name,
            blob=blob_name,
        )
        parquet_bytes = blob_client.download_blob().readall()
        return pd.read_parquet(BytesIO(parquet_bytes))
    except Exception as exc:
        raise RepositoryError(
            f"Bid/Offer data could not be loaded from '{blob_name}': {exc}"
        ) from exc
