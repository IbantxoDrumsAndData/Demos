"""Repository for NED operational Parquet data and Elexon BMU mapping."""

from io import BytesIO
from typing import Optional
import pandas as pd
import requests
import streamlit as st
from azure.storage.blob import BlobServiceClient

import src.utils.globals as g


class RepositoryError(RuntimeError):
    """Raised when a repository fails to retrieve or parse external data."""


@st.cache_data(ttl=3600, show_spinner="Loading operational price data...")
def get_operational_data(
    blob_name: str = "NED/BMU/latest_bmu_data.parquet",
    columns: Optional[tuple[str, ...]] = None,
) -> pd.DataFrame:
    """Download operational BMU data from Azure Blob Parquet storage."""
    try:
        blob_service_client = BlobServiceClient(
            account_url=g.storage_account_url,
            credential=g.credential,
        )
        blob_client = blob_service_client.get_blob_client(
            container=g.container_name,
            blob=blob_name,
        )
        parquet_bytes = blob_client.download_blob().readall()
        col_list = list(columns) if columns else None
        return pd.read_parquet(BytesIO(parquet_bytes), columns=col_list)
    except Exception as exc:
        raise RepositoryError(
            f"Operational data could not be loaded from '{blob_name}': {exc}"
        ) from exc


@st.cache_data(ttl=3600, show_spinner="Loading BMU Mapping Data . . . ")
def get_bmu_mapping() -> pd.DataFrame:
    """Fetch nationalGridBmUnit to elexonBmUnit mapping from Elexon BMRS API."""
    base_url = "https://data.elexon.co.uk/bmrs/api/v1/reference/bmunits/all"
    try:
        response = requests.get(base_url, timeout=30)
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as exc:
        raise RepositoryError(f"Elexon BMU mapping request failed: {exc}") from exc
    except ValueError as exc:
        raise RepositoryError(f"Elexon BMU mapping JSON decode failed: {exc}") from exc

    df = pd.DataFrame(data)
    if df.empty or not {"nationalGridBmUnit", "elexonBmUnit"}.issubset(df.columns):
        raise RepositoryError(
            "Elexon BMU mapping response is missing required columns "
            "('nationalGridBmUnit', 'elexonBmUnit')."
        )

    df = df[["nationalGridBmUnit", "elexonBmUnit"]].rename(
        columns={"nationalGridBmUnit": "BMU_ID", "elexonBmUnit": "ELEXON_BMU_ID"}
    )
    return df
