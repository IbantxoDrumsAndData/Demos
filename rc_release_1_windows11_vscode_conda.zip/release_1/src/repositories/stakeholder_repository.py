"""Repository for lightweight stakeholder metadata and available blob time frames."""

from io import BytesIO
import pandas as pd
import streamlit as st
from azure.storage.blob import BlobServiceClient

from src.repositories.operational_repository import RepositoryError
import src.utils.globals as g


@st.cache_data(ttl=3600, show_spinner="Loading stakeholder data...")
def get_stakeholder_metadata(
    blob_name: str = "NED/bm_stakeholders.parquet",
) -> tuple[pd.DataFrame, list[str], list[str]]:
    """Load stakeholder mapping DataFrame, sorted fuel types, and sorted lead parties."""
    try:
        blob_service_client = BlobServiceClient(
            account_url=g.storage_account_url,
            credential=g.credential,
        )
        blob_client = blob_service_client.get_blob_client(
            container=g.container_name,
            blob=blob_name,
        )
        parquet_bytes = blob_client.download_blob().readall()
        df = pd.read_parquet(BytesIO(parquet_bytes))
    except Exception as exc:
        raise RepositoryError(
            f"Stakeholder metadata could not be loaded from '{blob_name}': {exc}"
        ) from exc

    fuel_types = (
        sorted(df["sheetName"].dropna().unique().tolist())
        if "sheetName" in df.columns
        else []
    )
    lead_parties = (
        sorted(df["Lead Party"].dropna().astype(str).unique().tolist())
        if "Lead Party" in df.columns
        else []
    )
    return df, fuel_types, lead_parties


@st.cache_data(ttl=3600, show_spinner="Loading time frames data...")
def get_time_frames(prefix: str = "NED/BMU/") -> list[str]:
    """List available Parquet time-frame filenames under the given Blob prefix."""
    try:
        blob_service_client = BlobServiceClient(
            account_url=g.storage_account_url,
            credential=g.credential,
        )
        container_client = blob_service_client.get_container_client(g.container_name)
        parquet_files: list[str] = []
        for blob in container_client.list_blobs(name_starts_with=prefix):
            if blob.name.endswith(".parquet"):
                parquet_files.append(blob.name.split("/")[-1])
        return parquet_files
    except Exception as exc:
        raise RepositoryError(
            f"Available time-frame blobs could not be listed for '{prefix}': {exc}"
        ) from exc
