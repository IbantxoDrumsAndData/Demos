"""Repository for Elexon REMIT outage event data."""

from datetime import datetime
from typing import Union
import pandas as pd
import requests
import streamlit as st

from src.repositories.operational_repository import RepositoryError


@st.cache_data(ttl=3600, show_spinner="Loading REMIT Information . . . ")
def get_remit_data(
    elexon_bmu_id: str,
    start_date: Union[datetime, str],
    end_date: Union[datetime, str],
) -> pd.DataFrame:
    """Fetch REMIT event details for an Elexon BMU ID and date range."""
    if not elexon_bmu_id or pd.isna(elexon_bmu_id):
        return pd.DataFrame()

    base_url = "https://data.elexon.co.uk/bmrs/api/v1/remit/list/by-event/stream"
    params = {
        "from": start_date,
        "to": end_date,
        "latestRevisionOnly": "true",
        "profileOnly": "false",
        "assetId": elexon_bmu_id,
    }

    try:
        response = requests.get(base_url, params=params, timeout=30)
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as exc:
        raise RepositoryError(
            f"Elexon REMIT list request failed for '{elexon_bmu_id}': {exc}"
        ) from exc
    except ValueError as exc:
        raise RepositoryError(
            f"Elexon REMIT list JSON decode failed for '{elexon_bmu_id}': {exc}"
        ) from exc

    list_df = pd.DataFrame(data)
    if list_df.empty or "id" not in list_df.columns:
        return pd.DataFrame()

    remit_details: list[pd.DataFrame] = []
    for remit_id in list_df["id"]:
        remit_url = f"https://data.elexon.co.uk/bmrs/api/v1/remit/{remit_id}"
        try:
            detail_resp = requests.get(remit_url, timeout=30)
            detail_resp.raise_for_status()
            remit_detail = detail_resp.json()
            if (
                isinstance(remit_detail, dict)
                and "data" in remit_detail
                and isinstance(remit_detail["data"], list)
                and len(remit_detail["data"]) > 0
            ):
                remit_details.append(pd.DataFrame(remit_detail["data"]))
        except requests.exceptions.RequestException:
            continue

    if remit_details:
        return pd.concat(remit_details, ignore_index=True)

    return pd.DataFrame()
