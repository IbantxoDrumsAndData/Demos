"""Repository for NED BOA instructions Parquet data."""

from io import BytesIO
import pandas as pd
import streamlit as st
from azure.storage.blob import BlobServiceClient

from src.repositories.operational_repository import RepositoryError
import src.utils.globals as g


@st.cache_data(ttl=3600, show_spinner="Loading BOA Instructions...")
def get_boa_instructions(
    blob_name: str = "NED/BOA_INSTRUCTIONS/latest_boa_instructions_data.parquet",
) -> pd.DataFrame:
    """Download BOA instructions data from Azure Blob Parquet storage."""
    try:
        blob_service_client = BlobServiceClient(
            account_url=g.storage_account_url,
            credential=g.credential,
        )
        blob_client = blob_service_client.get_blob_client(
            container=g.container_name,
            blob=blob_name,
        )
        parquet_bytes = blob_client.download_blob().readall()
        return pd.read_parquet(BytesIO(parquet_bytes))
    except Exception as exc:
        raise RepositoryError(
            f"BOA instructions could not be loaded from '{blob_name}': {exc}"
        ) from exc
