"""Repository for EnAppSys wholesale market price data."""

import pandas as pd
import requests
import streamlit as st

from src.repositories.operational_repository import RepositoryError
from src.utils.keyvault import get_secret


@st.cache_data(ttl=3600, show_spinner="Loading wholesale price data...")
def get_wholesale_prices(start_date: str, end_date: str) -> pd.DataFrame:
    """Fetch and pivot wholesale prices from EnAppSys for the given date window."""
    try:
        enappsys_pass = get_secret("ENAPP")
        enappsys_user = get_secret("ENAPPUSR")
    except Exception as exc:
        raise RepositoryError(
            f"EnAppSys credentials could not be retrieved from Key Vault: {exc}"
        ) from exc

    base_url = "https://app.enappsys.com/datadownload"
    params = {
        "code": "gb/elec/pricing/intraday/forecast",
        "currency": "GBP",
        "delimiter": "comma",
        "minavmax": "false",
        "pass": enappsys_pass,
        "res": "hh",
        "tag": "json",
        "timezone": "WET",
        "user": enappsys_user,
        "start": start_date,
        "end": end_date,
    }

    try:
        response = requests.get(base_url, params=params, timeout=30)
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as exc:
        raise RepositoryError(
            f"EnAppSys wholesale price request failed: {exc}"
        ) from exc
    except ValueError as exc:
        raise RepositoryError(f"EnAppSys wholesale JSON decode failed: {exc}") from exc

    if not isinstance(data, dict) or "data" not in data:
        raise RepositoryError("EnAppSys response is missing the 'data' key.")

    raw_df = pd.DataFrame(data["data"])
    if raw_df.empty:
        return pd.DataFrame(
            columns=[
                "dateTime",
                "DA_Nordpool £/MWh",
                "ID_Forecast £/MWh",
                "Upper_Forecast £/MWh",
                "Lower_Forecast £/MWh",
            ]
        )

    to_keep = [
        "GB_NORDPOOL_HR_DA.PRICE_GBP",
        "GB_MIDP_PRICE_FORECAST.DM01",
        "GB_SYSTEM_PRICE_FORECAST.SBP.DM01",
        "GB_SYSTEM_PRICE_FORECAST.SSP.DM01",
    ]

    filtered = raw_df[raw_df["dataTypeEntity"].isin(to_keep)]
    if filtered.empty:
        return pd.DataFrame(
            columns=[
                "dateTime",
                "DA_Nordpool £/MWh",
                "ID_Forecast £/MWh",
                "Upper_Forecast £/MWh",
                "Lower_Forecast £/MWh",
            ]
        )

    pivoted = filtered.pivot_table(
        index="dateTime", columns="dataTypeEntity", values="value"
    ).reset_index()

    pivoted["dateTime"] = pd.to_datetime(pivoted["dateTime"])
    pivoted = pivoted.sort_values("dateTime")

    for col in to_keep:
        if col in pivoted.columns:
            pivoted[col] = pd.to_numeric(pivoted[col], errors="coerce")

    pivoted = pivoted.rename(
        columns={
            "GB_NORDPOOL_HR_DA.PRICE_GBP": "DA_Nordpool £/MWh",
            "GB_MIDP_PRICE_FORECAST.DM01": "ID_Forecast £/MWh",
            "GB_SYSTEM_PRICE_FORECAST.SBP.DM01": "Upper_Forecast £/MWh",
            "GB_SYSTEM_PRICE_FORECAST.SSP.DM01": "Lower_Forecast £/MWh",
        }
    )
    return pivoted
