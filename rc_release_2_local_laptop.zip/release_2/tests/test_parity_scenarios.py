"""Parity validation suite covering all 10 required scenarios from the refactoring specification."""

from datetime import datetime
import numpy as np
import pandas as pd

from src.components.operational_chart import (
    build_dynamic_parameters_figure,
    build_operational_figure,
)
from src.components.price_chart import build_price_figure
from src.models.dashboard_filters import DashboardFilters
from src.repositories.operational_repository import RepositoryError
from src.services.filter_service import (
    derive_required_sources,
    validate_dashboard_filters,
)
from src.services.operational_service import (
    build_dynamic_parameters_table,
    filter_operational_by_bmu,
    filter_operational_data,
    load_remit_for_bmu,
    prepare_operational_data,
)
from src.services.price_comparison_service import (
    BOA_DISPLAY_COLUMNS,
    build_wholesale_comparison_table,
    filter_bid_offer_data,
    filter_boa_instructions_for_bmu,
    filter_wholesale_prices,
    get_available_pair_ids,
)
from src.utils.timing import build_source_diagnostic
from tests.conftest import legacy_build_operational_figure


def _assert_figures_equal(fig_a, fig_b) -> None:
    """Assert that two Plotly figures have identical trace names, x/y values, and shapes."""
    assert len(fig_a.data) == len(fig_b.data)
    for trace_a, trace_b in zip(fig_a.data, fig_b.data):
        assert trace_a.name == trace_b.name
        assert trace_a.mode == trace_b.mode
        assert list(pd.to_datetime(trace_a.x)) == list(pd.to_datetime(trace_b.x))
        np.testing.assert_allclose(
            np.asarray(trace_a.y, dtype=float),
            np.asarray(trace_b.y, dtype=float),
        )
    assert len(fig_a.layout.shapes) == len(fig_b.layout.shapes)
    assert fig_a.layout.title.text == fig_b.layout.title.text
    assert fig_a.layout.xaxis.title.text == fig_b.layout.xaxis.title.text
    assert fig_a.layout.yaxis.title.text == fig_b.layout.yaxis.title.text


def test_scenario_1_one_bmu_operational_remit_off(synthetic_data):
    """Scenario 1: One BMU, Operational Monitoring, REMIT off."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 28, 0, 0)
    bmu = "T_BMU_01"

    filters = DashboardFilters(
        start_datetime=start_dt,
        end_datetime=end_dt,
        bmus=(bmu,),
        views=("Operational Data",),
        overlays=(),
    )
    required = derive_required_sources(filters, active_page="operational_monitoring")
    assert required == {"operational_data", "bmu_mapping"}
    assert "remit" not in required

    remit_calls = []

    def forbidden_remit_fetcher(*args, **kwargs):
        remit_calls.append(args)
        return synthetic_data["remit"]

    prepared = prepare_operational_data(
        synthetic_data["operational"], synthetic_data["bmu_mapping"]
    )
    filtered = filter_operational_data(prepared, start_dt, end_dt, (bmu,))
    bmu_df = filter_operational_by_bmu(filtered, bmu)

    remit_df, remit_overlays, warning = load_remit_for_bmu(
        bmu_df=bmu_df,
        start_datetime=start_dt,
        end_datetime=end_dt,
        show_remit_overlay=False,
        remit_fetcher=forbidden_remit_fetcher,
    )
    assert len(remit_calls) == 0
    assert remit_df.empty
    assert remit_overlays == []
    assert warning is None

    refactored_fig = build_operational_figure(bmu=bmu, bmu_df=bmu_df)
    legacy_fig, legacy_bmu_df = legacy_build_operational_figure(
        synthetic_data["operational"],
        synthetic_data["bmu_mapping"],
        bmu,
        start_dt,
        end_dt,
        show_remit=False,
        remit_df=synthetic_data["remit"],
    )

    assert len(bmu_df) == len(legacy_bmu_df)
    assert bmu_df["GMT_DATETIME"].min() == legacy_bmu_df["GMT_DATETIME"].min()
    assert bmu_df["GMT_DATETIME"].max() == legacy_bmu_df["GMT_DATETIME"].max()
    pd.testing.assert_frame_equal(
        bmu_df.reset_index(drop=True), legacy_bmu_df.reset_index(drop=True)
    )
    _assert_figures_equal(refactored_fig, legacy_fig)


def test_scenario_2_one_bmu_operational_remit_on(synthetic_data):
    """Scenario 2: One BMU, Operational Monitoring, REMIT on."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 28, 12, 0)
    bmu = "T_BMU_01"

    filters = DashboardFilters(
        start_datetime=start_dt,
        end_datetime=end_dt,
        bmus=(bmu,),
        views=("Operational Data",),
        overlays=("REMIT Information",),
    )
    required = derive_required_sources(filters, active_page="operational_monitoring")
    assert "remit" in required

    prepared = prepare_operational_data(
        synthetic_data["operational"], synthetic_data["bmu_mapping"]
    )
    filtered = filter_operational_data(prepared, start_dt, end_dt, (bmu,))
    bmu_df = filter_operational_by_bmu(filtered, bmu)

    remit_calls = []

    def mock_remit_fetcher(elexon_id, s_dt, e_dt):
        remit_calls.append((elexon_id, s_dt, e_dt))
        return synthetic_data["remit"]

    remit_df, remit_overlays, warning = load_remit_for_bmu(
        bmu_df=bmu_df,
        start_datetime=start_dt,
        end_datetime=end_dt,
        show_remit_overlay=True,
        remit_fetcher=mock_remit_fetcher,
    )
    assert len(remit_calls) == 1
    assert remit_calls[0][0] == "ELEX_T_BMU_01"
    assert warning is None
    assert len(remit_overlays) == 1

    refactored_fig = build_operational_figure(
        bmu=bmu, bmu_df=bmu_df, remit_overlays=remit_overlays
    )
    legacy_fig, _ = legacy_build_operational_figure(
        synthetic_data["operational"],
        synthetic_data["bmu_mapping"],
        bmu,
        start_dt,
        end_dt,
        show_remit=True,
        remit_df=synthetic_data["remit"],
    )
    _assert_figures_equal(refactored_fig, legacy_fig)


def test_scenario_3_one_bmu_market_prices_bid_offer_off(synthetic_data):
    """Scenario 3: One BMU, Market Prices, Bid/Offer off."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 0, 0)
    bmu = "T_BMU_01"

    filters = DashboardFilters(
        start_datetime=start_dt,
        end_datetime=end_dt,
        bmus=(bmu,),
        views=("Wholesale Prices",),
        overlays=(),
        show_tables=True,
    )
    required = derive_required_sources(filters, active_page="market_prices")
    assert required == {"wholesale_prices"}
    assert "bid_offer_data" not in required

    filtered_wholesale = filter_wholesale_prices(
        synthetic_data["wholesale"], start_dt, end_dt
    )
    fig = build_price_figure(
        bmu=bmu,
        filtered_wholesale_df=filtered_wholesale,
        show_bid_offer_overlay=False,
    )
    assert [t.name for t in fig.data] == ["ID Forecast", "DA Forecast"]

    table_df = build_wholesale_comparison_table(
        filtered_wholesale_df=filtered_wholesale,
        filtered_bid_offer_df=None,
        show_bid_offer_overlay=False,
    )
    pd.testing.assert_frame_equal(table_df, filtered_wholesale)


def test_scenario_4_one_bmu_market_prices_bid_offer_on(synthetic_data):
    """Scenario 4: One BMU, Market Prices, Bid/Offer on."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 0, 0)
    bmu = "T_BMU_01"

    filters = DashboardFilters(
        start_datetime=start_dt,
        end_datetime=end_dt,
        bmus=(bmu,),
        views=("Wholesale Prices",),
        overlays=("Bid / Offer Data",),
        show_tables=True,
    )
    required = derive_required_sources(filters, active_page="market_prices")
    assert required == {"wholesale_prices", "bid_offer_data"}

    filtered_wholesale = filter_wholesale_prices(
        synthetic_data["wholesale"], start_dt, end_dt
    )
    filtered_bod = filter_bid_offer_data(
        synthetic_data["bid_offer"], start_dt, end_dt, (bmu,)
    )
    pair_ids = get_available_pair_ids(filtered_bod)
    assert pair_ids == [-1, 1, 2]

    fig = build_price_figure(
        bmu=bmu,
        filtered_wholesale_df=filtered_wholesale,
        bmu_bid_offer_df=filtered_bod[filtered_bod["BMU_ID"] == bmu],
        pair_ids=pair_ids,
        show_bid_offer_overlay=True,
    )
    expected_traces = [
        "ID Forecast",
        "DA Forecast",
        "Pair -1 BID",
        "Pair -1 OFFER",
        "Pair 1 BID",
        "Pair 1 OFFER",
        "Pair 2 BID",
        "Pair 2 OFFER",
    ]
    assert [t.name for t in fig.data] == expected_traces

    comparison_df = build_wholesale_comparison_table(
        filtered_wholesale_df=filtered_wholesale,
        filtered_bid_offer_df=filtered_bod,
        show_bid_offer_overlay=True,
    )

    # Compare against legacy inline pivot logic
    bod_legacy = synthetic_data["bid_offer"].copy()
    bod_legacy["GMT_DATETIME"] = pd.to_datetime(bod_legacy["GMT_DATETIME"])
    bod_legacy = bod_legacy[
        (bod_legacy["GMT_DATETIME"] >= start_dt)
        & (bod_legacy["GMT_DATETIME"] <= end_dt)
        & (bod_legacy["BMU_ID"].isin([bmu]))
    ]
    pivot_legacy = bod_legacy.pivot_table(
        index="GMT_DATETIME",
        columns=["BMU_ID", "BOPAIR_ID"],
        values=["BID_PRICE_GBP_MWH", "OFFER_PRICE_GBP_MWH"],
        aggfunc="first",
    )
    pivot_legacy.columns = [
        f"{b} | Pair {p} | {'Bid' if m == 'BID_PRICE_GBP_MWH' else 'Offer'}"
        for m, b, p in pivot_legacy.columns
    ]
    pivot_legacy = pivot_legacy.reset_index()
    expected_comparison = filtered_wholesale.merge(
        pivot_legacy,
        left_on="dateTime",
        right_on="GMT_DATETIME",
        how="left",
    ).drop(columns=["GMT_DATETIME"], errors="ignore")

    pd.testing.assert_frame_equal(comparison_df, expected_comparison)


def test_scenario_5_multiple_bmus(synthetic_data):
    """Scenario 5: Multiple BMUs across Operational, Wholesale + Bid/Offer, and Dynamic Parameters."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 0, 0)
    bmus = ("T_BMU_01", "T_BMU_02", "T_BMU_03")

    prepared = prepare_operational_data(
        synthetic_data["operational"], synthetic_data["bmu_mapping"]
    )
    filtered = filter_operational_data(prepared, start_dt, end_dt, bmus)
    assert set(filtered["BMU_ID"].unique()) == set(bmus)
    assert filtered["GMT_DATETIME"].is_monotonic_increasing

    for bmu in bmus:
        bmu_df = filter_operational_by_bmu(filtered, bmu)
        refactored_fig = build_operational_figure(bmu=bmu, bmu_df=bmu_df)
        legacy_fig, legacy_bmu_df = legacy_build_operational_figure(
            synthetic_data["operational"],
            synthetic_data["bmu_mapping"],
            bmu,
            start_dt,
            end_dt,
            show_remit=False,
            remit_df=pd.DataFrame(),
        )
        assert len(bmu_df) == len(legacy_bmu_df)
        _assert_figures_equal(refactored_fig, legacy_fig)


def test_scenario_6_dynamic_parameters(synthetic_data):
    """Scenario 6: Dynamic Parameters chart traces, x-axis range, and concatenated table."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 0, 0)
    bmus = ("T_BMU_01", "T_BMU_02")

    prepared = prepare_operational_data(
        synthetic_data["operational"], synthetic_data["bmu_mapping"]
    )
    filtered = filter_operational_data(prepared, start_dt, end_dt, bmus)
    bmu_df = filter_operational_by_bmu(filtered, "T_BMU_01")

    dyn_fig = build_dynamic_parameters_figure("T_BMU_01", bmu_df, start_dt, end_dt)
    assert [t.name for t in dyn_fig.data] == [
        "Average NDZ",
        "Average MZT",
        "Average MNZT",
    ]
    assert list(dyn_fig.layout.xaxis.range) == [start_dt, end_dt]

    dyn_table = build_dynamic_parameters_table(filtered, bmus)
    expected_cols = [
        "GMT_DATETIME",
        "BMU_ID",
        "AVERAGENOTICETODEVIATEFROMZERO_MINS",
        "AVERAGEMINIMUMZEROTIME_MINS",
        "AVERAGEMINIMUMNONZEROTIME_MINS",
    ]
    assert list(dyn_table.columns) == expected_cols
    assert len(dyn_table) == len(bmu_df) * len(bmus)


def test_scenario_7_boa_instructions_date_and_bmu_filtering(synthetic_data):
    """Scenario 7: BOA Instructions respects both BMU and date range, preserving columns and descending sort."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 12, 0)
    bmu = "T_BMU_01"

    filtered_boa = filter_boa_instructions_for_bmu(
        synthetic_data["boa"], bmu, start_dt, end_dt
    )
    assert list(filtered_boa.columns) == BOA_DISPLAY_COLUMNS
    assert not filtered_boa.empty
    assert (filtered_boa["BMU_ID"] == bmu).all()
    assert (filtered_boa["GMT_DATETIME"] >= start_dt).all()
    assert (filtered_boa["GMT_DATETIME"] <= end_dt).all()
    assert filtered_boa["GMT_DATETIME"].is_monotonic_decreasing


def test_scenario_8_empty_date_or_bmu_result(synthetic_data):
    """Scenario 8: Empty date/BMU result produces empty DataFrames and descriptive diagnostic message."""
    start_dt = datetime(2030, 1, 1, 0, 0)
    end_dt = datetime(2030, 1, 2, 0, 0)
    bmu = "T_BMU_01"

    prepared = prepare_operational_data(
        synthetic_data["operational"], synthetic_data["bmu_mapping"]
    )
    filtered = filter_operational_data(prepared, start_dt, end_dt, (bmu,))
    assert filtered.empty

    diag = build_source_diagnostic(
        source_name="NED Operational Data",
        loaded=True,
        df=synthetic_data["operational"],
        filtered_df=filtered,
        timestamp_col="GMT_DATETIME",
    )
    assert diag.row_count == len(synthetic_data["operational"])
    assert diag.selected_bmu_row_count == 0
    assert "No rows matched submitted BMUs and date range" in diag.message


def test_scenario_9_missing_elexon_mapping(synthetic_data):
    """Scenario 9: BMU without Elexon mapping skips REMIT call cleanly and still builds operational chart."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 0, 0)
    unmapped_bmu = "T_BMU_12"  # Last BMU omitted from bmu_mapping fixture

    prepared = prepare_operational_data(
        synthetic_data["operational"], synthetic_data["bmu_mapping"]
    )
    filtered = filter_operational_data(prepared, start_dt, end_dt, (unmapped_bmu,))
    bmu_df = filter_operational_by_bmu(filtered, unmapped_bmu)
    assert not bmu_df.empty
    assert bmu_df["ELEXON_BMU_ID"].isna().all()

    remit_calls = []

    def tracking_fetcher(*args, **kwargs):
        remit_calls.append(args)
        return synthetic_data["remit"]

    remit_df, overlays, warning = load_remit_for_bmu(
        bmu_df=bmu_df,
        start_datetime=start_dt,
        end_datetime=end_dt,
        show_remit_overlay=True,
        remit_fetcher=tracking_fetcher,
    )
    assert len(remit_calls) == 0
    assert remit_df.empty
    assert overlays == []
    assert warning is not None and "no Elexon BMU mapping" in warning

    fig = build_operational_figure(unmapped_bmu, bmu_df, remit_overlays=overlays)
    assert len(fig.data) == 10


def test_scenario_10_external_api_failure(synthetic_data):
    """Scenario 10: External REMIT or BMU mapping failure is reported without breaking operational chart."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 0, 0)
    bmu = "T_BMU_01"

    # Case A: BMU mapping API returned None / failed -> operational data still prepares and plots
    prepared_no_map = prepare_operational_data(synthetic_data["operational"], None)
    filtered_no_map = filter_operational_data(prepared_no_map, start_dt, end_dt, (bmu,))
    bmu_df_no_map = filter_operational_by_bmu(filtered_no_map, bmu)
    fig_no_map = build_operational_figure(bmu, bmu_df_no_map)
    assert len(fig_no_map.data) == 10

    # Case B: REMIT API raises RepositoryError -> warning returned, operational chart still builds
    prepared = prepare_operational_data(
        synthetic_data["operational"], synthetic_data["bmu_mapping"]
    )
    bmu_df = filter_operational_by_bmu(
        filter_operational_data(prepared, start_dt, end_dt, (bmu,)), bmu
    )

    def failing_remit_fetcher(*args, **kwargs):
        raise RepositoryError("Simulated Elexon REMIT 503 Service Unavailable")

    remit_df, overlays, warning = load_remit_for_bmu(
        bmu_df=bmu_df,
        start_datetime=start_dt,
        end_datetime=end_dt,
        show_remit_overlay=True,
        remit_fetcher=failing_remit_fetcher,
    )
    assert remit_df.empty
    assert overlays == []
    assert warning is not None and "503 Service Unavailable" in warning

    fig = build_operational_figure(bmu, bmu_df, remit_overlays=overlays)
    assert len(fig.data) == 10


def test_unfinished_views_do_not_require_data_sources():
    """Unfinished views (Ancillary Services, Strike Prices, Wind ROC Mappings) load zero sources."""
    filters = DashboardFilters(
        start_datetime=datetime(2026, 10, 25),
        end_datetime=datetime(2026, 10, 26),
        bmus=(),
        views=("Ancillary Services", "Strike Prices", "Wind ROC Mappings"),
    )
    is_valid, errors = validate_dashboard_filters(filters)
    assert is_valid
    assert errors == []
    assert derive_required_sources(filters) == set()


def test_local_blob_only_bid_offer_without_wholesale(synthetic_data):
    """Verify Bid/Offer chart and pivot table work in local Blob-only mode without EnAppSys wholesale data."""
    start_dt = datetime(2026, 10, 26, 0, 0)
    end_dt = datetime(2026, 10, 27, 0, 0)
    bmu = "T_BMU_01"

    filtered_bod = filter_bid_offer_data(
        synthetic_data["bid_offer"], start_dt, end_dt, (bmu,)
    )
    pair_ids = get_available_pair_ids(filtered_bod)
    fig = build_price_figure(
        bmu=bmu,
        filtered_wholesale_df=pd.DataFrame(),
        bmu_bid_offer_df=filtered_bod,
        pair_ids=pair_ids,
        show_bid_offer_overlay=True,
    )
    assert [t.name for t in fig.data] == [
        "Pair -1 BID",
        "Pair -1 OFFER",
        "Pair 1 BID",
        "Pair 1 OFFER",
        "Pair 2 BID",
        "Pair 2 OFFER",
    ]

    pivot_table = build_wholesale_comparison_table(
        filtered_wholesale_df=pd.DataFrame(),
        filtered_bid_offer_df=filtered_bod,
        show_bid_offer_overlay=True,
    )
    assert not pivot_table.empty
    assert "GMT_DATETIME" in pivot_table.columns
    assert "T_BMU_01 | Pair 1 | Bid" in pivot_table.columns


def test_dotenv_enappsys_secret_loading(tmp_path, monkeypatch):
    """Verify EnAppSys credentials are read from a local .env file without calling Key Vault."""
    from src.utils.keyvault import get_secret

    for key in (
        "ENAPP",
        "ENAPPUSR",
        "ENAPPSYS_PASS",
        "ENAPPSYS_USER",
        "ENAPPSYS_PASSWORD",
        "ENAPPSYS_USERNAME",
    ):
        monkeypatch.delenv(key, raising=False)

    env_file = tmp_path / ".env"
    env_file.write_text(
        "# Local EnAppSys configuration\n"
        'ENAPPUSR="test_user_from_dotenv"\n'
        "ENAPP='test_pass_from_dotenv'\n",
        encoding="utf-8",
    )

    assert get_secret("ENAPPUSR", dotenv_path=env_file) == "test_user_from_dotenv"
    assert get_secret("ENAPP", dotenv_path=env_file) == "test_pass_from_dotenv"

    # Also verify ENAPPSYS_USER / ENAPPSYS_PASS aliases work
    for key in ("ENAPP", "ENAPPUSR"):
        monkeypatch.delenv(key, raising=False)

    alias_env_file = tmp_path / ".env.alias"
    alias_env_file.write_text(
        "ENAPPSYS_USER=alias_user\nENAPPSYS_PASS=alias_pass\n",
        encoding="utf-8",
    )
    assert get_secret("ENAPPUSR", dotenv_path=alias_env_file) == "alias_user"
    assert get_secret("ENAPP", dotenv_path=alias_env_file) == "alias_pass"
