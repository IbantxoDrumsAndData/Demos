"""Service functions for Bid/Offer overlays, comparison tables, and BOA tables in local Blob-only mode."""

from datetime import datetime
from typing import Optional
import pandas as pd
import streamlit as st

BOA_DISPLAY_COLUMNS: list[str] = [
    "GMT_DATETIME",
    "BMU_ID",
    "BOPAIR_ID",
    "BID_PRICE",
    "OFFER_PRICE",
    "CST_GROUP",
    "DIRECT_ACTION_COST",
]


@st.cache_data(ttl=3600, show_spinner=False)
def prepare_wholesale_prices(wholesale_df: pd.DataFrame) -> pd.DataFrame:
    """Ensure wholesale price dateTime column is parsed as datetime."""
    if wholesale_df is None or wholesale_df.empty:
        return wholesale_df.copy() if wholesale_df is not None else pd.DataFrame()
    df = wholesale_df.copy()
    df["dateTime"] = pd.to_datetime(df["dateTime"])
    return df


@st.cache_data(ttl=3600, show_spinner=False)
def filter_wholesale_prices(
    wholesale_df: pd.DataFrame,
    start_datetime: datetime,
    end_datetime: datetime,
) -> pd.DataFrame:
    """Filter wholesale prices to the submitted datetime range."""
    if wholesale_df is None or wholesale_df.empty:
        return wholesale_df.copy() if wholesale_df is not None else pd.DataFrame()
    df = prepare_wholesale_prices(wholesale_df)
    return df[
        (df["dateTime"] >= start_datetime) & (df["dateTime"] <= end_datetime)
    ].copy()


@st.cache_data(ttl=3600, show_spinner=False)
def prepare_bid_offer_data(bid_offer_df: pd.DataFrame) -> pd.DataFrame:
    """Convert Bid/Offer GMT_DATETIME column to pandas datetime."""
    if bid_offer_df is None or bid_offer_df.empty:
        return bid_offer_df.copy() if bid_offer_df is not None else pd.DataFrame()
    df = bid_offer_df.copy()
    df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])
    return df


@st.cache_data(ttl=3600, show_spinner=False)
def filter_bid_offer_data(
    bid_offer_df: pd.DataFrame,
    start_datetime: datetime,
    end_datetime: datetime,
    bmus: tuple[str, ...],
) -> pd.DataFrame:
    """Filter Bid/Offer rows by date range and selected BMUs."""
    if bid_offer_df is None or bid_offer_df.empty:
        return bid_offer_df.copy() if bid_offer_df is not None else pd.DataFrame()
    df = prepare_bid_offer_data(bid_offer_df)
    mask = (df["GMT_DATETIME"] >= start_datetime) & (df["GMT_DATETIME"] <= end_datetime)
    if bmus:
        mask = mask & df["BMU_ID"].isin(bmus)
    return df.loc[mask].copy()


def get_available_pair_ids(filtered_bid_offer_df: pd.DataFrame) -> list:
    """Return sorted unique BOPAIR_ID values present in the filtered Bid/Offer DataFrame."""
    if (
        filtered_bid_offer_df is None
        or filtered_bid_offer_df.empty
        or "BOPAIR_ID" not in filtered_bid_offer_df.columns
    ):
        return []
    return sorted(filtered_bid_offer_df["BOPAIR_ID"].dropna().unique().tolist())


@st.cache_data(ttl=3600, show_spinner=False)
def build_wholesale_comparison_table(
    filtered_wholesale_df: Optional[pd.DataFrame],
    filtered_bid_offer_df: Optional[pd.DataFrame],
    show_bid_offer_overlay: bool,
) -> pd.DataFrame:
    """Build the Wholesale + Bid/Offer or Blob-only Bid/Offer pivot table."""
    has_wholesale = (
        filtered_wholesale_df is not None and not filtered_wholesale_df.empty
    )
    has_bod = (
        show_bid_offer_overlay
        and filtered_bid_offer_df is not None
        and not filtered_bid_offer_df.empty
    )

    if not has_bod:
        return filtered_wholesale_df.copy() if has_wholesale else pd.DataFrame()

    pivot_df = filtered_bid_offer_df.pivot_table(
        index="GMT_DATETIME",
        columns=["BMU_ID", "BOPAIR_ID"],
        values=["BID_PRICE_GBP_MWH", "OFFER_PRICE_GBP_MWH"],
        aggfunc="first",
    )

    pivot_df.columns = [
        (
            f"{bmu} | Pair {pair_id} | "
            f"{'Bid' if metric == 'BID_PRICE_GBP_MWH' else 'Offer'}"
        )
        for metric, bmu, pair_id in pivot_df.columns
    ]

    pivot_df = pivot_df.reset_index()

    if not has_wholesale:
        return pivot_df

    comparison_df = (
        filtered_wholesale_df.copy()
        .merge(
            pivot_df,
            left_on="dateTime",
            right_on="GMT_DATETIME",
            how="left",
        )
        .drop(columns=["GMT_DATETIME"], errors="ignore")
    )
    return comparison_df


@st.cache_data(ttl=3600, show_spinner=False)
def prepare_boa_instructions(boa_df: pd.DataFrame) -> pd.DataFrame:
    """Convert BOA instructions GMT_DATETIME column to pandas datetime."""
    if boa_df is None or boa_df.empty:
        return boa_df.copy() if boa_df is not None else pd.DataFrame()
    df = boa_df.copy()
    df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])
    return df


@st.cache_data(ttl=3600, show_spinner=False)
def filter_boa_instructions_for_bmu(
    boa_df: pd.DataFrame,
    bmu: str,
    start_datetime: datetime,
    end_datetime: datetime,
) -> pd.DataFrame:
    """Filter BOA instructions by BMU and submitted date range, sorted descending by GMT_DATETIME."""
    if boa_df is None or boa_df.empty:
        return pd.DataFrame(columns=BOA_DISPLAY_COLUMNS)

    df = prepare_boa_instructions(boa_df)
    mask = (
        (df["BMU_ID"] == bmu)
        & (df["GMT_DATETIME"] >= start_datetime)
        & (df["GMT_DATETIME"] <= end_datetime)
    )
    filtered = df.loc[mask].sort_values("GMT_DATETIME", ascending=False)
    available_cols = [c for c in BOA_DISPLAY_COLUMNS if c in filtered.columns]
    return filtered[available_cols]
