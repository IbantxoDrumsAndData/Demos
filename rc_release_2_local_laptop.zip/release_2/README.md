# Market Monitoring Dashboard — Release 2 (Local Laptop Execution: Windows 11 + VS Code + Conda)

Performance-optimised, multi-page Streamlit application for **local execution on a Windows 11 laptop** using **VS Code** and **Conda** (`python=3.11`).

- **Azure Blob Storage**: Reads Parquet datasets (`NED/bm_stakeholders.parquet`, `NED/BMU/latest_bmu_data.parquet`, `NED/BID_OFFERS/latest_bid_offer_data.parquet`, `NED/BOA_INSTRUCTIONS/latest_boa_instructions_data.parquet`) using `DefaultAzureCredential()` (`az login`).
- **EnAppSys Wholesale API via `.env`**: Reads EnAppSys credentials (`ENAPPUSR` and `ENAPP`, or `ENAPPSYS_USER` and `ENAPPSYS_PASS`) directly from a local `.env` file in the `release_2` root directory.
- **Elexon BMRS APIs**: Calls Elexon BMU mapping and REMIT APIs directly over HTTPS.

---

## 1. Quick Start on Windows 11 (VS Code + Conda)

### Prerequisites
- **Windows 11**
- **Miniconda** or **Anaconda** installed
- **Visual Studio Code** with the **Python** extension (`ms-python.python`)
- **Azure CLI** (`az login`) signed in with read access to the Azure Blob Storage container

### Step 1: Open in VS Code
Open the `release_2` folder in Visual Studio Code (`File > Open Folder...`).

### Step 2: Create & Activate the Conda Environment
Open a terminal in VS Code (**Command Prompt** or **Anaconda Prompt**) and run:

```bat
conda env create -f environment.yml
conda activate price-dashboard-local
```
*(Or double-click / run `setup_conda_env.bat`.)*

Select the **`price-dashboard-local`** Conda interpreter in VS Code (`Ctrl+Shift+P` -> `Python: Select Interpreter` -> `price-dashboard-local`).

### Step 3: Create Your `.env` File & Authenticate with Azure
1. Copy `.env.example` to `.env` in the `release_2` root directory:
   ```bat
   copy .env.example .env
   ```
2. Edit `.env` with your EnAppSys credentials and Azure Blob container settings:
   ```dotenv
   ENAPPUSR=your_enappsys_username
   ENAPP=your_enappsys_password

   AZURE_STORAGE_ACCOUNT_URL=https://<your-storage-account>.blob.core.windows.net
   AZURE_STORAGE_CONTAINER_NAME=<your-container-name>
   ```
   *(Note: Both `ENAPPUSR`/`ENAPP` and `ENAPPSYS_USER`/`ENAPPSYS_PASS` variable names are supported in `.env`.)*
3. Sign in via Azure CLI so `DefaultAzureCredential()` can read from Azure Blob Storage:
   ```bat
   az login
   ```

### Step 4: Run the Dashboard
From the activated `price-dashboard-local` Conda terminal in VS Code:

```bat
python -m streamlit run streamlit_app.py --server.port 8000
```
*(Or press **`F5`** in VS Code and select **`Streamlit: Run Market Monitoring Dashboard`**, or run **`run_dashboard.bat`**.)*

---

## 2. Running Tests, Benchmarks, and Formatting on Windows 11

With `conda activate price-dashboard-local`:

```bat
REM 1. Run all 13 parity & .env validation tests
pytest -v tests

REM 2. Run the before-and-after performance benchmark comparison
python tests\benchmark_comparison.py

REM 3. Check code formatting with Black
black --check .
```

---

## 3. Application Structure

```text
release_2/
├── .env.example                   # Template for local .env (EnAppSys + Blob Storage settings)
├── .streamlit/
│   └── config.toml                # NESO branding & light theme configuration
├── .vscode/
│   ├── extensions.json            # Recommended VS Code Python extensions
│   ├── launch.json                # F5 debug configs (loads ${workspaceFolder}/.env)
│   ├── settings.json              # Windows 11 Conda, Black, and Pytest settings
│   └── tasks.json                 # One-click VS Code tasks
├── assets/
│   └── logo.png
├── environment.yml                # Conda environment specification (Python 3.11)
├── pyproject.toml                 # Project metadata, Black & Pytest config
├── requirements.txt               # Pip requirements
├── setup_conda_env.bat            # Windows batch helper to create/update Conda env
├── run_dashboard.bat              # Windows batch helper to launch Streamlit
├── streamlit_app.py               # Multi-page navigation entry point
├── pages/
│   ├── operational_monitoring.py  # Operational traces, Dynamic Params, REMIT overlay
│   ├── market_prices.py           # EnAppSys wholesale prices & BMU Bid/Offer overlay
│   ├── balancing_actions.py       # BMU + date-filtered BOA instructions table
│   └── data_diagnostics.py        # Execution timings, row counts, and freshness
├── src/
│   ├── models/
│   │   └── dashboard_filters.py   # Immutable DashboardFilters & SourceDiagnostic
│   ├── repositories/
│   │   ├── stakeholder_repository.py # Azure Blob: NED/bm_stakeholders.parquet
│   │   ├── operational_repository.py # Azure Blob: NED/BMU/latest_bmu_data.parquet + Elexon BMU mapping API
│   │   ├── remit_repository.py       # Elexon REMIT API
│   │   ├── wholesale_repository.py   # EnAppSys wholesale API (reads credentials from .env)
│   │   ├── bid_offer_repository.py   # Azure Blob: NED/BID_OFFERS/latest_bid_offer_data.parquet
│   │   └── boa_repository.py         # Azure Blob: NED/BOA_INSTRUCTIONS/latest_boa_instructions_data.parquet
│   ├── services/
│   │   ├── filter_service.py
│   │   ├── operational_service.py
│   │   └── price_comparison_service.py
│   ├── components/
│   │   ├── filter_panel.py
│   │   ├── operational_chart.py
│   │   ├── price_chart.py
│   │   ├── boa_table.py
│   │   └── source_status.py
│   └── utils/
│       ├── dates.py
│       ├── figTrace.py
│       ├── globals.py             # Standard-library .env loader + DefaultAzureCredential()
│       ├── keyvault.py            # Reads ENAPP/ENAPPUSR from .env first (with Key Vault fallback)
│       └── timing.py              # perf_counter timing instrumentation
└── tests/
    ├── conftest.py
    ├── test_parity_scenarios.py   # Parity + .env validation test suite
    └── benchmark_comparison.py    # Before-and-after performance benchmark script
```
