"""Plotly figure builder for Wholesale prices and explicit 6-trace Bid/Offer overlays."""

from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go

from src.models.investigation import (
    BID_OFFER_TRACE_SPECS,
    CHART_HEIGHT,
    PLOTLY_BG_COLOR,
    PLOTLY_THEME,
)
from src.utils.figTrace import figTrace


def build_wholesale_figure(
    bmu: str,
    filtered_wholesale_df: pd.DataFrame,
    show_bid_offer: bool,
    selected_bod_df: pd.DataFrame,
) -> go.Figure:
    """Build the wholesale price figure with six explicit Bid/Offer traces (-1..-3 Bids, +1..+3 Offers)."""
    wholesale_fig = go.Figure()

    if filtered_wholesale_df is not None and not filtered_wholesale_df.empty:
        figTrace(
            wholesale_fig,
            filtered_wholesale_df["dateTime"],
            filtered_wholesale_df["DA_Nordpool £/MWh"],
            "lines",
            "DA Price",
            line=dict(width=3),
        )
        figTrace(
            wholesale_fig,
            filtered_wholesale_df["dateTime"],
            filtered_wholesale_df["ID_Forecast £/MWh"],
            "lines",
            "ID Forecast",
            line=dict(width=3),
        )

    if show_bid_offer and selected_bod_df is not None and not selected_bod_df.empty:
        bmu_bod_df = selected_bod_df[selected_bod_df["BMU_ID"] == bmu]

        for spec in BID_OFFER_TRACE_SPECS:
            pair_id = spec["pair_id"]
            col_name = spec["column"]
            trace_name = spec["name"]
            visibility = spec["visible"]

            pair_df = bmu_bod_df[bmu_bod_df["BOPAIR_ID"] == pair_id].sort_values(
                "GMT_DATETIME"
            )
            if pair_df.empty or col_name not in pair_df.columns:
                continue

            wholesale_fig.add_trace(
                go.Scatter(
                    x=pair_df["GMT_DATETIME"],
                    y=pair_df[col_name],
                    mode="lines",
                    name=trace_name,
                    line=dict(width=3, dash="dot"),
                    visible=visibility,
                )
            )

    wholesale_fig.update_layout(
        template=PLOTLY_THEME,
        paper_bgcolor=PLOTLY_BG_COLOR,
        plot_bgcolor=PLOTLY_BG_COLOR,
        xaxis_title="Date/Time",
        yaxis_title="£/MWh",
        height=CHART_HEIGHT,
        margin=dict(
            l=55,
            r=20,
            t=36,
            b=55,
            autoexpand=True,
        ),
        hovermode="x unified",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0,
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor="#CBD5E1",
            gridwidth=1,
        ),
    )
    return wholesale_fig
