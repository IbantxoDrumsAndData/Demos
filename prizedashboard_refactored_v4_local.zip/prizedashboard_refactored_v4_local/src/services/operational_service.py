"""Operational data preparation, filtering, Dynamic Parameters, REMIT, and Constraints time-band logic."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any
import pandas as pd
import streamlit as st

from src.models.investigation import DYNAMIC_PARAM_COLUMNS


@st.cache_data(ttl=3600, show_spinner=False)
def prepare_operational_with_mapping(
    operational_df: pd.DataFrame,
    bmu_mapping_df: pd.DataFrame,
) -> pd.DataFrame:
    """Parse operational timestamps and left-join Elexon BMU IDs."""
    df = operational_df.copy()
    df["GMT_DATETIME"] = pd.to_datetime(df["GMT_DATETIME"])
    if (
        bmu_mapping_df is not None
        and not bmu_mapping_df.empty
        and {"BMU_ID", "ELEXON_BMU_ID"}.issubset(bmu_mapping_df.columns)
    ):
        df = df.merge(bmu_mapping_df, on="BMU_ID", how="left")
    elif "ELEXON_BMU_ID" not in df.columns:
        df["ELEXON_BMU_ID"] = pd.NA
    return df


@st.cache_data(ttl=3600, show_spinner=False)
def filter_operational_data(
    prepared_df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    bmus_tuple: tuple[str, ...],
) -> pd.DataFrame:
    """Filter prepared operational data by datetime range and selected BMUs."""
    mask = (prepared_df["GMT_DATETIME"] >= start_dt) & (
        prepared_df["GMT_DATETIME"] <= end_dt
    )
    if bmus_tuple:
        mask = mask & prepared_df["BMU_ID"].isin(bmus_tuple)
    return prepared_df.loc[mask].sort_values("GMT_DATETIME")


def extract_dynamic_parameters_df(
    filtered_operational_df: pd.DataFrame,
    select_bmus: list[str] | tuple[str, ...],
) -> pd.DataFrame:
    """Extract concatenated Dynamic Parameters DataFrame in selected-BMU order."""
    if filtered_operational_df is None or filtered_operational_df.empty:
        return pd.DataFrame()

    dynamic_frames: list[pd.DataFrame] = []
    for bmu in select_bmus:
        bmu_df = filtered_operational_df[
            filtered_operational_df["BMU_ID"] == bmu
        ].sort_values("GMT_DATETIME")
        if bmu_df.empty:
            continue
        dynamic_frames.append(bmu_df[DYNAMIC_PARAM_COLUMNS])

    if not dynamic_frames:
        return pd.DataFrame()

    return pd.concat(dynamic_frames, ignore_index=True)


def prepare_remit_time_bands(
    remit_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
) -> list[dict[str, Any]]:
    """Deduplicate REMIT revisions, exclude dismissed rows, and compute simple time-band windows."""
    if remit_df is None or remit_df.empty:
        return []

    required_columns = {"eventStartTime", "eventEndTime"}
    if not required_columns.issubset(remit_df.columns):
        return []

    r_df = remit_df.copy()

    # Keep only the latest revision of each REMIT message.
    if {"mrid", "revisionNumber"}.issubset(r_df.columns):
        r_df["revisionNumber"] = pd.to_numeric(
            r_df["revisionNumber"],
            errors="coerce",
        )
        r_df = (
            r_df.sort_values("revisionNumber")
            .drop_duplicates(subset="mrid", keep="last")
            .copy()
        )

    # Dismissed REMIT notices should not draw active bands on the operational chart.
    if "eventStatus" in r_df.columns:
        r_df = r_df[
            r_df["eventStatus"].astype(str).str.lower() != "dismissed"
        ].copy()

    r_df["eventStartTime"] = pd.to_datetime(
        r_df["eventStartTime"],
        errors="coerce",
        utc=True,
    ).dt.tz_localize(None)

    r_df["eventEndTime"] = pd.to_datetime(
        r_df["eventEndTime"],
        errors="coerce",
        utc=True,
    ).dt.tz_localize(None)

    bands: list[dict[str, Any]] = []
    for _, remit in r_df.iterrows():
        event_start = remit["eventStartTime"]
        event_end = remit["eventEndTime"]

        if pd.isna(event_start) or pd.isna(event_end):
            continue

        if event_end < start_dt or event_start > end_dt:
            continue

        overlay_start = max(event_start, start_dt)
        overlay_end = min(event_end, end_dt)

        if overlay_end <= overlay_start:
            continue

        midpoint = overlay_start + (overlay_end - overlay_start) / 2
        width_ms = (overlay_end - overlay_start).total_seconds() * 1_000

        bands.append(
            {
                "overlay_start": overlay_start,
                "overlay_end": overlay_end,
                "event_start": event_start,
                "event_end": event_end,
                "midpoint": midpoint,
                "width_ms": width_ms,
                "hover_text": (
                    "<b>REMIT Notice</b><br>"
                    f"{event_start:%d %b %Y %H:%M} -> {event_end:%d %b %Y %H:%M}"
                    "<extra></extra>"
                ),
            }
        )

    return bands


def prepare_constraints_selection(
    constraints_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
    select_bmus: list[str] | tuple[str, ...],
) -> pd.DataFrame:
    """Filter active constraints to selected BMUs and date range using source GMT_DATETIME."""
    if constraints_df is None or constraints_df.empty or not select_bmus:
        return pd.DataFrame()

    required_columns = {"BMU_ID", "CONSTRAINT_GROUP", "GMT_DATETIME"}
    if not required_columns.issubset(constraints_df.columns):
        return pd.DataFrame()

    scoped = constraints_df[constraints_df["BMU_ID"].isin(select_bmus)].copy()
    if scoped.empty:
        return pd.DataFrame()

    scoped["GMT_DATETIME"] = pd.to_datetime(scoped["GMT_DATETIME"], errors="coerce")
    if "SETT_DATE" in scoped.columns:
        scoped["SETT_DATE"] = pd.to_datetime(scoped["SETT_DATE"], errors="coerce")

    start_ts = pd.Timestamp(start_dt)
    end_ts = pd.Timestamp(end_dt)
    mask = (
        scoped["GMT_DATETIME"].notna()
        & (scoped["GMT_DATETIME"] >= start_ts)
        & (scoped["GMT_DATETIME"] <= end_ts)
    )
    filtered = scoped.loc[mask].copy()
    if filtered.empty:
        return pd.DataFrame()

    if "SETT_PERIOD" in filtered.columns:
        filtered["SETT_PERIOD"] = (
            pd.to_numeric(filtered["SETT_PERIOD"], errors="coerce")
            .round()
            .astype("Int64")
        )

    preferred_order = [
        "BMU_ID",
        "CONSTRAINT_GROUP",
        "BID_OFFER",
        "GMT_DATETIME",
        "SETT_DATE",
        "SETT_PERIOD",
    ]
    ordered_cols = [c for c in preferred_order if c in filtered.columns] + [
        c for c in filtered.columns if c not in preferred_order
    ]
    return (
        filtered[ordered_cols]
        .sort_values(["BMU_ID", "GMT_DATETIME", "CONSTRAINT_GROUP"])
        .reset_index(drop=True)
    )


def prepare_constraint_time_bands(
    constraints_df: pd.DataFrame | None,
    start_dt: datetime,
    end_dt: datetime,
) -> list[dict[str, Any]]:
    """Collapse simultaneous constraint groups into one deduplicated 30-min SP bar per source GMT_DATETIME."""
    if constraints_df is None or constraints_df.empty:
        return []

    required_columns = {"CONSTRAINT_GROUP", "GMT_DATETIME"}
    if not required_columns.issubset(constraints_df.columns):
        return []

    c_df = constraints_df.copy()
    c_df["GMT_DATETIME"] = pd.to_datetime(c_df["GMT_DATETIME"], errors="coerce")
    if "SETT_DATE" in c_df.columns:
        c_df["SETT_DATE"] = pd.to_datetime(c_df["SETT_DATE"], errors="coerce")
    if "SETT_PERIOD" in c_df.columns:
        c_df["SETT_PERIOD"] = pd.to_numeric(c_df["SETT_PERIOD"], errors="coerce")

    c_df = c_df.dropna(subset=["GMT_DATETIME"])
    if c_df.empty:
        return []

    start_ts = pd.Timestamp(start_dt)
    end_ts = pd.Timestamp(end_dt)

    c_df = c_df[
        (c_df["GMT_DATETIME"] >= start_ts) & (c_df["GMT_DATETIME"] <= end_ts)
    ].copy()
    if c_df.empty:
        return []

    bands: list[dict[str, Any]] = []
    # Deduplicate by source GMT_DATETIME so simultaneous constraint groups produce one binary grey bar
    grouped = c_df.sort_values(["GMT_DATETIME", "CONSTRAINT_GROUP"]).groupby(
        "GMT_DATETIME", sort=True
    )
    for gmt_start_ts, grp in grouped:
        gmt_start = pd.Timestamp(gmt_start_ts).to_pydatetime()
        gmt_end = gmt_start + timedelta(minutes=30)

        overlay_start = max(gmt_start, start_dt)
        overlay_end = min(gmt_end, end_dt)
        if overlay_end <= overlay_start:
            continue

        unique_groups = sorted(
            {
                str(g).strip()
                for g in grp["CONSTRAINT_GROUP"].dropna().tolist()
                if str(g).strip()
            }
        )
        groups_label = ", ".join(unique_groups) if unique_groups else "Active constraint"

        first_row = grp.iloc[0]
        if "SETT_DATE" in grp.columns and pd.notna(first_row["SETT_DATE"]):
            sett_date_label = pd.Timestamp(first_row["SETT_DATE"]).strftime("%d %b %Y")
        else:
            sett_date_label = gmt_start.strftime("%d %b %Y")

        if "SETT_PERIOD" in grp.columns and pd.notna(first_row["SETT_PERIOD"]):
            sett_period_val: int | str = int(round(float(first_row["SETT_PERIOD"])))
        else:
            sett_period_val = "N/A"

        midpoint = overlay_start + (overlay_end - overlay_start) / 2
        width_ms = (overlay_end - overlay_start).total_seconds() * 1_000

        bands.append(
            {
                "gmt_start": gmt_start,
                "gmt_end": gmt_end,
                "overlay_start": overlay_start,
                "overlay_end": overlay_end,
                "midpoint": midpoint,
                "width_ms": width_ms,
                "constraint_groups": unique_groups,
                "groups_label": groups_label,
                "sett_date_label": sett_date_label,
                "sett_period": sett_period_val,
                "time_window_label": (
                    f"{gmt_start.strftime('%H:%M')} - {gmt_end.strftime('%H:%M')} GMT"
                ),
            }
        )

    return bands
