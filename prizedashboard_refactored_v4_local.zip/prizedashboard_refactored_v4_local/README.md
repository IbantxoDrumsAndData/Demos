# Market Monitoring - Price Dashboard (Refactored v4 Release: Local Laptop / Windows 11 + VS Code + Conda + `.env`)

This release provides the v4 domain-modular implementation of the **Market Monitoring - Price Dashboard**, adding the **Constraint context overlay** (`NED/CONSTRAINTS/bmu_lookup_active_constraints.parquet`) aligned directly on source **`GMT_DATETIME`**, a **`Constraints` Data Table**, and updated Wholesale chart legend labels (**`DA Price`** first, followed by **`ID Forecast`**). Configured for **local execution on a Windows 11 laptop** using **VS Code**, **Conda** (`python=3.11`), `DefaultAzureCredential()` (`az login`), and a local **`.env`** file for EnAppSys credentials.

---

## 1. Quick Start on Windows 11 (VS Code + Conda)

### Step 1: Open in VS Code
Open the `prizedashboard_refactored_v4_local` folder in Visual Studio Code (`File > Open Folder...`).

### Step 2: Create & Activate the Conda Environment
In the VS Code terminal (**Command Prompt** or **Anaconda Prompt**):

```bat
conda env create -f environment.yml
conda activate price-dashboard-local
```
*(Or run `setup_conda_env.bat`. No new dependencies were added compared to v3.)*

Select the **`price-dashboard-local`** Conda interpreter in VS Code (`Ctrl+Shift+P` -> `Python: Select Interpreter` -> `price-dashboard-local`).

### Step 3: Verify `.env` & Authenticate with Azure
1. If `.env` is not already present, copy `.env.example` to `.env` in the project root:
   ```bat
   copy .env.example .env
   ```
2. Verify your EnAppSys credentials and Azure Blob Storage settings in `.env`:
   ```dotenv
   ENAPPUSR=your_enappsys_username
   ENAPP=your_enappsys_password

   AZURE_STORAGE_ACCOUNT_URL=https://<your-storage-account>.blob.core.windows.net
   AZURE_STORAGE_CONTAINER_NAME=<your-container-name>
   ```
3. Run `az login` in your terminal so `DefaultAzureCredential()` can read from Azure Blob Storage:
   ```bat
   az login
   ```

### Step 4: Run the Dashboard
```bat
python -m streamlit run streamlit_app.py --server.port 8000
```
*(Or press **`F5`** in VS Code and choose **`Streamlit: Run Market Monitoring Dashboard`**, or run **`run_dashboard.bat`**.)*

---

## 2. Highlights in Refactored v4

* **Constraint Context Overlay (`NED/CONSTRAINTS/bmu_lookup_active_constraints.parquet`)**:
  * Independent sidebar toggle (`Constraints on operational charts`, unchecked by default; lazy-loaded and cached with `ttl=3600` matching other Blob Parquet readers).
  * Uses source `GMT_DATETIME` directly from NED for chart alignment and date filtering (consistent with all other NED Parquet datasets), keeping `SETT_DATE` and `SETT_PERIOD` for hover and audit reference.
  * Renders subtle light-grey per-settlement-period bars (`Constraint period`) behind operational traces and REMIT bands, bounded strictly to the unit's MW range.
  * Deduplicates simultaneous constraint groups into a single binary grey band per BMU/`GMT_DATETIME` while listing all applicable `CONSTRAINT_GROUP` values in hover text (`BMU`, `Group`, `Settlement date`, `Settlement period`, `Time` in GMT).
* **Constraints Data Table**: Added `Constraints` to `Data Tables` mirroring `REMIT`, displaying filtered `BMU_ID`, `CONSTRAINT_GROUP`, `BID_OFFER`, `GMT_DATETIME`, `SETT_DATE`, and `SETT_PERIOD`.
* **Wholesale Chart Legend Refinement**: Updated legend to display **`DA Price`** first, followed by **`ID Forecast`** (matching EnAppSys `GB_NORDPOOL_HR_DA.PRICE_GBP` and `GB_MIDP_PRICE_FORECAST.DM01`).
* **Retained v3 & v2 Capabilities**: Up to 6 simultaneous BMUs, `Current Year` / `YoY Comparison` dashboard switcher in the shared shell, compact `Date selection` modes, `DA PN` horizon (`#1E40AF`, `legendonly`), 6-trace Bid/Offer price chart, subtle yellow REMIT time bands, and overlap-proof HTML card titles.
