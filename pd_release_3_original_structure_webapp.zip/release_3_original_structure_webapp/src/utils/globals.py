import os

from azure.identity import DefaultAzureCredential

client_id = os.environ.get("DEFAULT_IDENTITY_CLIENT_ID")

credential = DefaultAzureCredential(
    managed_identity_client_id=client_id,
)

vault_url = os.environ.get("AZURE_KEYVAULT_URL", "placeholder")

storage_account_url = os.environ.get("AZURE_STORAGE_ACCOUNT_URL", "placeholder")

container_name = os.environ.get("AZURE_STORAGE_CONTAINER_NAME", "placeholder")
