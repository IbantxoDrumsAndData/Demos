# Market Monitoring Dashboard — Release 3 (Original Code Structure: Web App Deployment)

This release preserves the **exact original file and folder structure** (`streamlit_app.py`, `dashboards/demo_dashboard.py`, `dashboards/demo_dashboard_2.py`, `src/apis/*`, `src/utils/*`) for **Azure App Service (Web App) deployment**, with all performance bottlenecks and correctness issues resolved in-place.

---

## 1. File Structure

```text
release_3_original_structure_webapp/
├── .streamlit/
│   └── config.toml
├── assets/
│   └── logo.png
├── azure-pipelines.yaml
├── azure-pipelines-NED-refresh.yml
├── requirements.txt
├── requirements-NED.txt
├── streamlit_app.py
├── dashboards/
│   ├── demo_dashboard.py          # Optimized main dashboard (conditional loading + caching)
│   └── demo_dashboard_2.py        # Data Diagnostics & execution timings view
├── src/
│   ├── apis/
│   │   ├── NEDBlob.py             # Cached Blob Parquet loaders with in-cache datetime parsing
│   │   ├── elexon.py              # Cached Elexon BMU mapping & guarded REMIT loader
│   │   ├── enappsys.py            # Cached EnAppSys wholesale loader with lazy KeyVault lookup
│   │   ├── lowcarboncontracts.py
│   │   └── neso.py
│   └── utils/
│       ├── dates.py
│       ├── figTrace.py
│       ├── globals.py             # Managed Identity credential & Azure endpoint configuration
│       └── keyvault.py            # Lazy SecretClient initialization
├── jobs/
│   └── ned_query.py
└── setup/
```

---

## 2. Performance & Correctness Improvements Applied

1. **No Eager Top-of-Script Loading**:
   - Only lightweight `getStakeholders()` runs on initial page load. `getOperationalData()`, `getBMUMapping()`, `getWholesalePrices()`, `getBidOfferData()`, and `getBOAInstructionsData()` are never called until **`Load dashboard`** is clicked and their respective view is selected.
2. **Reactive Sidebar + `Load dashboard` Gate**:
   - `Fuel Type -> Portfolio -> BMU` filtering runs instantaneously against cached `stakeholders` metadata without downloading `latest_bmu_data.parquet`.
   - Changing sidebar widgets does not trigger heavy queries or clear displayed charts until **`Load dashboard`** is clicked.
3. **Cached Downstream Data Preparation (`@st.cache_data(ttl=3600)`)**:
   - `GMT_DATETIME` parsing is performed once inside the cached `NEDBlob.py` functions (`getOperationalData`, `getBidOfferData`, `getBOAInstructionsData`).
   - Elexon BMU mapping joins (`_prepare_operational_with_mapping`), date/BMU filtering (`_filter_operational_data`), and Bid/Offer pivot merges (`_build_wholesale_comparison_table`) are cached.
4. **REMIT Guardrails**:
   - `getRemit()` is called **only** inside `if showREMITOverlay:` when `bmuDF` is non-empty and `ELEXON_BMU_ID` is present and valid.
5. **Lazy Key Vault Secret Retrieval**:
   - `get_secret("ENAPP")` and `get_secret("ENAPPUSR")` are called inside `getWholesalePrices()` rather than at module import time.
6. **BOA Date-Range Filter Fix**:
   - `bOAInstructionsData` is filtered by both `BMU_ID` and the submitted `datetimeRange`.
7. **Data Diagnostics**:
   - Execution timings (`time.perf_counter()`) and per-source diagnostics are available in an expander at the bottom of `Demo Dashboard 1` and on `Demo Dashboard 2 (Diagnostics)`.

---

## 3. Startup Command (Azure App Service)

```bash
python -m streamlit run streamlit_app.py --server.port 8000 --server.address 0.0.0.0
```
